#include "adventure.h"
#include "flame_art.h"
#include "sticks.h"
#include "ember_save.h"
#include "console_service.h"
#include "ui_zh.h"
#include "./BSP/LCD/lcd.h"
#include <stdint.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

/* Shared fixed-pool room engine. Positions are Q4, time advances only in PLAY.
 * One 16x16 world tile is composited at a time; no full-screen framebuffer. */
#define AV_W 320
#define AV_H 176
#define AV_CELLS 220
#define AV_ENEMIES 8
#define AV_BULLETS 48
#define AV_BG 0x0842
#define AV_GOLD 0xfda0
#define AV_CYAN 0x5f7f
enum {AV_TITLE,AV_SELECT,AV_CODEX,AV_RECORD,AV_STORY,AV_COUNT,AV_PLAY,AV_PAUSE,AV_REWARD,AV_ROUTE,AV_SHOP,AV_CHEST,AV_MEMORY,AV_END_CHOICE,AV_END,AV_SECRET};
enum {AP_PIERCE=1,AP_BOUNCE=2,AP_BLAST=4,AP_ICE=8};
typedef struct {int16_t x,y;int8_t vx,vy;uint8_t life,damage,flags,enemy,bounce;uint16_t hit;} av_bullet;
typedef struct {int16_t x,y;uint16_t clock;uint8_t hp,type,dir,slow,flash;} av_enemy;
typedef struct {int16_t x,y;uint8_t life,radius;} av_effect;
typedef struct {int16_t x,y;uint8_t life;} av_hazard;
typedef struct {uint8_t delay,damage,cost,speed,flags;const char *name;} av_weapon;
static const av_weapon av_weapons[12]={
 {9,2,0,80,0,"W_PISTOL"},{4,1,1,88,0,"W_SMG"},{17,2,3,72,0,"W_SHOTGUN"},{24,7,3,120,AP_PIERCE,"W_SNIPER"},
 {28,6,4,64,AP_BLAST,"W_ROCKET"},{11,3,2,120,AP_PIERCE,"W_LASER"},{14,3,2,80,AP_BOUNCE,"W_BOUNCE"},{15,2,2,76,AP_ICE,"W_ICE"},
 {12,4,0,0,0,"W_SWORD"},{26,8,0,0,0,"W_GREATSWORD"},{17,5,0,0,0,"W_SPEAR"},{19,3,0,0,0,"W_CIRCLE"}};
static const char *av_heroes[3]={"H_KNIGHT","H_ENGINEER","H_RANGER"};
static const char *av_tanks[4]={"T_ASSAULT","T_HEAVY","T_ROCKET","T_LASER"};
static const char *av_modes[4]={"M_CAMPAIGN","M_SURVIVAL","M_CAPTURE","M_BOSS"};
static const char *av_maps[5]={"MAP_CITY","MAP_SWAMP","MAP_DESERT","MAP_ICE","MAP_FORT"};
static const char *av_chapters[5]={"CH_ASH","CH_FORGE","CH_GARDEN","CH_TOWER","CH_THRONE"};
static const char *av_boss_names[5]={"B_MECH","B_FORGE","B_THORN","B_STAR","B_LOST"};
static const char *av_perks[12]={"P_HEALTH","P_DAMAGE","P_RATE","P_SPEED","P_ARMOR","P_ENERGY","P_CRIT","P_RECOVER","P_SHIELD","P_PIERCE","P_COOL","P_VAMP"};
static const uint16_t av_themes[5]={0x3165,0x4143,0x1945,0x1929,0x2805};
static const uint16_t av_floor_color[5]={0x10a3,0x1882,0x0902,0x1086,0x1003};
static const uint16_t av_enemy_colors[6]={0xf2ca,0xfd83,0xee26,0xc9df,0x947f,0xbdf7};
static struct {
 uint8_t tank,state,hero,mode,mapchoice,floor,room,room_kind,story_page,won,ending;
 uint8_t map[AV_CELLS],dirty[AV_CELLS],nav[AV_CELLS],perks[12],choices[3];
 uint8_t hp,maxhp,armor,maxarmor,energy,maxenergy,weapon,second,body,aim,memories,boss_mask;
 uint8_t spawned,total,kills,boss,boss_hp,boss_max,boss_dir,base_hp,armed,preview,room_weapon;
 uint16_t frame,shot_at,hurt_at,skill_cd,skill_active,invul,room_frame,boss_clock,wave,capture,coins;
 uint8_t melee_life,melee_kind,melee_dir,roll_boost,fallback;int16_t melee_x,melee_y;
 uint16_t turret_life,turret_clock;int16_t px,py,bx,by,turret_x,turret_y,ice_vx,ice_vy;
 uint32_t seed,score,last,count_at,hud_at,elapsed;
 int screen_y,screen_h,screen_w,tile_x,tile_y,tile_w,tile_h,world_x,world_y;
 v6_rect buttons[6];av_enemy enemies[AV_ENEMIES];av_bullet bullets[AV_BULLETS];av_effect effects[8];av_hazard hazards[4];
} av;
static uint16_t av_pixels[40*40];
static void av_scene(void);
static void av_room(void);
static void av_end(uint8_t win);
static uint32_t av_rand(void){uint32_t n=av.seed;n^=n<<13;n^=n>>17;n^=n<<5;return av.seed=n?n:0x12345678;}
static int av_clamp(int n,int lo,int hi){return n<lo?lo:n>hi?hi:n;}
static int av_dist(int x,int y,int xx,int yy){return abs(x-xx)+abs(y-yy);}
static int av_overlap(int x,int y,int w,int h,int xx,int yy,int ww,int hh){return x<xx+ww&&xx<x+w&&y<yy+hh&&yy<y+h;}
static void av_text(int x,int y,int w,int size,const char *key,uint16_t color){zh_draw(x,y,w,size,size,key,color,AV_BG);}
static void av_center(int y,const char *key,uint16_t color){int size=lcddev.width>=640?24:16,w=zh_width(key,size);av_text((lcddev.width-w)/2,y,w,size,key,color);}
static void av_btn(int i,int x,int y,int w,int h,const char *key){v6_rect *r=&av.buttons[i];int size=16,tw=zh_width(key,size);if(h<34)h=34;r->x=x;r->y=y;r->w=w;r->h=h;lcd_fill(x,y,x+w-1,y+h-1,0x1926);lcd_draw_rectangle(x,y,x+w-1,y+h-1,0x6bce);av_text(x+(w-tw>0?(w-tw)/2:4),y+(h-size)/2,w-8,size,key,WHITE);}
static void av_mark(int x,int y,int w,int h){int xx,yy,x0=av_clamp(x/16,0,19),y0=av_clamp(y/16,0,10),x1=av_clamp((x+w)/16,0,19),y1=av_clamp((y+h)/16,0,10);for(yy=y0;yy<=y1;yy++)for(xx=x0;xx<=x1;xx++)av.dirty[yy*20+xx]=1;}
static void av_wall_changed(int t){av.dirty[t]=1;if(t>=20)av.dirty[t-20]=1;if(t<200)av.dirty[t+20]=1;}
static void av_mark_actors(void){int i;av_mark(av.px/16-32,av.py/16-28,66,50);for(i=0;i<AV_ENEMIES;i++)if(av.enemies[i].hp)av_mark(av.enemies[i].x/16-16,av.enemies[i].y/16-20,34,40);for(i=0;i<AV_BULLETS;i++)if(av.bullets[i].life)av_mark(av.bullets[i].x/16-4,av.bullets[i].y/16-4,9,9);if(av.boss)av_mark(av.bx/16-28,av.by/16-28,58,58);if(av.melee_life)av_mark(av.melee_x-50,av.melee_y-50,102,102);if(av.turret_life)av_mark(av.turret_x/16-8,av.turret_y/16-8,18,18);for(i=0;i<8;i++)if(av.effects[i].life)av_mark(av.effects[i].x-22,av.effects[i].y-22,44,44);for(i=0;i<4;i++)if(av.hazards[i].life)av_mark(av.hazards[i].x-14,av.hazards[i].y-14,30,30);}
static void av_paint(int x,int y,int w,int h,uint16_t color){int x0,y0,x1,y1,i,j;if(x+w<=av.world_x||x>=av.world_x+16||y+h<=av.world_y||y>=av.world_y+16)return;x0=x*av.screen_w/AV_W;y0=av.screen_y+y*av.screen_h/AV_H;x1=(x+w)*av.screen_w/AV_W;y1=av.screen_y+(y+h)*av.screen_h/AV_H;x0=av_clamp(x0,av.tile_x,av.tile_x+av.tile_w);x1=av_clamp(x1,av.tile_x,av.tile_x+av.tile_w);y0=av_clamp(y0,av.tile_y,av.tile_y+av.tile_h);y1=av_clamp(y1,av.tile_y,av.tile_y+av.tile_h);for(j=y0;j<y1;j++)for(i=x0;i<x1;i++)av_pixels[(j-av.tile_y)*av.tile_w+i-av.tile_x]=color;}
static void av_line(int x,int y,int xx,int yy,int thick,uint16_t color){int dx=abs(xx-x),sx=x<xx?1:-1,dy=-abs(yy-y),sy=y<yy?1:-1,e=dx+dy,t;for(;;){av_paint(x,y,thick,thick,color);if(x==xx&&y==yy)break;t=2*e;if(t>=dy){e+=dy;x+=sx;}if(t<=dx){e+=dx;y+=sy;}}}
static int av_sprite_origin;
static void av_sprite_paint(int x,int y,int w,int h,uint16_t c){int top=(y-av_sprite_origin)*3/2,bottom=(y+h-av_sprite_origin)*3/2;av_paint(x,av_sprite_origin+top,w,bottom-top,c);}
static void av_actor(int x,int y,int dir,int body,uint16_t c,int tank,int type){
 int u,v,dx=stick_dx[body],dy=stick_dy[body];
 if(tank){for(u=-1;u<=1;u+=2){v=u*5;av_line(x-dy*v/256-dx*6/256,y+dx*v/256-dy*6/256,x-dy*v/256+dx*6/256,y+dx*v/256+dy*6/256,3,0x8410);}av_paint(x-4,y-4,9,9,c);av_paint(x-3,y-3,6,6,0xc618);av_line(x,y,x+stick_dx[dir]*11/256,y+stick_dy[dir]*11/256,2,c);}
 else{av_paint(x-7,y-1,14,10,c);av_paint(x-8,y+5,3,5,c);av_paint(x+5,y+5,3,5,c);av_paint(x-4,y+6,3,4,0x8410);av_paint(x+2,y+6,3,4,0x8410);av_paint(x-5,y-12,10,10,0xbdf7);av_paint(x-4,y-13,8,3,0xe71c);av_paint(x-6,y-9,12,3,0xe71c);av_paint(x-3,y-6,6,2,0x0801);av_paint(x-1,y-12,2,6,WHITE);av_paint(x-4,y,8,5,0x8c51);av_paint(x-2,y+1,4,3,AV_GOLD);if(type==2)av_paint(x-6,y-12,12,3,0x07e0);if(type==1){av_paint(x-4,y-6,3,2,AV_CYAN);av_paint(x+1,y-6,3,2,AV_CYAN);}av_line(x,y,x+stick_dx[dir]*10/256,y+stick_dy[dir]*10/256,2,AV_GOLD);}
}
static void av_render(void){int tile,i,x,y,k,bx,by;uint16_t bg,color;av_enemy *e;av_bullet *p;
 for(tile=0;tile<AV_CELLS;tile++)if(av.dirty[tile]){av.dirty[tile]=0;x=tile%20*16;y=tile/20*16;av.world_x=x;av.world_y=y;av.tile_x=x*av.screen_w/AV_W;av.tile_y=av.screen_y+y*av.screen_h/AV_H;av.tile_w=(x+16)*av.screen_w/AV_W-av.tile_x;av.tile_h=av.screen_y+(y+16)*av.screen_h/AV_H-av.tile_y;bg=av_floor_color[av.tank?av.mapchoice:av.floor];for(i=0;i<av.tile_w*av.tile_h;i++)av_pixels[i]=bg;
  k=av.map[tile];if(!av.tank)flame_tile(x,y,k,av.floor,tile>=20&&av.map[tile-20],tile<200&&av.map[tile+20],av_paint);
  if(av.tank){av_paint(x,y,16,1,bg+0x0821);av_paint(x,y,1,16,bg+0x0821);color=av_themes[av.tank?av.mapchoice:av.floor];
  if(k==1||k==2){av_paint(x,y,16,16,color);av_paint(x+1,y+1,14,3,k==2?0x8c51:0x8b69);av_paint(x+1,y+14,14,2,0x0000);av_paint(x+7,y+4,1,10,0x1082);}
  if(k==3){av_paint(x,y,16,16,0x1230);av_paint(x+2,y+4,9,2,0x449a);av_paint(x+6,y+11,8,1,0x449a);}
  if(k==4){av_paint(x+2,y+3,3,10,0x2365);av_paint(x+9,y+1,4,12,0x3446);}
  if(k==5){av_paint(x+1,y+2,14,13,AV_GOLD);av_paint(x+4,y+5,8,8,0xe986);}
  }
  if(av.tank&&av.mode==2&&tile%20>=8&&tile%20<=11&&tile/20>=4&&tile/20<=6){av_paint(x,y,16,1,AV_CYAN);av_paint(x,y,1,16,AV_CYAN);}
  for(i=0;i<4;i++)if(av.hazards[i].life){bx=av.hazards[i].x;by=av.hazards[i].y;if(av.hazards[i].life<16)av_paint(bx-13,by-13,27,27,av.floor==2?0x53a0:0xea40);else{av_paint(bx-2,by-3,5,6,0xfbe0);av_paint(bx-13,by-13,27,1,0xf800);av_paint(bx-13,by+13,27,1,0xf800);av_paint(bx-13,by-13,1,27,0xf800);av_paint(bx+13,by-13,1,27,0xf800);}}
  if(av.turret_life){bx=av.turret_x/16;by=av.turret_y/16;av_paint(bx-7,by-5,14,10,0x7bef);av_paint(bx-3,by-8,6,8,AV_CYAN);}
  for(i=0;i<AV_ENEMIES;i++){e=&av.enemies[i];if(e->hp&&av_overlap(x,y,16,16,e->x/16-16,e->y/16-20,34,40)){if(av.tank)av_actor(e->x/16,e->y/16,e->dir,e->dir,e->flash?WHITE:av_enemy_colors[e->type],1,e->type%3);else{av_sprite_origin=e->y/16;flame_enemy(e->x/16,e->y/16,e->type,e->clock,e->flash,av_sprite_paint);}if(e->slow)av_paint(e->x/16-5,e->y/16+9,10,1,AV_CYAN);if(e->type==2&&e->clock%90>65)av_paint(e->x/16-2,e->y/16-14,4,3,0xf800);}}
  if(av.boss&&av_overlap(x,y,16,16,av.bx/16-28,av.by/16-28,58,58)){bx=av.bx/16;by=av.by/16;if(!av.tank)flame_boss(bx,by,av.floor,av.boss_clock,av_paint);else{color=av.tank?0xfbe0:av_enemy_colors[av.floor];av_paint(bx-17,by-14,34,28,0x18c3);av_paint(bx-14,by-16,28,30,color);av_paint(bx-21,by-5,8,18,0x7bef);av_paint(bx+13,by-5,8,18,0x7bef);av_paint(bx-9,by-9,18,5,0x0000);av_paint(bx-6,by-8,4,3,0xf800);av_paint(bx+3,by-8,4,3,0xf800);av_paint(bx-7,by+3,14,12,AV_GOLD);av_line(bx,by,bx+stick_dx[av.boss_dir]*23/256,by+stick_dy[av.boss_dir]*23/256,3,0xffff);}av_paint(bx-20,by-27,40,3,0x3000);av_paint(bx-20,by-27,40*av.boss_hp/av.boss_max,3,0xf800);}
  if(av_overlap(x,y,16,16,av.px/16-18,av.py/16-28,38,48)){if(av.tank)av_actor(av.px/16,av.py/16,av.aim,av.body,av.invul&&av.frame%4<2?WHITE:AV_CYAN,1,av.hero);else{av_sprite_origin=av.py/16;flame_hero(av.px/16,av.py/16,av.hero,av.frame,sticks.move>=0,av.invul&&av.frame%4<2,av_sprite_paint);}}
  if(!av.tank&&av_overlap(x,y,16,16,av.px/16-32,av.py/16-28,66,50)){int wx=av.px/16+4,wy=av.py/16,reach=av.weapon==10?23:av.weapon>=8?15:10,ex=wx+stick_dx[av.aim]*reach/256,ey=wy+stick_dy[av.aim]*reach/256;av_line(wx,wy,ex,ey,av.weapon==9?4:2,av.weapon>=8?0xdedb:0xd4c9);if(av.weapon==8||av.weapon==9)av_line(wx-stick_dy[av.aim]*4/256,wy+stick_dx[av.aim]*4/256,wx+stick_dy[av.aim]*4/256,wy-stick_dx[av.aim]*4/256,2,AV_GOLD);if(av.weapon==10)av_paint(ex-2,ey-2,5,5,0xffff);if(av.weapon==11){int a;for(a=0;a<16;a+=2)av_paint(ex+stick_dx[a]*5/256,ey+stick_dy[a]*5/256,2,2,AV_GOLD);}}
  if(av.melee_life&&av_overlap(x,y,16,16,av.melee_x-50,av.melee_y-50,102,102)){int a,from=av.melee_kind==11?0:-3,to=av.melee_kind==11?16:3,rad=av.melee_kind==9?33:av.melee_kind==11?27:27;bx=av.melee_x;by=av.melee_y;
   if(av.melee_kind==10){int len=46*(9-av.melee_life)/8;av_line(bx,by,bx+stick_dx[av.melee_dir]*len/256,by+stick_dy[av.melee_dir]*len/256,2,0xef5c);}
   else for(a=from;a<to;a++){int d=(av.melee_dir+a)&15,dd=(d+1)&15;av_line(bx+stick_dx[d]*rad/256,by+stick_dy[d]*rad/256,bx+stick_dx[dd]*rad/256,by+stick_dy[dd]*rad/256,2,av.melee_life>4?0xff91:0xb368);}
  }
  if(av.armor||av.invul){av_paint(av.px/16-8,av.py/16+10,16,1,av.invul?WHITE:AV_CYAN);}
  for(i=0;i<AV_BULLETS;i++){p=&av.bullets[i];if(p->life){color=p->enemy?0xfa89:(p->flags&AP_ICE)?AV_CYAN:AV_GOLD;av_paint(p->x/16-2,p->y/16-2,4,4,color);av_paint(p->x/16-1,p->y/16-1,2,2,WHITE);}}
  for(i=0;i<8;i++)if(av.effects[i].life){int r=av.effects[i].radius*(9-av.effects[i].life)/8;bx=av.effects[i].x;by=av.effects[i].y;av_paint(bx-r,by-r,2*r+1,1,AV_GOLD);av_paint(bx-r,by+r,2*r+1,1,AV_GOLD);av_paint(bx-r,by-r,1,2*r+1,0xf986);av_paint(bx+r,by-r,1,2*r+1,0xf986);}
  lcd_color_fill(av.tile_x,av.tile_y,av.tile_x+av.tile_w-1,av.tile_y+av.tile_h-1,av_pixels);
 }
}
static void av_circle(int x,int y,int r,uint16_t c){int i,xx;for(i=-r;i<=r;i++){xx=r;while(xx*xx+i*i>r*r)xx--;lcd_fill(x-xx,y+i,x+xx,y+i,c);}}
static void av_action(v6_rect q,const char *key,uint16_t color,int cd){int cx=q.x+q.w/2,cy=q.y+q.h/2,r=q.w/2,size=12,tw;char b[12];av_circle(cx,cy,r,color);av_circle(cx,cy,r-2,AV_BG);if(cd){sprintf(b,"%u",(cd*30+999)/1000);tw=zh_width(b,16);av_text(cx-tw/2,cy-13,q.w,16,b,0xbdf7);av_text(cx-12,cy+5,30,size,"COOLDOWN",0x8c51);}else{tw=zh_width(key,size);av_text(cx-tw/2,cy-6,q.w,size,key,color);}}
static void av_controls(void){int r=sticks.r,i,off=r/2;uint16_t rim=av.tank?0x3a8d:0x6aab;char b[24];v6_rect q;
 /* Only redraw each control's own footprint, preserving the adjacent arc. */
 for(i=0;i<2;i++){int x=i?sticks.rx:sticks.lx,y=sticks.ly;av_circle(x,y,r,rim);av_circle(x,y,r-2,AV_BG);av_circle(x+(i?sticks.ax:sticks.mx)*off/r,y+(i?sticks.ay:sticks.my)*off/r,r/3,i?0xe527:AV_CYAN);if(!i){lcd_fill(x-r+7,y,x-r+14,y,0x9c92);lcd_fill(x+r-14,y,x+r-7,y,0x9c92);lcd_fill(x,y-r+7,x,y-r+14,0x9c92);lcd_fill(x,y+r-14,x,y+r-7,0x9c92);}}
 av_action(sticks.skill,av.tank?"SKILL":av.hero==0?"ACTION_FURY":av.hero==1?"ACTION_TURRET":"ACTION_ROLL",av.skill_cd?0x528a:AV_GOLD,av.skill_cd);
 if(!av.tank)av_action(sticks.swap,"ACTION_SWAP",0xcddd,0);
 q=sticks.swap;if(av.tank){lcd_fill(q.x-10,q.y,q.x+q.w+10,q.y+q.h-1,AV_BG);av_text(q.x-10,q.y+2,q.w+20,12,av.mode==0?"BASE_HP":av.mode==1?"WAVE":av.mode==2?"CAPTURE":"BOSS_STAGE",WHITE);sprintf(b,"%u",av.mode==0?av.base_hp:av.mode==1?av.wave:av.mode==2?av.capture/10:av.floor+1);av_text(q.x+q.w/2-10,q.y+20,40,16,b,AV_CYAN);}
 av_text(sticks.lx-r,sticks.top+2,2*r,12,"MOVE_STICK",0x9c92);av_text(sticks.rx-r,sticks.top+2,2*r,12,av.tank?"FIRE_STICK":"AIM_ATTACK",0xcddd);
 if(!av.tank){int x=sticks.lx+r+14,w=sticks.swap.x-x-6;if(w>=60){lcd_fill(x,sticks.top+8,x+w-1,sticks.top+45,AV_BG);av_text(x,sticks.top+8,w,12,"BACKUP",0x9c92);av_text(x,sticks.top+25,w,12,av_weapons[av.second].name,0xcddd);}}
}
static void av_bar(int x,int y,int w,int v,int max,uint16_t c){lcd_fill(x,y,x+w-1,y+3,0x2945);if(v&&max)lcd_fill(x,y,x+w*v/max-1,y+3,c);}
static void av_hud(void){char b[80];int x=lcddev.width>=640?218:133;lcd_fill(0,0,lcddev.width-1,39,AV_BG);av_text(8,3,120,16,av.tank?av_tanks[av.hero]:"FLAME",AV_GOLD);
 if(av.tank){sprintf(b,"%u  HP %u/%u   %lu",av.floor+1,av.hp,av.maxhp,(unsigned long)av.score);av_text(8,23,lcddev.width-16,12,b,WHITE);}
 else{av_bar(8,24,50,av.hp,av.maxhp,0xf9e8);av_bar(64,24,40,av.armor,av.maxarmor,AV_CYAN);av_bar(110,24,40,av.energy,av.maxenergy,0xbc5f);sprintf(b,"%u/%u  A%u E%u  $%u",av.hp,av.maxhp,av.armor,av.energy,av.coins);av_text(159,23,lcddev.width-235,12,b,WHITE);}
 av_text(x,3,lcddev.width-x-88,16,av.fallback?"PISTOL_ASSIST":av_weapons[av.weapon].name,av.fallback?0xfe07:AV_CYAN);lcd_draw_rectangle(sticks.pause.x,sticks.pause.y,sticks.pause.x+sticks.pause.w-1,sticks.pause.y+sticks.pause.h-1,0x528a);av_text(sticks.pause.x+12,13,48,12,"PAUSE",WHITE);
 if(!av.tank){sprintf(b,"%u-%u",av.floor+1,av.room+1);av_text(lcddev.width-112,25,34,12,b,AV_GOLD);}else if(av.mode==2){sprintf(b,"%u%%",av.capture/10);av_text(lcddev.width-65,25,64,12,b,AV_CYAN);}
}

static int av_solid(int x,int y){int xx,yy,t;if(x<23||y<23||x>297||y>153)return 1;for(yy=(y-5)/16;yy<=(y+5)/16;yy++)for(xx=(x-5)/16;xx<=(x+5)/16;xx++){t=av.map[yy*20+xx];if(t==1||t==2||t==3||t==5)return 1;}return 0;}
static void av_move(int16_t *x,int16_t *y,int vx,int vy){int nx=*x+vx,ny=*y+vy;if(!av_solid(nx/16,*y/16))*x=nx;if(!av_solid(*x/16,ny/16))*y=ny;}
static void av_flow(void){uint8_t queue[AV_CELLS];int head=0,tail=0,n,t,k,x,y;static const int off[4]={-20,1,20,-1};memset(av.nav,255,sizeof av.nav);n=(av.py/256)*20+av.px/256;if(av.tank&&av.mode==0)n=9*20+10;av.nav[n]=0;queue[tail++]=n;while(head<tail){n=queue[head++];x=n%20;y=n/20;for(k=0;k<4;k++){if((k==0&&y==0)||(k==1&&x==19)||(k==2&&y==10)||(k==3&&x==0))continue;t=n+off[k];if(av.nav[t]==255&&av.map[t]!=1&&av.map[t]!=2&&av.map[t]!=3){av.nav[t]=av.nav[n]+1;queue[tail++]=t;}}}}
static int av_seek(av_enemy *e){int x=e->x/16,y=e->y/16,n=(y/16)*20+x/16,k,t,b=n;static const int off[4]={-20,1,20,-1};for(k=0;k<4;k++){t=n+off[k];if(t>=0&&t<AV_CELLS&&abs(t%20-n%20)+abs(t/20-n/20)==1&&av.nav[t]<av.nav[b])b=t;}if(b==n)return stick_direction(av.px/16-x,av.py/16-y);return stick_direction(b%20*16+8-x,b/20*16+8-y);}
static void av_fx(int x,int y,int radius){int i;for(i=0;i<8;i++)if(!av.effects[i].life){av.effects[i].x=x;av.effects[i].y=y;av.effects[i].radius=radius;av.effects[i].life=8;return;}}
static void av_save(void){if(av.tank){console_record(10,av.score);console_flush();}else{if(av.score>ember_stats.score)ember_stats.score=av.score;if(av.floor+1>ember_stats.floors[av.hero])ember_stats.floors[av.hero]=av.floor+1;ember_stats.boss_end|=av.boss_mask;ember_flush();}}
static void av_end(uint8_t win){av.won=win;if(win){if(av.tank)console_won(10);else{if(ember_stats.wins<255)ember_stats.wins++;ember_stats.boss_end|=1<<(5+av.ending);}}av_save();av.state=AV_END;sticks_reset();av.armed=0;av_scene();}
static void av_hurt(int damage){if(av.invul)return;av.hurt_at=av.frame;av.invul=27;if(av.armor){if(damage<=av.armor){av.armor-=damage;damage=0;}else{damage-=av.armor;av.armor=0;}}if(damage>=av.hp){av.hp=0;av_end(0);return;}av.hp-=damage;av_fx(av.px/16,av.py/16,12);console_beep(HAL_GetTick(),35);}
static void av_damage(int i,int damage,int flags){av_enemy *e=&av.enemies[i];if(!e->hp)return;e->flash=3;if(flags&AP_ICE)e->slow=70;if(damage>=e->hp){e->hp=0;av.kills++;av.score+=60+e->type*25;av.coins+=2;av.energy=av_clamp(av.energy+3+av.perks[7],0,av.maxenergy);if(av.perks[11]&&av.kills%5==0&&av.hp<av.maxhp)av.hp++;av_fx(e->x/16,e->y/16,10);}else e->hp-=damage;}
static void av_emit(int x,int y,int dir,int speed,int damage,int flags,int enemy){int i;dir&=15;for(i=enemy?12:0;i<AV_BULLETS;i++)if(!av.bullets[i].life){av_bullet *p=&av.bullets[i];memset(p,0,sizeof *p);p->x=x;p->y=y;p->vx=stick_dx[dir]*speed/256;p->vy=stick_dy[dir]*speed/256;p->life=85;p->damage=damage;p->flags=flags;p->enemy=enemy;p->bounce=flags&AP_BOUNCE?2:0;return;}}
static int av_reach(int dx,int dy,int weapon,int dir,int extra){int dot=(dx*stick_dx[dir]+dy*stick_dy[dir])/256,cross=abs(dx*stick_dy[dir]-dy*stick_dx[dir])/256,range=weapon==9?33:weapon==10?46:27;if(dx*dx+dy*dy>(range+extra)*(range+extra))return 0;if(weapon==11)return 1;if(weapon==10)return dot>=0&&cross<=6+extra;return dot>=0&&cross<=dot+8+extra;}
static int av_sight(int x,int y,int xx,int yy){int i,n=abs(xx-x)>abs(yy-y)?abs(xx-x):abs(yy-y),tx,ty,t;for(i=4;i<n;i+=3){tx=x+(xx-x)*i/n;ty=y+(yy-y)*i/n;if(tx<0||tx>=320||ty<0||ty>=176)return 0;t=av.map[ty/16*20+tx/16];if(t==1||t==2||t==3)return 0;}return 1;}
static void av_melee(int weapon,int damage){int i,j,dx,dy,x=av.px/16,y=av.py/16;av_enemy *e;av_bullet *b;av_mark_actors();av.melee_life=8;av.melee_kind=weapon;av.melee_dir=av.aim;av.melee_x=x;av.melee_y=y;
 if(av.roll_boost){damage+=3;av.roll_boost=0;}
 for(i=0;i<AV_ENEMIES;i++){e=&av.enemies[i];dx=e->x/16-x;dy=e->y/16-y;if(e->hp&&av_reach(dx,dy,weapon,av.aim,3)&&av_sight(x,y,e->x/16,e->y/16)){av_damage(i,damage,0);if(weapon==9&&e->hp)for(j=0;j<6;j++)av_move(&e->x,&e->y,stick_dx[av.aim]/16,stick_dy[av.aim]/16);}}
 if(av.boss&&av_reach(av.bx/16-x,av.by/16-y,weapon,av.aim,10)&&av_sight(x,y,av.bx/16,av.by/16))av.boss_hp=av.boss_hp>damage?av.boss_hp-damage:0;
 if(weapon==8)for(i=0;i<AV_BULLETS;i++){b=&av.bullets[i];if(b->life&&b->enemy&&!b->flags&&av_reach(b->x/16-x,b->y/16-y,8,av.aim,0)&&av_sight(x,y,b->x/16,b->y/16))b->life=0;}
 /* Break only exposed destructible masonry; never steel or distant walls. */
 if(weapon==9)for(i=0;i<AV_CELLS;i++)if(av.map[i]==1){dx=i%20*16+8-x;dy=i/20*16+8-y;if(av_reach(dx,dy,9,av.aim,0)&&av_sight(x,y,x+dx*2/3,y+dy*2/3)){av.map[i]=0;av_wall_changed(i);}}
 av_mark_actors();console_beep(HAL_GetTick(),18);
}
static void av_fire(void){const av_weapon *w=&av_weapons[av.weapon];int delay,damage,flags,i,cost=av.tank?0:w->cost,fallback=0;
 /* An energy-starved ranged weapon borrows the free pistol without dropping
  * either equipped weapon. The HUD explicitly names the fallback. */
 if(!av.tank&&av.energy<cost){w=&av_weapons[0];cost=0;fallback=1;}
 delay=w->delay-av.perks[2];damage=w->damage+av.perks[1];flags=w->flags;if(av.skill_active&&av.hero==0)delay/=2;if(!av.tank&&av.weapon>=8&&av.hero==0)delay=delay*4/5;if(delay<2)delay=2;if((uint16_t)(av.frame-av.shot_at)<delay)return;
 av.shot_at=av.frame;av.energy-=cost;av.fallback=fallback?25:0;if(av.perks[6]&&av_rand()%10<av.perks[6])damage*=2;if(!av.tank&&av.weapon>=8){av_melee(av.weapon,damage);return;}if(av.perks[9])flags|=AP_PIERCE;av_emit(av.px,av.py,av.aim,w->speed,damage,flags,0);if(av.weapon==2&&!fallback)for(i=-1;i<=1;i+=2)av_emit(av.px,av.py,(av.aim+i)&15,w->speed,damage,flags,0);
}

static void av_skill(void){int i,dir;if(av.skill_cd)return;av_mark_actors();av.skill_cd=av.tank?300:330;av.skill_cd-=av.perks[10]*25;av.skill_active=70;console_beep(HAL_GetTick(),40);
 if(av.tank){if(av.hero==1)av.invul=100;else if(av.hero==2)for(i=-2;i<=2;i++)av_emit(av.px,av.py,av.aim+i,72,10,AP_BLAST,0);else if(av.hero==3){for(i=0;i<5;i++)av_emit(av.px,av.py,av.aim,120,5,AP_PIERCE,0);av.skill_active=90;}}
 else if(av.hero==1){av.turret_life=230;av.turret_x=av.px;av.turret_y=av.py;av.turret_clock=0;}else if(av.hero==2){av.roll_boost=90;av.invul=24;dir=sticks.move>=0?sticks.move:av.body;for(i=0;i<24;i++)av_move(&av.px,&av.py,stick_dx[dir]*3/16,stick_dy[dir]*3/16);}
 av_fx(av.px/16,av.py/16,20);
}
static void av_blast(int x,int y,int damage){int i;av_fx(x,y,22);for(i=0;i<AV_ENEMIES;i++)if(av.enemies[i].hp&&av_dist(x,y,av.enemies[i].x/16,av.enemies[i].y/16)<32)av_damage(i,damage,0);if(av.boss&&av_dist(x,y,av.bx/16,av.by/16)<42)av.boss_hp=av.boss_hp>damage?av.boss_hp-damage:0;}
static void av_projectiles(void){int i,j,step,x,y,t,hit;av_bullet *p;for(i=0;i<AV_BULLETS;i++){p=&av.bullets[i];if(!p->life)continue;p->life--;for(step=0;step<2&&p->life;step++){p->x+=p->vx/2;p->y+=p->vy/2;x=p->x/16;y=p->y/16;if(x<1||x>=319||y<1||y>=175){p->life=0;break;}t=(y/16)*20+x/16;hit=av.map[t];if(hit==1||hit==2||hit==5){if(hit==1){av.map[t]=0;av_wall_changed(t);}if(hit==5&&av.tank&&av.mode==0){if(av.base_hp)av.base_hp--;if(!av.base_hp){av_end(0);return;}}if(p->bounce&&hit!=5){int oldx=(p->x-p->vx/2)/16,oldy=(p->y-p->vy/2)/16;if(oldx/16!=x/16)p->vx=-p->vx;if(oldy/16!=y/16)p->vy=-p->vy;p->bounce--;p->x=(oldx*16);p->y=(oldy*16);}else p->life=0;if(p->flags&AP_BLAST)av_blast(x,y,p->damage);continue;}
 if(p->enemy){if(abs(x-av.px/16)<8&&abs(y-av.py/16)<9){p->life=0;av_hurt(p->damage);if(av.state!=AV_PLAY)return;}}
 else{for(j=0;j<AV_ENEMIES&&p->life;j++)if(av.enemies[j].hp&&!(p->hit&(1<<j))&&abs(x-av.enemies[j].x/16)<9&&abs(y-av.enemies[j].y/16)<10){p->hit|=1<<j;if(p->flags&AP_BLAST){av_blast(x,y,p->damage);p->life=0;}else{av_damage(j,p->damage,p->flags);if(!(p->flags&AP_PIERCE))p->life=0;}}
 if(p->life&&av.boss&&!(p->hit&256)&&abs(x-av.bx/16)<20&&abs(y-av.by/16)<19){p->hit|=256;av.boss_hp=av.boss_hp>p->damage?av.boss_hp-p->damage:0;if(p->flags&AP_BLAST)av_fx(x,y,22);if(!(p->flags&AP_PIERCE))p->life=0;}}
 }} }
static void av_spawn(void){int i,j,k,t;av_enemy *e;for(i=0;i<AV_ENEMIES;i++)if(!av.enemies[i].hp){for(k=0;k<100;k++){t=22+av_rand()%176;if(av.map[t]||av.nav[t]==255||av_dist(t%20*16+8,t/20*16+8,av.px/16,av.py/16)<90)continue;e=&av.enemies[i];memset(e,0,sizeof *e);for(j=0;j<AV_BULLETS;j++)av.bullets[j].hit&=~(1<<i);e->x=(t%20*16+8)*16;e->y=(t/20*16+8)*16;e->type=av_rand()%6;e->hp=3+av.floor+(e->type==5?5:0)+(av.tank?2:0);av.spawned++;return;}return;}}
static void av_enemies(void){int i,d,speed,dist;av_enemy *e;for(i=0;i<AV_ENEMIES;i++){e=&av.enemies[i];if(!e->hp)continue;e->clock++;if(e->slow)e->slow--;if(e->flash)e->flash--;dist=av_dist(e->x,e->y,av.px,av.py);d=av_seek(e);speed=av.tank?13:15;if(e->slow)speed/=2;
 if(e->type==2){if(e->clock%90==65)e->dir=stick_direction(av.px-e->x,av.py-e->y);if(e->clock%90>72){d=e->dir;speed=65;}else if(e->clock%90>60)speed=0;}
 else e->dir=stick_direction(av.px-e->x,av.py-e->y);
 if(e->type==3)speed=0;if(e->type==1&&dist<900)speed=-speed;
 if(e->type==4&&e->clock%150==0&&av.total<40){av.total++;}
 if(speed)av_move(&e->x,&e->y,stick_dx[d]*speed/256,stick_dy[d]*speed/256);
 if((e->type==1||e->type==3||e->type==5||av.tank)&&e->clock%(70-av.floor*5)==0){d=e->dir;if(av.tank&&av.mode==0)d=stick_direction(168*16-e->x,152*16-e->y);av_emit(e->x,e->y,d,36+av.floor*2,1,0,1);if(e->type==3){av_emit(e->x,e->y,d-1,36,1,0,1);av_emit(e->x,e->y,d+1,36,1,0,1);}}
 if(av_dist(e->x,e->y,av.px,av.py)<190){av_hurt(1);if(av.state!=AV_PLAY)return;}
 }}
static void av_boss_step(void){int dir,i,phase,period;if(!av.boss||!av.boss_hp)return;av.boss_clock++;phase=av.boss_hp*3/av.boss_max;dir=stick_direction(av.px-av.bx,av.py-av.by);av.boss_dir=dir;period=phase==0?24:phase==1?37:50;
 if(av.floor==0||av.floor==4||av.tank){if(av.boss_clock%150>115)av_move(&av.bx,&av.by,stick_dx[dir]/8,stick_dy[dir]/8);}
 else{av_move(&av.bx,&av.by,(av.boss_clock/80)%2?12:-12,0);}
 if(av.boss_clock%period==0){if(av.floor==3){for(i=0;i<16;i+=2)av_emit(av.bx,av.by,i+av.boss_clock/period,30,1,0,1);}else for(i=-1-phase%2;i<=1+phase%2;i++)av_emit(av.bx,av.by,dir+i,38,1,0,1);}
 if((av.floor==1||av.floor==2)&&av.boss_clock%200==0&&av.total<30){av.total+=2;}
 if(!av.tank&&(av.floor==1||av.floor==2)&&av.boss_clock%80==0){for(i=0;i<4;i++)if(!av.hazards[i].life){av.hazards[i].x=av.px/16;av.hazards[i].y=av.py/16;av.hazards[i].life=45;break;}}
 if(av_dist(av.px,av.py,av.bx,av.by)<380)av_hurt(2);
}
static void av_perk(int n){if(av.perks[n]<4)av.perks[n]++;if(n==0){av.maxhp+=2;av.hp=av_clamp(av.hp+2,0,av.maxhp);}if(n==4){av.maxarmor++;av.armor=av.maxarmor;}if(n==5){av.maxenergy+=5;av.energy=av.maxenergy;}if(n==8){av.armor=av.maxarmor;av.invul=50;}}
static void av_transition(int state){av.state=state;av.armed=0;sticks_reset();av_scene();}
static void av_clear(void){int i,j;av.score+=100+av.floor*40;if(av.boss&&!av.tank){av.boss_mask|=1<<av.floor;av.score+=1000;av_transition(AV_MEMORY);av_save();return;}
 if(av.tank){if(av.mode==1){av.wave++;av.total=av_clamp(6+av.wave*2,6,40);av.spawned=av.kills=0;av.room_frame=0;av.hp=av_clamp(av.hp+1,0,av.maxhp);return;}if(av.floor==4){av_end(1);return;}av.floor++;av.room=0;av.hp=av_clamp(av.hp+2,0,av.maxhp);av_room();av_transition(AV_COUNT);av.count_at=HAL_GetTick();return;}
 for(i=0;i<3;i++){do{av.choices[i]=av_rand()%12;for(j=0;j<i;j++)if(av.choices[j]==av.choices[i])break;}while(j<i);}av_transition(AV_REWARD);av_save();}
static void av_step(void){int speed,dir,i,alive=0;av_mark_actors();av.frame++;av.room_frame++;av.elapsed+=30;if(av.invul)av.invul--;if(av.skill_cd)av.skill_cd--;if(av.skill_active)av.skill_active--;if(av.melee_life)av.melee_life--;if(av.roll_boost)av.roll_boost--;if(av.fallback)av.fallback--;for(i=0;i<8;i++)if(av.effects[i].life)av.effects[i].life--;
 for(i=0;i<4;i++)if(av.hazards[i].life){av.hazards[i].life--;if(av.hazards[i].life&&av.hazards[i].life<16&&abs(av.px/16-av.hazards[i].x)<18&&abs(av.py/16-av.hazards[i].y)<18){av_hurt(1);if(av.state!=AV_PLAY)return;}}
 if(av.frame%10==0&&av.energy<av.maxenergy)av.energy++;if(av.frame%33==0&&(uint16_t)(av.frame-av.hurt_at)>165&&av.armor<av.maxarmor)av.armor++;
 if(sticks.move>=0){av.body=sticks.move;speed=(av.tank?(av.hero==1?18:av.hero==3?29:24):(av.hero==2?30:25))+av.perks[3]*3;if(av.tank&&av.skill_active&&av.hero==0)speed+=12;speed=speed*sticks.power/255;if(av.map[(av.py/256)*20+av.px/256]==4)speed/=2;av.ice_vx=stick_dx[av.body]*speed/256;av.ice_vy=stick_dy[av.body]*speed/256;}else if(av.tank&&av.mapchoice==3){av.ice_vx=av.ice_vx*7/8;av.ice_vy=av.ice_vy*7/8;}else av.ice_vx=av.ice_vy=0;
 av_move(&av.px,&av.py,av.ice_vx,av.ice_vy);av.aim=sticks.aim;if(sticks.fire)av_fire();
 if(av.frame%12==1)av_flow();if(av.spawned<av.total&&av.room_frame%(!av.tank&&av.floor==0?36:24)==1)av_spawn();av_enemies();if(av.state!=AV_PLAY)return;av_boss_step();if(av.state!=AV_PLAY)return;av_projectiles();if(av.state!=AV_PLAY)return;
 if(av.turret_life){av.turret_life--;if(++av.turret_clock%12==0){for(i=0;i<AV_ENEMIES;i++)if(av.enemies[i].hp)break;if(i<AV_ENEMIES){dir=stick_direction(av.enemies[i].x-av.turret_x,av.enemies[i].y-av.turret_y);av_emit(av.turret_x,av.turret_y,dir,85,2,0,0);}else if(av.boss)av_emit(av.turret_x,av.turret_y,stick_direction(av.bx-av.turret_x,av.by-av.turret_y),85,2,0,0);}}
 for(i=0;i<AV_ENEMIES;i++)if(av.enemies[i].hp)alive++;
 if(av.tank&&av.mode==2){if(abs(av.px/16-160)<32&&abs(av.py/16-88)<24){if(av.capture<1000)av.capture++;}if(av.capture>=1000){av_clear();return;}if(av.spawned==av.total&&!alive){av.spawned=av.kills=0;av.total=6;}}
 else if(av.boss?!av.boss_hp:av.spawned>=av.total&&!alive){av_clear();return;}
 av_mark_actors();av_render();if(av.frame%6==0)av_hud();if(av.frame%3==0)av_controls();
}
/* Twelve pillar templates, five palettes. Main corridors remain open. */
static void av_room(void){int i,x,y,t,variant=av_rand()%12;memset(av.map,0,sizeof av.map);memset(av.enemies,0,sizeof av.enemies);memset(av.bullets,0,sizeof av.bullets);memset(av.effects,0,sizeof av.effects);av.boss=0;av.melee_life=0;av.spawned=av.kills=av.room_frame=0;av.capture=0;av.turret_life=0;av.ice_vx=av.ice_vy=0;av.px=160*16;av.py=144*16;av.base_hp=3;av.bx=160*16;av.by=48*16;
 memset(av.hazards,0,sizeof av.hazards);
 for(y=0;y<11;y++)for(x=0;x<20;x++){t=y*20+x;if(x==0||x==19||y==0||y==10)av.map[t]=2;else if(x>2&&x<17&&y>1&&y<8&&x!=9&&x!=10&&y!=5){if((x+variant)%(av.tank&&av.mapchoice==2?6:4)==0&&(y+variant/4)%3==0)av.map[t]=av.tank?(av.mapchoice==1?3:av.mapchoice==4?2:1):((x+y+variant)%3==0?1:2);else if(av.tank&&av.mapchoice==1&&(x+y)%7==0)av.map[t]=4;}}
 for(y=1;y<10;y++){av.map[y*20+9]=0;av.map[y*20+10]=0;}for(x=1;x<19;x++)av.map[5*20+x]=0;
 av.total=av.tank?6+av.floor*2:5+av.floor+av.room*2;if(av.tank&&av.mode==0){av.map[9*20+10]=5;av.px=136*16;}
 if((!av.tank&&av.room>=3)||(av.tank&&av.mode==3)){av.boss=1;av.boss_hp=av.boss_max=45+av.floor*15;av.total=av.tank?2:0;for(y=1;y<5;y++)for(x=6;x<14;x++)av.map[y*20+x]=0;av.boss_clock=0;}
 av_flow();for(i=0;i<AV_CELLS;i++)av.dirty[i]=1;av.invul=35;
}
static void av_begin(uint32_t now){int hero=av.hero,tank=av.tank,mode=av.mode,map=av.mapchoice;uint32_t seed=av.seed;memset(&av,0,sizeof av);av.hero=hero;av.tank=tank;av.mode=mode;av.mapchoice=map;av.seed=seed;av.maxhp=tank?(hero==1?12:hero==3?6:8):hero==2?6:8;av.hp=av.maxhp;av.maxarmor=tank?0:hero==1?4:3;av.armor=av.maxarmor;av.maxenergy=av.energy=30;av.weapon=tank?(hero==1?3:hero==2?4:hero==3?5:0):0;av.second=tank?0:hero==1?10:hero==2?11:8;av.body=av.aim=12;av.screen_w=lcddev.width;av.screen_y=40;av.screen_h=sticks.top-40;av.last=now;av.wave=1;if(tank)console_started(10);else{if(ember_stats.plays<255)ember_stats.plays++;if(av.weapon<8)ember_stats.weapons|=1<<av.weapon;}av_room();av_transition(tank?AV_COUNT:AV_STORY);av.count_at=now;av_save();}
static int av_art_scale,av_art_x,av_art_y;
static void av_title_paint(int x,int y,int w,int h,uint16_t c){x=av_art_x+x*av_art_scale;y=av_art_y+y*av_art_scale;lcd_fill(x,y,x+w*av_art_scale-1,y+h*av_art_scale-1,c);}
static void av_flame_title(void){int w=lcddev.width,h=lcddev.height,large=h>=400,cx=w/4,base=h-42,i,xx,yy,r,top=large?138:65,step=large?57:38;const char *keys[5]={"BEGIN_ADVENTURE","SELECT_HERO","WEAPON_CODEX","RECORDS","HOME"};
 av_center(large?48:36,"CAVALIER'S FLAME",0xcddd);
 /* Ruined sanctuary framing a single red-cloaked keeper. */
 for(i=0;i<5;i++){xx=16+i*(large?70:40);yy=large?118:84;lcd_fill(xx,yy+(i%2)*17,xx+(large?22:13),base,0x1906);lcd_fill(xx,yy+(i%2)*17,xx+(large?22:13),yy+(i%2)*17+3,0x4a2b);}
 lcd_fill(10,base,w/2-10,base+6,0x4a2b);lcd_fill(16,base+7,w/2-16,base+10,0x2908);
 av_art_scale=large?5:3;av_art_x=cx;av_art_y=base-11*av_art_scale;flame_hero(0,0,av.hero,0,0,0,av_title_paint);
 for(i=0;i<12;i++){xx=24+(i*37)%(w/2-45);yy=70+(i*43)%(base-80);r=i%3?1:2;lcd_fill(xx,yy,xx+r,yy+r,i%2?0xca85:0x7a46);}
 for(i=0;i<5;i++)av_btn(i,w/2+10,top+i*step,w/2-26,step-4,keys[i]);
 av_text(14,h-23,w/2-24,12,"FLAME_MOTTO",0xc493);
}
static void av_scene(void){char b[100];int w=lcddev.width,h=lcddev.height,large=h>=400,y,i,step=large?52:38,top=large?165:92;const char *key;
 if(av.state==AV_PLAY){lcd_clear(AV_BG);memset(av.dirty,1,sizeof av.dirty);av_render();av_hud();av_controls();return;}
 lcd_clear(AV_BG);memset(av.buttons,0,sizeof av.buttons);av_center(12,av.tank?"TANK_V6":"FLAME",AV_GOLD);
 if(av.state==AV_RECORD&&!av.tank){int bosses=0,ends=0;for(i=0;i<5;i++)bosses+=(ember_stats.boss_end>>i)&1;for(i=5;i<8;i++)ends+=(ember_stats.boss_end>>i)&1;sprintf(b,"BOSS %u/5     END %u/3",bosses,ends);av_text(w/2-100,large?330:214,200,12,b,AV_GOLD);}
 if(av.state==AV_TITLE&&!av.tank){av_flame_title();return;}
 if(av.state==AV_TITLE){if(!large)top=68;av_center(large?60:40,av.tank?"TANK_TAG":"CAVALIER'S FLAME",AV_CYAN);if(large){av_center(104,"FLAME_MOTTO",0xce59);}av_btn(0,w/2-110,top,220,step-4,"BEGIN_ADVENTURE");av_btn(1,w/2-110,top+step,220,step-4,"SELECT_HERO");av_btn(2,w/2-110,top+step*2,220,step-4,av.tank?"TANK_GUIDE":"WEAPON_CODEX");av_btn(3,w/2-110,top+step*3,220,step-4,"RECORDS");av_btn(4,w/2-110,top+step*4,220,step-4,"HOME");return;}
 if(av.state==AV_SELECT){av_center(48,av.tank?av_tanks[av.hero]:av_heroes[av.hero],AV_CYAN);av_center(large?93:72,av.tank?(av.hero==0?"SK_ASSAULT":av.hero==1?"SK_HEAVY":av.hero==2?"SK_ROCKET":"SK_LASER"):(av.hero==0?"SK_KNIGHT":av.hero==1?"SK_ENGINEER":"SK_RANGER"),WHITE);av_btn(0,12,top,w/2-18,step-4,"CHANGE_HERO");av_btn(1,w/2+6,top,w/2-18,step-4,"START");if(av.tank){av_btn(2,12,top+step,w-24,step-4,av_modes[av.mode]);av_btn(3,12,top+step*2,w-24,step-4,av_maps[av.mapchoice]);}av_btn(4,12,h-40,w-24,30,"BACK");return;}
 if(av.state==AV_CODEX){for(i=0;i<(av.tank?4:12);i++){y=52+(av.tank?i:i%6)*(large?50:28);key=av.tank?(i==0?"CONTROL_HELP":i==1?"TANK_MODES_HELP":i==2?"TANK_MAPS_HELP":"TANK_SKILLS_HELP"):av_weapons[i].name;av_text(av.tank?20:20+(i/6)*(w/2),y,av.tank?w-40:w/2-30,16,key,av.tank||i>=8||(ember_stats.weapons&(1<<i))?AV_CYAN:0x632c);}av_btn(4,12,h-35,w-24,28,"BACK");return;}
 if(av.state==AV_RECORD){sprintf(b,"%lu",(unsigned long)(av.tank?console_best(10):ember_stats.score));av_center(60,"BEST",WHITE);av_center(large?104:84,b,AV_GOLD);sprintf(b,"%u / %u",av.tank?console_plays(10):ember_stats.plays,av.tank?console_wins(10):ember_stats.wins);av_center(large?155:115,"PLAYS_WINS",WHITE);av_center(large?193:140,b,AV_CYAN);if(!av.tank){sprintf(b,"%u / %u / %u",ember_stats.floors[0],ember_stats.floors[1],ember_stats.floors[2]);av_center(large?246:169,"HERO_FLOORS",WHITE);av_center(large?282:193,b,AV_CYAN);}av_btn(4,12,h-40,w-24,30,"BACK");return;}
 if(av.state==AV_STORY||av.state==AV_MEMORY||av.state==AV_SECRET){av_center(large?68:44,av_chapters[av.floor],AV_CYAN);if(av.state==AV_STORY){av_center(large?132:84,"INTRO_1",WHITE);av_center(large?170:112,"INTRO_2",WHITE);av_center(large?208:140,"INTRO_3",WHITE);av_center(large?246:168,"INTRO_4",AV_GOLD);}else{char k[20];sprintf(k,av.state==AV_SECRET?"SECRET_%u_A":"MEMORY_%u_A",av.floor);av_center(large?140:90,k,WHITE);sprintf(k,av.state==AV_SECRET?"SECRET_%u_B":"MEMORY_%u_B",av.floor);av_center(large?190:125,k,WHITE);av_center(large?240:160,av.state==AV_SECRET?"MEMORY_FOUND":av_boss_names[av.floor],AV_GOLD);}av_btn(0,12,h-55,w-24,42,"CONTINUE");return;}
 if(av.state==AV_COUNT){av_center(h/2-30,"READY_HELP",WHITE);sprintf(b,"%u",3-(unsigned)((HAL_GetTick()-av.count_at)/1000>2?2:(HAL_GetTick()-av.count_at)/1000));av_center(h/2+5,b,AV_GOLD);return;}
 if(av.state==AV_PAUSE){av_center(55,"GAME PAUSED",AV_CYAN);av_btn(0,w/2-110,top,220,step-4,"RESUME");av_btn(1,w/2-110,top+step,220,step-4,"RESTART");av_btn(4,w/2-110,top+step*2,220,step-4,"HOME");return;}
 if(av.state==AV_REWARD){av_center(large?75:48,"CHOOSE_PERK",AV_CYAN);for(i=0;i<3;i++)av_btn(i,20,top+i*(step+6),w-40,step,av_perks[av.choices[i]]);return;}
 if(av.state==AV_ROUTE){av_center(large?70:48,"CHOOSE_ROUTE",AV_CYAN);av_btn(0,20,top,w-40,step,"ROUTE_BATTLE");av_btn(1,20,top+step+8,w-40,step,"ROUTE_CHEST");av_btn(2,20,top+2*(step+8),w-40,step,"ROUTE_SHOP");return;}
 if(av.state==AV_CHEST){av_center(large?80:48,"FOUND_WEAPON",WHITE);av_center(large?125:75,av_weapons[av.room_weapon].name,AV_GOLD);av_btn(0,20,top+step,w-40,step,"TAKE_WEAPON");av_btn(1,20,top+2*step+8,w-40,step,"KEEP_WEAPON");return;}
 if(av.state==AV_SHOP){sprintf(b,"$ %u",av.coins);av_center(large?65:48,b,AV_GOLD);av_btn(0,20,top,w-40,step,"BUY_HEALTH");av_btn(1,20,top+step+8,w-40,step,"BUY_WEAPON");av_btn(2,20,top+2*(step+8),w-40,step,"LEAVE_SHOP");return;}
 if(av.state==AV_END_CHOICE){av_center(large?75:48,"FINAL_QUESTION",WHITE);av_btn(0,20,top,w-40,step,"ENDING_LIGHT");av_btn(1,20,top+step+8,w-40,step,"ENDING_SCATTER");av_btn(2,20,top+2*(step+8),w-40,step,av.memories==31?"ENDING_KEEPER":"MEMORIES_MISSING");return;}
 if(av.state==AV_END){av_center(large?65:45,av.won?"YOU WIN!":"GAME OVER",av.won?AV_GOLD:0xf986);sprintf(b,"%lu",(unsigned long)av.score);av_center(large?110:73,b,AV_CYAN);if(av.won&&!av.tank){av_center(large?158:101,av.ending==0?"END_LIGHT_TEXT":av.ending==1?"END_SCATTER_TEXT":"END_KEEPER_TEXT",WHITE);}av_btn(0,20,large?270:145,w-40,step,"PLAY AGAIN");av_btn(4,20,large?338:196,w-40,step,"HOME");if(ember_error()||console_save_error())av_text(12,h-18,w-24,12,"SAVE_ERROR",0xf800);return;}
}
void adventure_start(uint8_t tank,uint32_t now,uint32_t seed){memset(&av,0,sizeof av);av.tank=tank;av.seed=seed?seed:1;av.last=now;sticks_init();ember_load();av.state=AV_TITLE;av_scene();}
static void av_next_room(uint32_t now){av_room();av.count_at=now;av_transition(AV_COUNT);}
uint8_t adventure_tick(uint32_t now,uint16_t x,uint16_t y,uint8_t press,uint8_t down){int i;sticks_sample(x,y,down);if(av.state==AV_PLAY){if(sticks.pause_press){av_save();av_transition(AV_PAUSE);return 0;}if(sticks.skill_press)av_skill();if(sticks.swap_press&&!av.tank){i=av.weapon;av.weapon=av.second;av.second=i;av.fallback=0;av_hud();av_controls();}if((uint32_t)(now-av.last)>=30){av.last=now;av_step();}return 0;}
 if(!down)av.armed=1;if(av.state==AV_COUNT){if(now-av.count_at>=3000){av.last=now;av_transition(AV_PLAY);}else if(now-av.hud_at>=500){av.hud_at=now;av_scene();}return 0;}
 if(!press||!av.armed)return 0;for(i=0;i<6;i++)if(av.buttons[i].w&&v6_hit(av.buttons[i],x,y))break;if(i==6)return 0;
 if(av.state==AV_TITLE){if(i==0)av_begin(now);else if(i==1)av_transition(AV_SELECT);else if(i==2)av_transition(AV_CODEX);else if(i==3)av_transition(AV_RECORD);else return 1;}
 else if(av.state==AV_SELECT){if(i==0){av.hero=(av.hero+1)%(av.tank?4:3);av_scene();}else if(i==1)av_begin(now);else if(i==2){av.mode=(av.mode+1)%4;av_scene();}else if(i==3){av.mapchoice=(av.mapchoice+1)%5;av_scene();}else av_transition(AV_TITLE);}
 else if(av.state==AV_CODEX||av.state==AV_RECORD)av_transition(AV_TITLE);
 else if(av.state==AV_STORY){av.count_at=now;av_transition(AV_COUNT);}
 else if(av.state==AV_PAUSE){if(i==0){av.count_at=now;av_transition(AV_COUNT);}else if(i==1)av_begin(now);else return 1;}
 else if(av.state==AV_REWARD){av_perk(av.choices[i]);av.room++;av_transition(AV_ROUTE);}
 else if(av.state==AV_ROUTE){if(i==0){av_next_room(now);}else if(i==1){av.room_weapon=1+av_rand()%11;av_transition(AV_CHEST);}else av_transition(AV_SHOP);}
 else if(av.state==AV_CHEST){if(i==0){av.second=av.weapon;av.weapon=av.room_weapon;if(av.weapon<8)ember_stats.weapons|=1<<av.weapon;}av_transition(AV_SECRET);}
 else if(av.state==AV_SECRET){av.memories|=1<<av.floor;av_next_room(now);}
 else if(av.state==AV_SHOP){if(i==0&&av.coins>=8&&av.hp<av.maxhp){av.coins-=8;av.hp=av_clamp(av.hp+4,0,av.maxhp);av_scene();}else if(i==1&&av.coins>=12){av.coins-=12;av.second=av.weapon;av.weapon=1+av_rand()%11;if(av.weapon<8)ember_stats.weapons|=1<<av.weapon;av_scene();}else if(i==2)av_next_room(now);}
 else if(av.state==AV_MEMORY){if(av.tank){if(av.floor==4)av_end(1);else{av.floor++;av_next_room(now);}}else if(av.floor==4)av_transition(AV_END_CHOICE);else{av.floor++;av.room=0;av.hp=av_clamp(av.hp+2,0,av.maxhp);av.energy=av.maxenergy;av_next_room(now);}}
 else if(av.state==AV_END_CHOICE){if(i<2||av.memories==31){av.ending=i;av_end(1);}}
 else if(av.state==AV_END){if(i==0)av_transition(AV_SELECT);else return 1;}
 return 0;
}
