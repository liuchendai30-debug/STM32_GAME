#ifndef ADVENTURE_H
#define ADVENTURE_H
#include <stdint.h>
void adventure_start(uint8_t tank,uint32_t now,uint32_t seed);
uint8_t adventure_tick(uint32_t now,uint16_t x,uint16_t y,uint8_t press,uint8_t down);
#endif
