#include "arcade.h"
#include "ui_zh.h"
#include "console_service.h"
#include "combat.h"
#include "adventure.h"
#include "./BSP/LCD/lcd.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#define BG 0x0841
#define PANEL 0x10a2
#define EDGE 0x4a69
#define ACCENT 0x07ff
#define INK 0xffff
#define GOLD 0xffe0
#define BAD 0xf986
typedef struct {int16_t x,y,w,h;} rect_t;
typedef struct {uint8_t x[320],y[320],dir,pending,fx,fy,combo;uint16_t len,eaten;uint32_t food_at;} snake_t;
typedef struct {uint8_t cells[20][10],paint[20][10],kind,next,rot,hold,held_once,bag[7],bag_at,combo;int8_t x,y;uint16_t lines;} tetris_t;
typedef struct {uint32_t v[25],undo[25],undo_score,target;uint16_t moves;uint8_t reached,can_undo;} puzzle_t;
typedef struct {uint8_t bombs[120],open[120],flags[120],placed,flag_mode,revealed,long_done;int16_t touch_cell,last_cell;uint32_t touch_at,last_at;} mines_t;
typedef struct {int8_t v[16],turn;uint8_t ai_pending;uint32_t ai_time;} xo_t;
typedef struct {uint8_t v[25],blank;uint16_t moves;} slide_t;
typedef struct {uint8_t v[16],matched[16],first,second,pairs,combo;uint16_t turns,bonus;uint32_t hide_at;} memory_t;
/* Fixed logical playfield, independent of LCD resolution. Positions use Q8. */
typedef struct {int32_t y,vy;int16_t pipe_x,gap_y;uint8_t passed,gap;uint16_t shield;} bird_t;
typedef struct {int16_t obstacle_y;uint8_t lane,obstacle_lane,fuel,car;uint16_t fuel_at;uint32_t boost_until;} racer_t;
enum {PLAY,READY,PAUSED,OVER,COUNTDOWN};
static struct {
    uint8_t id,state,resume,won,cols,rows,diff,mode,mine_count,held,started,variant;
    uint32_t score,last,seed,elapsed,tick,hud_at,repeat_at,flash_until,count_at;
    uint32_t clear_mask;
    int16_t bx,by,cell,sx,sw,gesture_x,gesture_y;
    uint8_t gesture;
    rect_t controls[6],pause,modal[3],choices[2];
    union {snake_t snake;tetris_t tet;puzzle_t puzzle;mines_t mines;xo_t xo;slide_t slide;memory_t memory;bird_t bird;racer_t racer;} g;
} a;
static const char *titles[12]={"BRICKS","SNAKE","TETRIS","2048","MINES","XO","SLIDE","MEMORY","BIRD","RACER","TANK","SPACE"};
static uint32_t daily_seed;
static uint8_t variants[10];
void arcade_set_daily(uint32_t seed){daily_seed=seed;}
static const int8_t dx[4]={0,1,0,-1},dy[4]={-1,0,1,0};
static uint32_t rng(void) {uint32_t x=a.seed;x^=x<<13;x^=x>>17;x^=x<<5;return a.seed=x?x:0x12345678;}
static uint8_t inside(rect_t r,uint16_t x,uint16_t y){return x>=r.x && y>=r.y && x<r.x+r.w && y<r.y+r.h;}
static void fill(int x,int y,int w,int h,uint16_t c){if(w>0 && h>0)lcd_fill(x,y,x+w-1,y+h-1,c);}
static void center(rect_t r,uint8_t size,const char *s,uint16_t fg,uint16_t bg){
    int w=zh_width(s,size),x=r.x+(r.w-w)/2,y=r.y+(r.h-size)/2;
    if(x<r.x)x=r.x;if(y<r.y)y=r.y;
    zh_draw(x,y,r.x+r.w-x,r.y+r.h-y,size,s,fg,bg);
}
static void button(rect_t r,const char *s,uint16_t c){fill(r.x,r.y,r.w,r.h,PANEL);lcd_draw_rectangle(r.x,r.y,r.x+r.w-1,r.y+r.h-1,c);center(r,16,s,INK,PANEL);}
static void number(int x,int y,int w,uint32_t n,uint16_t fg){char b[16];sprintf(b,"%lu",(unsigned long)n);zh_draw(x,y,w,20,16,b,fg,BG);}
void arcade_result_panel(uint8_t id,uint8_t won,uint32_t score,uint32_t best_score){
    rect_t r;char b[64];int large=lcddev.height>=400;
    lcd_clear(BG);r.x=0;r.y=8;r.w=lcddev.width;r.h=32;center(r,16,titles[id],ACCENT,BG);
    r.y=large?60:44;r.h=32;center(r,24,won==3?"O_WIN":won==4?"X_WIN":won==2?"DRAW":won?"YOU WIN!":"GAME OVER",won?GOLD:INK,BG);
    zh_draw(lcddev.width/2-90,large?106:82,68,20,16,"SCORE",INK,BG);number(lcddev.width/2,large?106:82,110,score,ACCENT);
    zh_draw(lcddev.width/2-90,large?136:104,68,20,16,"BEST",INK,BG);number(lcddev.width/2,large?136:104,110,best_score,GOLD);
    if(large){int i,n=0;for(i=0;i<12;i++)n+=console_medal(i);sprintf(b,"%u / 36",n);zh_draw(lcddev.width/2-90,170,80,20,16,"TROPHIES",GOLD,BG);zh_draw(lcddev.width/2,170,100,20,16,b,GOLD,BG);}
}
static void tile(int col,int row,uint16_t color,const char *label,uint16_t fg){
    rect_t r;r.x=a.bx+col*a.cell;r.y=a.by+row*a.cell;r.w=r.h=a.cell;
    fill(r.x+1,r.y+1,r.w-2,r.h-2,color);
    if(label)center(r,a.cell>=50?24:16,label,fg,color);
}
static uint8_t tet_bit(uint8_t kind,uint8_t rot,int x,int y);
static void hud(void){
    char info[64];int i,n=0,px,py;
    fill(a.sx,58,a.sw,lcddev.height>=400?112:68,BG);
    zh_draw(a.sx,60,40,20,16,"SCORE",INK,BG);number(a.sx+42,60,a.sw-42,a.score,ACCENT);
    zh_draw(a.sx,84,40,20,16,"BEST",INK,BG);number(a.sx+42,84,a.sw-42,console_best(a.id)>a.score?console_best(a.id):a.score,GOLD);
    zh_draw(a.sx,108,a.sw,18,12,a.id==8?"BIRD_HELP":a.id==9?"RACER_HELP":a.id==6?"SLIDE_HELP":a.id==7?"MEMORY_HELP":a.id==1?"SNAKE_HELP":a.id==2?"TETRIS_HELP":a.id==3?"PUZZLE_HELP":a.id==4?"MINE_HELP":"XO_HELP",INK,BG);
    if(a.id==2){
        fill(a.sx,108,a.sw,18,BG);
        zh_draw(a.sx,108,24,18,12,"LEVEL",GOLD,BG);sprintf(info,"%u",1+a.g.tet.lines/10);
        zh_draw(a.sx+28,108,30,18,12,info,GOLD,BG);zh_draw(a.sx+65,108,48,18,12,"NEXT_PIECE",GOLD,BG);
        px=a.sx+a.sw-30;py=107;fill(px,py,28,20,BG);
        for(i=0;i<16;i++)if(tet_bit(a.g.tet.next,0,i%4,i/4))fill(px+(i%4)*6,py+(i/4)*5,5,4,ACCENT);
        zh_draw(a.sx,130,64,16,12,"HELD_PIECE",GOLD,BG);
        fill(a.sx+68,129,28,20,BG);
        if(a.g.tet.hold<7)for(i=0;i<16;i++)if(tet_bit(a.g.tet.hold,0,i%4,i/4))fill(a.sx+68+(i%4)*6,129+(i/4)*5,5,4,a.g.tet.held_once?EDGE:ACCENT);
    }else if(a.id==4){
        for(i=0;i<a.cols*a.rows;i++)n+=a.g.mines.flags[i];
        fill(a.sx,108,a.sw,18,BG);zh_draw(a.sx,108,24,18,12,"TIME",GOLD,BG);
        sprintf(info,"%lu",(unsigned long)(a.elapsed/1000));zh_draw(a.sx+28,108,48,18,12,info,GOLD,BG);
        zh_draw(a.sx+88,108,24,18,12,"MINES_LEFT",GOLD,BG);sprintf(info,"%d",a.mine_count-n);zh_draw(a.sx+116,108,a.sw-116,18,12,info,GOLD,BG);
    }else if(a.id==1){fill(a.sx,108,a.sw,18,BG);sprintf(info,"x%u  %u / %u",a.g.snake.combo?a.g.snake.combo:1,a.g.snake.eaten,a.mode==5?10:a.mode==3?15:320);zh_draw(a.sx,108,a.sw,18,12,info,GOLD,BG);
    }else if(a.id==3){fill(a.sx,108,a.sw,18,BG);zh_draw(a.sx,108,30,16,12,"MOVES",INK,BG);sprintf(info,"%u",a.g.puzzle.moves);zh_draw(a.sx+34,108,70,16,12,info,GOLD,BG);
    }else if(a.id==9){fill(a.sx,108,a.sw,18,BG);zh_draw(a.sx,108,40,16,12,"FUEL",INK,BG);sprintf(info,"%u%%",a.g.racer.fuel);zh_draw(a.sx+44,108,70,16,12,info,GOLD,BG);
    }else if(a.id==5&&a.mode>=2){fill(a.sx,108,a.sw,18,BG);zh_draw(a.sx,108,a.sw,18,12,a.g.xo.turn==1?"TURN_X":"TURN_O",GOLD,BG);
    }else if(a.id==6||a.id==7){
        fill(a.sx,108,a.sw,18,BG);zh_draw(a.sx,108,24,18,12,"TIME",GOLD,BG);
        sprintf(info,"%lu",(unsigned long)(a.id==7&&a.variant?(a.elapsed>=90000?0:90-a.elapsed/1000):a.elapsed/1000));zh_draw(a.sx+28,108,48,18,12,info,GOLD,BG);
        zh_draw(a.sx+88,108,24,18,12,a.id==6?"MOVES":"TRIES",GOLD,BG);
        sprintf(info,"%u",a.id==6?a.g.slide.moves:a.g.memory.turns);zh_draw(a.sx+116,108,a.sw-116,18,12,info,GOLD,BG);
    }

}
static void draw_board(void);
static void scene(void);
static void finish(uint8_t won,uint32_t now){(void)now;a.won=won;a.state=OVER;a.gesture=0;console_record(a.id,a.score);if(won==1)console_won(a.id);console_flush();console_beep(HAL_GetTick(),won?100:180);scene();}

/* Snake: one queued turn per movement step, so rapid opposite taps cannot reverse. */
static uint8_t snake_wall(int x,int y){return a.mode==2 && (x==5||x==14) && y>=4&&y<=11;}
static uint8_t snake_food(void){
    uint16_t empty=0,pick=0,i,j;uint8_t occupied,pass;
    for(pass=0;pass<2;pass++){
        for(i=0;i<320;i++){
            occupied=snake_wall(i%20,i/20)||(a.mode==4&&(i==21||i==298));
            for(j=0;j<a.g.snake.len;j++)if(a.g.snake.x[j]==i%20 && a.g.snake.y[j]==i/20){occupied=1;break;}
            if(!occupied){if(!pass)empty++;else if(pick--==0){a.g.snake.fx=i%20;a.g.snake.fy=i/20;return 1;}}
        }
        if(!empty)return 0;if(!pass)pick=(uint16_t)(rng()%empty);
    }
    return 0;
}
static void snake_turn(uint8_t d){if(a.g.snake.pending==a.g.snake.dir && d!=(a.g.snake.dir+2)%4)a.g.snake.pending=d;}
static void snake_step(uint32_t now){
    snake_t *s=&a.g.snake;int x,y;uint16_t i,limit;uint8_t eat;uint8_t tx=s->x[s->len-1],ty=s->y[s->len-1];
    s->dir=s->pending;x=s->x[0]+dx[s->dir];y=s->y[0]+dy[s->dir];
    if(a.mode==1){x=(x+20)%20;y=(y+16)%16;}
    if(a.mode==4){if(x==1&&y==1){x=18;y=14;}else if(x==18&&y==14){x=1;y=1;}}
    if(x<0||x>=20||y<0||y>=16||snake_wall(x,y)){finish(0,now);return;}
    eat=(x==s->fx && y==s->fy);limit=s->len-(eat?0:1);
    for(i=0;i<limit;i++)if(s->x[i]==x && s->y[i]==y){finish(0,now);return;}
    tile(s->x[0],s->y[0],0x05e0,0,0);
    if(eat)s->len++;else tile(tx,ty,a.mode==4&&((tx==1&&ty==1)||(tx==18&&ty==14))?0xf81f:PANEL,0,0);
    for(i=s->len-1;i>0;i--){s->x[i]=s->x[i-1];s->y[i]=s->y[i-1];}s->x[0]=x;s->y[0]=y;
    tile(x,y,ACCENT,0,0);
    if(eat){s->eaten++;s->combo=a.elapsed-s->food_at<=6000?(s->combo<3?s->combo+1:3):1;a.score+=10*s->combo;s->food_at=a.elapsed;console_record(a.id,a.score);console_beep(now,35);if(s->len==320-(a.mode==2?16:0)||(a.mode==3&&s->eaten>=15)||(a.mode==5&&s->eaten>=10)){finish(1,now);return;}if(!snake_food()){finish(1,now);return;}tile(s->fx,s->fy,GOLD,0,0);hud();}
}

/* Seven tetrominoes, four rotations in 4x4 masks; simple horizontal wall kicks. */
static const uint16_t shapes[7][4]={
 {0x0f00,0x2222,0x00f0,0x4444}, {0x6600,0x6600,0x6600,0x6600},
 {0x4e00,0x4640,0x0e40,0x4c40}, {0x6c00,0x4620,0x06c0,0x8c40},
 {0xc600,0x2640,0x0c60,0x4c80}, {0x8e00,0x6440,0x0e20,0x44c0},
 {0x2e00,0x4460,0x0e80,0xc440}};
static uint8_t tet_bit(uint8_t kind,uint8_t rot,int x,int y){return (shapes[kind][rot]&(0x8000U>>(y*4+x)))!=0;}
static uint8_t tet_fits(int x,int y,uint8_t rot){int cx,cy,xx,yy;for(cy=0;cy<4;cy++)for(cx=0;cx<4;cx++)if(tet_bit(a.g.tet.kind,rot,cx,cy)){xx=x+cx;yy=y+cy;if(xx<0||xx>=10||yy>=20)return 0;if(yy>=0 && a.g.tet.cells[yy][xx])return 0;}return 1;}
static uint8_t tet_bag(void){tetris_t *t=&a.g.tet;int i,j;uint8_t v;if(t->bag_at>=7){for(i=0;i<7;i++)t->bag[i]=i;for(i=6;i>0;i--){j=rng()%(i+1);v=t->bag[i];t->bag[i]=t->bag[j];t->bag[j]=v;}t->bag_at=0;}return t->bag[t->bag_at++];}
static void tet_spawn(uint32_t now){tetris_t *t=&a.g.tet;t->kind=t->next;t->next=tet_bag();t->rot=0;t->x=3;t->y=0;t->held_once=0;if(!tet_fits(t->x,t->y,0))finish(0,now);}
static void tet_lock(uint32_t now){
    tetris_t *t=&a.g.tet;int x,y,r,full,cleared=0;
    for(y=0;y<4;y++)for(x=0;x<4;x++)if(tet_bit(t->kind,t->rot,x,y)){if(t->y+y<0){finish(0,now);return;}t->cells[t->y+y][t->x+x]=t->kind+1;}
    for(y=19;y>=0;y--){full=1;for(x=0;x<10;x++)if(!t->cells[y][x])full=0;if(full){a.clear_mask|=1UL<<y;for(r=y;r>0;r--)memcpy(t->cells[r],t->cells[r-1],10);memset(t->cells[0],0,10);cleared++;y++;}}
    if(cleared){static const uint16_t points[5]={0,100,300,500,800};a.flash_until=now+100;a.score+=points[cleared]+50*t->combo;if(t->combo<20)t->combo++;t->lines+=cleared;console_record(a.id,a.score);console_beep(now,60);}else t->combo=0;
    tet_spawn(now);
}
static void tet_action(uint8_t action,uint32_t now){
    tetris_t *t=&a.g.tet;int i;uint8_t rot;
    if(action==0||action==1){i=action==0?-1:1;if(tet_fits(t->x+i,t->y,t->rot))t->x+=i;}
    else if(action==2){rot=(t->rot+1)%4;for(i=0;i<5;i++){static const int8_t kicks[5]={0,-1,1,-2,2};if(tet_fits(t->x+kicks[i],t->y,rot)){t->x+=kicks[i];t->rot=rot;break;}}}
    else if(action==3||action==6){if(tet_fits(t->x,t->y+1,t->rot)){t->y++;if(action==3)a.score++;}else tet_lock(now);}
    else if(action==4){while(tet_fits(t->x,t->y+1,t->rot)){t->y++;a.score+=2;}tet_lock(now);}
    else if(action==5&&!t->held_once){
        uint8_t old=t->kind;
        if(t->hold==255)tet_spawn(now);
        else {t->kind=t->hold;t->rot=0;t->x=3;t->y=0;if(!tet_fits(t->x,t->y,0))finish(0,now);}
        t->hold=old;t->held_once=1;a.last=now;
    }
    if(a.state==PLAY){draw_board();hud();}
}

/* 2048: compress -> merge once -> compress; spawn only after a changed move. */
static void puzzle_spawn(void){uint8_t free_cells[25],n=0,i;for(i=0;i<a.cols*a.rows;i++)if(!a.g.puzzle.v[i])free_cells[n++]=i;if(n)a.g.puzzle.v[free_cells[rng()%n]]=(rng()%10)?2:4;}
static int puzzle_index(int line,int pos,int dir){int n=a.cols;return dir==3?line*n+pos:dir==1?line*n+n-1-pos:dir==0?pos*n+line:(n-1-pos)*n+line;}
static uint8_t puzzle_possible(void){int x,y,n=a.cols;uint32_t *v=a.g.puzzle.v;for(y=0;y<n;y++)for(x=0;x<n;x++)if(!v[y*n+x]||(x<n-1&&v[y*n+x]==v[y*n+x+1])||(y<n-1&&v[y*n+x]==v[y*n+x+n]))return 1;return 0;}
static void puzzle_move(uint8_t dir,uint32_t now){
    uint32_t old_score=a.score,before[25],tmp[5],res[5];int line,i,n,j,k;memcpy(before,a.g.puzzle.v,sizeof before);
    for(line=0;line<a.cols;line++){
        n=0;memset(res,0,sizeof res);for(i=0;i<a.cols;i++){uint32_t v=a.g.puzzle.v[puzzle_index(line,i,dir)];if(v)tmp[n++]=v;}
        j=0;for(i=0;i<n;i++){if(i+1<n && tmp[i]==tmp[i+1] && tmp[i]<0x40000000U){res[j]=tmp[i]*2;a.score+=res[j];i++;}else res[j]=tmp[i];j++;}
        for(k=0;k<a.cols;k++)a.g.puzzle.v[puzzle_index(line,k,dir)]=res[k];
    }
    if(memcmp(before,a.g.puzzle.v,sizeof before)!=0){if(a.g.puzzle.moves<65535)a.g.puzzle.moves++;memcpy(a.g.puzzle.undo,before,sizeof before);a.g.puzzle.undo_score=old_score;a.g.puzzle.can_undo=1;puzzle_spawn();console_record(a.id,a.score);console_beep(now,25);draw_board();hud();}
    if(!a.g.puzzle.reached){for(i=0;i<a.cols*a.rows;i++)if(a.g.puzzle.v[i]>=a.g.puzzle.target){a.g.puzzle.reached=1;finish(1,now);return;}}
    if(!puzzle_possible())finish(0,now);
}

/* Mines: first reveal and its neighbours are safe; iterative flood fill. */
static uint8_t mine_adj(int index){int x=index%a.cols,y=index/a.cols,xx,yy;uint8_t n=0;for(yy=y-1;yy<=y+1;yy++)for(xx=x-1;xx<=x+1;xx++)if(xx>=0&&xx<a.cols&&yy>=0&&yy<a.rows)n+=a.g.mines.bombs[yy*a.cols+xx];return n;}
static void mines_place(int safe){int n=0,i;while(n<a.mine_count){i=rng()%(a.cols*a.rows);if(abs(i%a.cols-safe%a.cols)<=1 && abs(i/a.cols-safe/a.cols)<=1)continue;if(!a.g.mines.bombs[i]){a.g.mines.bombs[i]=1;n++;}}a.g.mines.placed=1;}
static void mines_reveal(int index,uint32_t now){
    mines_t *m=&a.g.mines;uint8_t queue[120],head=0,tail=0;int i,x,y,xx,yy,n;
    if(m->open[index])return;
    if(m->flag_mode){m->flags[index]^=1;draw_board();return;}
    if(m->flags[index])return;if(!m->placed)mines_place(index);
    if(m->bombs[index]){finish(0,now);return;}
    m->open[index]=1;queue[tail++]=index;
    while(head<tail){i=queue[head++];m->revealed++;if(mine_adj(i))continue;x=i%a.cols;y=i/a.cols;
        for(yy=y-1;yy<=y+1;yy++)for(xx=x-1;xx<=x+1;xx++)if(xx>=0&&xx<a.cols&&yy>=0&&yy<a.rows){n=yy*a.cols+xx;if(!m->open[n]&&!m->flags[n]&&!m->bombs[n]){m->open[n]=1;queue[tail++]=n;}}
    }
    a.score=m->revealed*10;console_record(a.id,a.score);console_beep(now,25);
    if(m->revealed==a.cols*a.rows-a.mine_count){a.score+=500;finish(1,now);}else{draw_board();hud();}
}

/* Tic-tac-toe: human +1, computer -1, alpha-beta minimax. */
static void mines_chord(int index,uint32_t now){int x=index%a.cols,y=index/a.cols,xx,yy,n,flags=0;uint8_t mode=a.g.mines.flag_mode;if(!a.g.mines.open[index])return;for(yy=y-1;yy<=y+1;yy++)for(xx=x-1;xx<=x+1;xx++)if(xx>=0&&xx<a.cols&&yy>=0&&yy<a.rows)flags+=a.g.mines.flags[yy*a.cols+xx];if(flags!=mine_adj(index))return;a.g.mines.flag_mode=0;for(yy=y-1;yy<=y+1&&a.state==PLAY;yy++)for(xx=x-1;xx<=x+1&&a.state==PLAY;xx++)if(xx>=0&&xx<a.cols&&yy>=0&&yy<a.rows){n=yy*a.cols+xx;if(!a.g.mines.flags[n])mines_reveal(n,now);}a.g.mines.flag_mode=mode;}
static int xo_result(void){
    int i,j,n=a.cols,v,ok;for(i=0;i<n*2+2;i++){v=0;ok=1;for(j=0;j<n;j++){int idx=i<n?i*n+j:i<n*2?j*n+i-n:i==n*2?j*n+j:j*n+n-1-j;if(!j)v=a.g.xo.v[idx];if(!v||a.g.xo.v[idx]!=v)ok=0;}if(ok)return v;}for(i=0;i<n*n;i++)if(!a.g.xo.v[i])return 2;return 0;
}
static int xo_search(int turn,int depth,int alpha,int beta){
    int result=xo_result(),i,v,best=turn==-1?-100:100;
    if(result!=2)return result==-1?10-depth:result==1?depth-10:0;
    for(i=0;i<9;i++)if(!a.g.xo.v[i]){a.g.xo.v[i]=turn;v=xo_search(-turn,depth+1,alpha,beta);a.g.xo.v[i]=0;
        if(turn==-1){if(v>best)best=v;if(best>alpha)alpha=best;}else{if(v<best)best=v;if(best<beta)beta=best;}if(alpha>=beta)break;}
    return best;
}
static void xo_check(uint32_t now){int r=xo_result();if(r!=2){if(a.mode>=2){a.score=0;finish(r==0?2:r==1?4:3,now);}else{a.score=r==1?100:r==0?10:0;finish(r==1?1:r==0?2:0,now);}}}
static void xo_ai(uint32_t now){int i,v,best=-100,move=-1;
    if(a.diff==0 || (a.diff==1 && rng()%2)){int free_cells[9],count=0;for(i=0;i<9;i++)if(!a.g.xo.v[i])free_cells[count++]=i;if(count)move=free_cells[rng()%count];}
    if(move<0)for(i=0;i<9;i++)if(!a.g.xo.v[i]){a.g.xo.v[i]=-1;v=xo_search(1,0,-100,100);a.g.xo.v[i]=0;if(v>best){best=v;move=i;}}if(move>=0)a.g.xo.v[move]=-1;a.g.xo.ai_pending=0;draw_board();xo_check(now);}


/* Scramble the solved 15-puzzle by legal blank moves: every generated board is solvable. */
static uint8_t slide_solved(void){int i,n=a.cols*a.rows;for(i=0;i<n-1;i++)if(a.g.slide.v[i]!=i+1)return 0;return a.g.slide.v[n-1]==0;}
static void slide_init(void){int i,d,n,previous=-1,b,count=a.cols*a.rows;for(i=0;i<count-1;i++)a.g.slide.v[i]=i+1;a.g.slide.v[count-1]=0;a.g.slide.blank=count-1;
    for(i=0;i<count*10;i++){b=a.g.slide.blank;d=rng()%4;if(b%a.cols+dx[d]<0||b%a.cols+dx[d]>=a.cols||b/a.cols+dy[d]<0||b/a.cols+dy[d]>=a.rows){i--;continue;}n=b+dx[d]+a.cols*dy[d];if(n==previous){i--;continue;}a.g.slide.v[b]=a.g.slide.v[n];a.g.slide.v[n]=0;previous=b;a.g.slide.blank=n;}
    if(slide_solved()){a.g.slide.v[count-1]=count-1;a.g.slide.v[count-2]=0;a.g.slide.blank=count-2;}
}
static void slide_move(int index,uint32_t now){int b=a.g.slide.blank;uint32_t cost;
    if(abs(index%a.cols-b%a.cols)+abs(index/a.cols-b/a.cols)!=1)return;
    a.g.slide.v[b]=a.g.slide.v[index];a.g.slide.v[index]=0;a.g.slide.blank=index;if(a.g.slide.moves<65535)a.g.slide.moves++;
    console_beep(now,20);draw_board();hud();
    if(slide_solved()){cost=(uint32_t)a.g.slide.moves*10+a.elapsed/1000;a.score=cost>=9999?1:10000-cost;finish(1,now);}
}
static void memory_init(void){int i,j;uint8_t t;for(i=0;i<16;i++)a.g.memory.v[i]=i/2;for(i=15;i>0;i--){j=rng()%(i+1);t=a.g.memory.v[i];a.g.memory.v[i]=a.g.memory.v[j];a.g.memory.v[j]=t;}a.g.memory.first=a.g.memory.second=255;}
static void memory_pick(int index,uint32_t now){memory_t *m=&a.g.memory;uint32_t cost;
    if(m->matched[index]||m->second!=255||m->first==index)return;
    if(m->first==255)m->first=index;else{m->second=index;if(m->turns<65535)m->turns++;
        if(m->v[m->first]==m->v[index]){m->matched[m->first]=m->matched[index]=1;m->pairs++;m->combo++;m->bonus+=m->combo*10;m->first=m->second=255;console_beep(now,45);if(m->pairs==8){cost=(uint32_t)m->turns*25+a.elapsed/1000;a.score=(cost>=4999?1:5000-cost)+m->bonus;finish(1,now);return;}}
        else {m->combo=0;m->hide_at=now+650;}
    }draw_board();hud();
}
static void puzzle_undo(void){if(a.g.puzzle.can_undo){memcpy(a.g.puzzle.v,a.g.puzzle.undo,sizeof a.g.puzzle.v);a.score=a.g.puzzle.undo_score;a.g.puzzle.can_undo=0;draw_board();hud();}}
static void action_rect(int x,int y,int w,int h,uint16_t color){
    int x0,y0,x1,y1,pw=a.cell*a.cols,ph=a.cell*a.rows;
    if(x<0){w+=x;x=0;}if(y<0){h+=y;y=0;}
    if(x+w>240)w=240-x;if(y+h>200)h=200-y;if(w<=0||h<=0)return;
    x0=x*pw/240;y0=y*ph/200;x1=(x+w)*pw/240;y1=(y+h)*ph/200;
    fill(a.bx+x0,a.by+y0,x1-x0,y1-y0,color);
}
static uint16_t action_bg(void){return a.id==8?(a.score/10%3==0?0x1147:a.score/10%3==1?0x3867:0x0842):PANEL;}
static void action_draw(uint8_t erase){
    uint16_t bg=action_bg(),c=erase?bg:ACCENT;int i,g=a.g.bird.gap;
    if(a.id==8){
        action_rect(44,(a.g.bird.y>>8)-6,12,12,erase?bg:GOLD);
        if(!erase){action_rect(51,(a.g.bird.y>>8)-4,3,3,INK);action_rect(53,(a.g.bird.y>>8)-3,1,2,BG);action_rect(44,a.g.bird.y>>8,6,3,0xfd20);action_rect(54,a.g.bird.y>>8,2,2,0xfd20);}
        action_rect(a.g.bird.pipe_x,0,28,a.g.bird.gap_y-g,c);
        action_rect(a.g.bird.pipe_x,a.g.bird.gap_y+g,28,200-a.g.bird.gap_y-g,c);
        if(!erase){action_rect(a.g.bird.pipe_x,a.g.bird.gap_y-g-5,28,5,0x03e0);action_rect(a.g.bird.pipe_x,a.g.bird.gap_y+g,28,5,0x03e0);}
    }else{
        action_rect(a.g.racer.lane*80+26,166,28,26,c);
        action_rect(a.g.racer.obstacle_lane*80+24,a.g.racer.obstacle_y,32,28,erase?PANEL:BAD);
        if(!erase){
            action_rect(a.g.racer.lane*80+31,170,18,7,0x328b);action_rect(a.g.racer.lane*80+26,172,3,14,BG);action_rect(a.g.racer.lane*80+51,172,3,14,BG);
            action_rect(a.g.racer.obstacle_lane*80+29,a.g.racer.obstacle_y+5,22,7,0x328b);
            for(i=1;i<3;i++)action_rect(i*80-1,0,2,200,EDGE);
        }
    }
}
static void action_step(uint32_t now){
    action_draw(1);
    if(a.id==8){
        bird_t *b=&a.g.bird;int y;
        b->vy+=38;if(b->vy>900)b->vy=900;b->y+=b->vy;b->pipe_x-=2;y=b->y>>8;
        if(y<6||y>194||(b->pipe_x<56&&b->pipe_x+28>44&&(y-6<b->gap_y-b->gap||y+6>b->gap_y+b->gap))){finish(0,now);return;}
        if(!b->passed&&b->pipe_x+28<=44){b->passed=1;a.score++;console_record(a.id,a.score);console_beep(now,20);hud();if(a.score%10==0)draw_board();}
        if(b->pipe_x<-28){b->pipe_x=240;b->gap_y=60+rng()%81;b->gap=a.variant?28+rng()%15:38;b->passed=0;}
    }else{
        racer_t *r=&a.g.racer;r->obstacle_y+=3+(a.score>=30?3:a.score/10)+(a.elapsed<r->boost_until?2:0);
        if(a.variant&&a.elapsed/1000>r->fuel_at){r->fuel_at=a.elapsed/1000;if(r->fuel)r->fuel--;if(!r->fuel){finish(0,now);return;}}
        if(r->lane==r->obstacle_lane&&r->obstacle_y+28>166&&r->obstacle_y<192){finish(0,now);return;}
        if(r->obstacle_y>=200){a.score+=a.elapsed<r->boost_until?2:1;if(a.score%3==0){int fuel=r->fuel+15;r->fuel=fuel>100?100:fuel;}console_record(a.id,a.score);r->obstacle_y=-40;r->obstacle_lane=rng()%3;console_beep(now,15);hud();}
    }
    action_draw(0);
}
static void draw_board(void){
    int x,y,i,cx,cy,ghost;char b[16];uint16_t color;uint32_t value;
    static const uint16_t tc[8]={PANEL,0x07ff,0xffe0,0xf81f,0x07e0,0xf800,0x001f,0xfd20};
    /* Redraw only changed tetris cells, including both old and new piece positions. */
    if(a.id==2){
        ghost=a.g.tet.y;while(tet_fits(a.g.tet.x,ghost+1,a.g.tet.rot))ghost++;
        for(y=0;y<20;y++)for(x=0;x<10;x++){
            value=a.g.tet.cells[y][x];cx=x-a.g.tet.x;cy=y-ghost;
            if(!value&&cx>=0&&cx<4&&cy>=0&&cy<4&&tet_bit(a.g.tet.kind,a.g.tet.rot,cx,cy))value=8;
            cy=y-a.g.tet.y;
            if(cx>=0&&cx<4&&cy>=0&&cy<4&&tet_bit(a.g.tet.kind,a.g.tet.rot,cx,cy))value=a.g.tet.kind+1;
            if(a.g.tet.paint[y][x]!=value || (a.clear_mask&(1UL<<y))){tile(x,y,(a.clear_mask&(1UL<<y))?GOLD:value==8?EDGE:tc[value],0,0);a.g.tet.paint[y][x]=value;}
        }
        return;
    }
    if(a.id>=8){fill(a.bx,a.by,a.cell*a.cols,a.cell*a.rows,action_bg());action_draw(0);return;}
    fill(a.bx,a.by,a.cell*a.cols,a.cell*a.rows,EDGE);
    if(a.id==1){
        for(y=0;y<16;y++)for(x=0;x<20;x++)tile(x,y,snake_wall(x,y)?EDGE:PANEL,0,0);
        if(a.mode==4){tile(1,1,0xf81f,"A",INK);tile(18,14,0xf81f,"B",INK);}
        for(i=0;i<a.g.snake.len;i++)tile(a.g.snake.x[i],a.g.snake.y[i],i?0x05e0:ACCENT,0,0);
        tile(a.g.snake.fx,a.g.snake.fy,GOLD,0,0);
    }else if(a.id==3){
        for(i=0;i<a.cols*a.rows;i++){value=a.g.puzzle.v[i];color=value?((value<=8)?0x4b4d:(value<=64)?0x9b00:0x6a94):PANEL;sprintf(b,"%lu",(unsigned long)value);tile(i%a.cols,i/a.cols,color,value?b:0,value?INK:0);}
    }else if(a.id==4){
        for(i=0;i<a.cols*a.rows;i++){color=PANEL;b[0]=0;
            if(a.g.mines.open[i]){color=0x31a6;value=mine_adj(i);if(value)sprintf(b,"%lu",(unsigned long)value);}
            else if(a.g.mines.flags[i]){color=0x6a40;strcpy(b,"F");}
            tile(i%a.cols,i/a.cols,color,b[0]?b:0,ACCENT);
        }
    }else if(a.id==6){
        for(i=0;i<a.cols*a.rows;i++){sprintf(b,"%u",a.g.slide.v[i]);tile(i%a.cols,i/a.cols,a.g.slide.v[i]?0x236b:PANEL,a.g.slide.v[i]?b:0,INK);}
    }else if(a.id==7){
        for(i=0;i<16;i++){
            uint8_t show=a.g.memory.matched[i]||a.g.memory.first==i||a.g.memory.second==i;
            {static const char symbols[8]={'@','#','+','*','%','&','=','!'};b[0]=symbols[a.g.memory.v[i]];b[1]=0;}
            tile(i%4,i/4,a.g.memory.matched[i]?0x2447:show?0x736e:0x19e8,show?b:"?",a.g.memory.matched[i]?0x67ec:INK);
        }
    }else{
        for(i=0;i<a.cols*a.rows;i++)tile(i%a.cols,i/a.cols,PANEL,a.g.xo.v[i]==1?"X":a.g.xo.v[i]==-1?"O":0,a.g.xo.v[i]==1?ACCENT:GOLD);
    }
}
static void controls(void){
    uint8_t i;const char *s[6];
    if(a.id==1||a.id==3){s[0]="UP";s[1]="DOWN";s[2]="LEFT";s[3]="RIGHT";s[4]=a.id==3?"UNDO":"RESTART";s[5]="HOME";}
    else if(a.id==2){s[0]="LEFT";s[1]="RIGHT";s[2]="ROTATE";s[3]="DOWN";s[4]="DROP";s[5]="HOLD";}
    else if(a.id==8){s[0]="FLAP";s[1]="HOME";s[2]=s[3]=s[4]=s[5]=0;}
    else if(a.id==9){s[0]="LEFT";s[1]="RIGHT";s[2]="RESTART";s[3]="HOME";s[4]="NITRO";s[5]=0;}
    else if(a.id>=6){s[0]="RESTART";s[1]="HOME";s[2]=s[3]=s[4]=s[5]=0;}
    else {s[0]=a.id==4?(a.g.mines.flag_mode?"FLAG_ON":"REVEAL_ON"):a.mode>=2?"PLAYER_X":"YOU_X";s[1]=a.id==4?"FLAG_SWITCH":a.mode>=2?"PLAYER_O":"CPU_O";s[2]="RESTART";s[3]="HOME";s[4]=s[5]=0;}
    for(i=0;i<6;i++)if(s[i]&&a.controls[i].w>0)button(a.controls[i],s[i],i==5?EDGE:ACCENT);
}
static void scene(void){
    rect_t title;uint8_t i;int w,h,top;
    lcd_clear(BG);title.x=10;title.y=8;title.w=lcddev.width-110;title.h=36;
    center(title,lcddev.width>=640?24:16,titles[a.id],ACCENT,BG);if(a.state==PLAY)button(a.pause,"PAUSE",ACCENT);
    if(a.state==COUNTDOWN){char b[8];sprintf(b,"%lu",(unsigned long)(3-(a.tick-a.count_at)/1000));title.y=lcddev.height/2-20;title.h=40;center(title,32,b,GOLD,BG);return;}
    if(a.state==PLAY){
        if(a.id==2){memset(a.g.tet.paint,255,sizeof a.g.tet.paint);fill(a.bx,a.by,a.cell*a.cols,a.cell*a.rows,EDGE);}
        draw_board();hud();controls();return;
    }
    w=lcddev.width>=640?260:200;h=lcddev.height>=400?52:34;top=lcddev.height>=400?210:128;
    title.x=0;title.w=lcddev.width;title.y=60;title.h=36;
    center(title,24,a.state==READY?"READY_HELP":a.state==PAUSED?"GAME PAUSED":a.won==2?"DRAW":a.won?"YOU WIN!":"GAME OVER",a.won?GOLD:INK,BG);
    if(a.state==READY){
        const char *diffs[3]={"EASY","NORMAL","HARD"};
        a.choices[0].x=20;a.choices[0].y=lcddev.height>=400?125:92;a.choices[0].w=(lcddev.width-52)/2;a.choices[0].h=lcddev.height>=400?40:28;
        a.choices[1]=a.choices[0];a.choices[1].x+=a.choices[0].w+12;
        if(a.id==1||a.id==4||a.id==5)button(a.choices[0],diffs[a.diff],GOLD);
        if(a.id==1)button(a.choices[1],a.mode==0?"WALL_MODE":a.mode==1?"WRAP_MODE":a.mode==2?"OBSTACLE_MODE":a.mode==3?"SNAKE_GOAL":a.mode==4?"PORTALS":"SNAKE_TIMED",ACCENT);
        if(a.id==5)button(a.choices[1],a.mode==3?"TWO4":a.mode==2?"TWO3":a.mode?"CPU_FIRST":"HUMAN_FIRST",ACCENT);
        if(a.id==3)button(a.choices[0],a.variant?"GRID5":"GRID4",ACCENT);
        if(a.id==6)button(a.choices[0],a.variant==1?"GRID3":a.variant==2?"GRID5":"GRID4",ACCENT);
        if(a.id==7)button(a.choices[0],a.variant?"MEM_TIMED":"MEM_CLASSIC",ACCENT);
        if(a.id==8)button(a.choices[0],a.variant?"BIRD_HARD":"BIRD_CLASSIC",ACCENT);
        if(a.id==9)button(a.choices[0],a.variant?"RACER_FUEL":"RACER_CLASSIC",ACCENT);
        if(daily_seed){title.y=90;title.h=24;fill(0,90,lcddev.width,32,BG);center(title,16,"DAILY_FIXED",GOLD,BG);}
    }
    if(a.state==OVER)arcade_result_panel(a.id,a.won,a.score,console_best(a.id));
    for(i=0;i<3;i++){a.modal[i].x=(lcddev.width-w)/2;a.modal[i].y=top+i*(h+10);a.modal[i].w=w;a.modal[i].h=h;}
    button(a.modal[0],a.state==PAUSED?"RESUME":a.state==READY?"START":a.id==3&&a.won?"CONTINUE":"PLAY AGAIN",ACCENT);
    if(a.state==PAUSED){button(a.modal[1],"RESTART",GOLD);button(a.modal[2],"HOME",EDGE);}else button(a.modal[1],"HOME",EDGE);
}
void arcade_start(uint8_t id,uint32_t now){
    int i,maxw,maxh,top,bh;uint32_t seed=a.seed^now^0xa53c91e7U;
    if(daily_seed)seed=daily_seed;
    if(id>=10){memset(&a,0,sizeof a);a.id=id;if(id==10||id==12)adventure_start(id==10,now,seed);else combat_start(id,now,seed,1);return;}
    memset(&a,0,sizeof a);a.seed=seed?seed:1;a.id=id;a.last=a.tick=now;a.held=255;
    a.diff=console_option(id==1?1:id==4?2:3);a.mode=console_option(id==1?0:4);
    a.variant=daily_seed?0:variants[id];
    if(id==1&&a.variant)a.mode=a.variant-1;
    if(id==5&&a.variant)a.mode=a.variant-1;
    if(daily_seed){a.diff=1;a.mode=0;}
    a.cols=id>=8?6:id==1?20:id==2?10:(id==3||id>=6)?4:id==4?(a.diff==0?8:a.diff==1?10:12):3;
    a.rows=id>=8?5:id==1?16:id==2?20:id==4?(a.diff==2?10:8):a.cols;a.mine_count=a.diff==0?10:a.diff==1?14:22;
    if(id==3&&a.variant)a.cols=a.rows=5;
    if(id==5&&a.mode==3)a.cols=a.rows=4;
    if(id==6){a.cols=a.rows=a.variant==1?3:a.variant==2?5:4;}
    a.sx=lcddev.width*3/5;a.sw=lcddev.width-a.sx-12;
    maxw=a.sx-24;maxh=lcddev.height-70;a.cell=maxw/a.cols;if(a.cell>maxh/a.rows)a.cell=maxh/a.rows;
    a.bx=(a.sx-a.cell*a.cols)/2;a.by=58;
    a.pause.x=lcddev.width-94;a.pause.y=8;a.pause.w=82;a.pause.h=34;
    top=lcddev.height>=400?180:id==2?154:132;bh=(lcddev.height-top-28)/3;
    for(i=0;i<6;i++){a.controls[i].x=a.sx+(i%2)*(a.sw/2+4);a.controls[i].y=top+(i/2)*(bh+8);a.controls[i].w=a.sw/2-4;a.controls[i].h=bh;}
    if(id==1){
        int size=(a.sw-12)/3,space=lcddev.height-134;
        if(size>(space-8)/3)size=(space-8)/3;
        for(i=0;i<4;i++){a.controls[i].w=a.controls[i].h=size;a.controls[i].x=a.sx+(a.sw-size)/2;a.controls[i].y=132+size+4;}
        a.controls[0].y-=size+4;a.controls[1].y+=size+4;
        a.controls[2].x-=size+4;a.controls[3].x+=size+4;
        /* Restart and hall are available through pause; leave diagonal space inert. */
        a.controls[4].w=a.controls[4].h=a.controls[5].w=a.controls[5].h=0;
    }
    if(id==1){a.g.snake.len=4;a.g.snake.dir=a.g.snake.pending=1;for(i=0;i<4;i++){a.g.snake.x[i]=8-i;a.g.snake.y[i]=8;}snake_food();a.state=READY;}
    else if(id==2){a.g.tet.hold=255;a.g.tet.bag_at=7;a.g.tet.next=tet_bag();tet_spawn(now);a.state=READY;}
    else if(id==3){a.g.puzzle.target=2048;puzzle_spawn();puzzle_spawn();}
    else if(id==4){a.g.mines.touch_cell=a.g.mines.last_cell=-1;}
    else if(id==5)a.g.xo.turn=1;
    else if(id==6)slide_init();
    else if(id==7)memory_init();
    else if(id==8){a.g.bird.y=100L<<8;a.g.bird.pipe_x=240;a.g.bird.gap_y=100;a.g.bird.gap=38;}
    else if(id==9){a.g.racer.lane=1;a.g.racer.obstacle_y=-40;a.g.racer.obstacle_lane=rng()%3;a.g.racer.fuel=100;}
    a.state=READY;
    scene();
}
static uint8_t go_home(void){console_record(a.id,a.score);console_flush();a.gesture=0;return 1;}

static uint8_t control_action(int i,uint32_t now){
    if(a.id==1||a.id==3){
        if(i<4){static const uint8_t dirs[4]={0,2,3,1};if(a.id==1)snake_turn(dirs[i]);else puzzle_move(dirs[i],now);}
        else if(i==4){if(a.id==3)puzzle_undo();else {console_record(a.id,a.score);console_flush();arcade_start(a.id,now);}}
        else return go_home();
    }else if(a.id==2){tet_action(i,now);}
    else if(a.id==8){if(i==1)return go_home();a.g.bird.vy=-700;}
    else if(a.id==9){if(i==3)return go_home();if(i==4){if(a.g.racer.fuel>=20){a.g.racer.fuel-=20;a.g.racer.boost_until=a.elapsed+3000;hud();}}else if(i==2){console_record(a.id,a.score);console_flush();arcade_start(a.id,now);}else{action_draw(1);if(i==0&&a.g.racer.lane)a.g.racer.lane--;if(i==1&&a.g.racer.lane<2)a.g.racer.lane++;action_draw(0);}}
    else if(a.id>=6){if(i==1)return go_home();if(i==0){console_flush();arcade_start(a.id,now);}}
    else{if(i==3)return go_home();if(i==2){console_record(a.id,a.score);console_flush();arcade_start(a.id,now);}else if(a.id==4&&(i==0||i==1)){a.g.mines.flag_mode^=1;controls();}}
    return 0;
}
uint8_t arcade_tick(uint32_t now,uint16_t x,uint16_t y,uint8_t press,uint8_t release,uint8_t down){
    int i,index,d,delta_x,delta_y;rect_t board;uint32_t interval,dt=now-a.tick;a.tick=now;
    if(a.id==10||a.id==12)return adventure_tick(now,x,y,press,down);
    if(a.id>=10)return combat_tick(now,x,y,press,down);
    if(a.state==COUNTDOWN){if(now-a.count_at>=3000){a.state=PLAY;a.last=a.tick=now;if(a.id==5&&a.g.xo.ai_pending)a.g.xo.ai_time=now+250;if(a.id==7&&a.g.memory.second!=255)a.g.memory.hide_at=now+650;scene();}else if((now-a.count_at)/1000!=(a.hud_at-a.count_at)/1000){a.hud_at=now;scene();}return 0;}
    if(a.state==PLAY)a.elapsed+=dt;
    if(!down && a.held!=255){a.held=255;if(a.state==PLAY)controls();}
    if(a.state!=PLAY){
        if(press){
            if(a.state==READY && !daily_seed && (a.id==1||a.id==4||a.id==5) && inside(a.choices[0],x,y)){
                console_set_option(a.id==1?1:a.id==4?2:3,(a.diff+1)%3);console_flush();arcade_start(a.id,now);return 0;
            }
            if(a.state==READY && !daily_seed && (a.id==1||a.id==5) && inside(a.choices[1],x,y)){
                variants[a.id]=(a.mode+1)%(a.id==1?6:4)+1;arcade_start(a.id,now);return 0;
            }
            if(a.state==READY&&!daily_seed&&(a.id==3||a.id>=6)&&inside(a.choices[0],x,y)){variants[a.id]=(a.variant+1)%(a.id==6?3:2);arcade_start(a.id,now);return 0;}
            if(inside(a.modal[0],x,y)){
                if(a.state==PAUSED||a.state==READY||(a.state==OVER&&a.id==3&&a.won)){
                    if(!a.started){console_started(a.id);a.started=1;if(a.id==5&&a.mode==1){a.g.xo.ai_pending=1;a.g.xo.ai_time=now+250;}}
                    if(a.state==OVER){a.g.puzzle.target=a.g.puzzle.target<65536?a.g.puzzle.target*2:0xffffffffU;a.g.puzzle.reached=0;a.won=0;}
                    if(a.id==7 && a.g.memory.second!=255)a.g.memory.hide_at=now+650;
                    a.state=COUNTDOWN;a.count_at=a.hud_at=now;a.last=a.tick=now;a.gesture=0;a.held=255;
                    if(a.id==5&&a.g.xo.ai_pending)a.g.xo.ai_time=now+250;scene();
                }else arcade_start(a.id,now);
            }else if(a.state==PAUSED && inside(a.modal[1],x,y)){console_record(a.id,a.score);console_flush();arcade_start(a.id,now);}
            else if(inside(a.modal[a.state==PAUSED?2:1],x,y))return go_home();
        }return 0;
    }
    if(press && inside(a.pause,x,y)){a.state=PAUSED;a.gesture=0;a.held=255;if(a.id==4)a.g.mines.touch_cell=-1;console_record(a.id,a.score);console_flush();scene();return 0;}
    if(press){
        for(i=0;i<(a.id==1?4:a.id==9?5:a.id>=6?2:(a.id==4||a.id==5)?4:6);i++)if(inside(a.controls[i],x,y)){
            a.gesture=0;
            if(control_action(i,now))return 1;
            if(a.state==PLAY){a.held=i;a.repeat_at=now+320;lcd_draw_rectangle(a.controls[i].x+2,a.controls[i].y+2,a.controls[i].x+a.controls[i].w-3,a.controls[i].y+a.controls[i].h-3,GOLD);}
            return 0;
        }
    }
    if(down && a.held!=255){
        if(!inside(a.controls[a.held],x,y)){a.held=255;controls();}
        else if((a.id==2&&(a.held==0||a.held==1||a.held==3)) && (int32_t)(now-a.repeat_at)>=0){a.repeat_at=now+85;control_action(a.held,now);}
    }
    if(a.state!=PLAY)return 0;
    board.x=a.bx;board.y=a.by;board.w=a.cell*a.cols;board.h=a.cell*a.rows;
    if(press && inside(board,x,y)){
        index=((y-a.by)/a.cell)*a.cols+(x-a.bx)/a.cell;
        if(a.id==3){a.gesture=1;a.gesture_x=x;a.gesture_y=y;}
        else if(a.id==4){a.g.mines.touch_cell=index;a.g.mines.touch_at=now;a.g.mines.long_done=0;}
        else if(a.id==6)slide_move(index,now);
        else if(a.id==7)memory_pick(index,now);
        else if(a.id==8)a.g.bird.vy=-700;
        else if(a.id==5 && !a.g.xo.ai_pending && !a.g.xo.v[index]){
            a.g.xo.v[index]=a.mode>=2?a.g.xo.turn:1;if(a.mode>=2)a.g.xo.turn=-a.g.xo.turn;draw_board();console_beep(now,25);xo_check(now);
            if(a.state==PLAY&&a.mode<2){a.g.xo.ai_pending=1;a.g.xo.ai_time=now+250;}
        }
    }
    if(a.id==4&&a.g.mines.touch_cell>=0){
        mines_t *m=&a.g.mines;int cell=m->touch_cell;rect_t r={a.bx+(cell%a.cols)*a.cell,a.by+(cell/a.cols)*a.cell,a.cell,a.cell};
        if(down&&!inside(r,x,y))m->touch_cell=-1;
        else if(down&&!m->long_done&&now-m->touch_at>=500){if(!m->open[cell]){m->flags[cell]^=1;draw_board();}m->long_done=1;}
        else if(release){if(!m->long_done){if(m->open[cell]&&cell==m->last_cell&&now-m->last_at<=350)mines_chord(cell,now);else mines_reveal(cell,now);m->last_cell=cell;m->last_at=now;}m->touch_cell=-1;}
    }
    if(a.id==9&&down&&inside(board,x,y)){int lane=(x-a.bx)*3/(a.cell*a.cols);if(lane!=a.g.racer.lane){action_draw(1);a.g.racer.lane=lane;action_draw(0);}}
    if(release && a.id==3 && a.gesture){
        a.gesture=0;delta_x=(int)x-a.gesture_x;delta_y=(int)y-a.gesture_y;
        if(abs(delta_x)>=18||abs(delta_y)>=18){d=abs(delta_x)>abs(delta_y)?(delta_x>0?1:3):(delta_y>0?2:0);puzzle_move(d,now);}
    }
    if(a.state!=PLAY)return 0;
    if(a.id==1){if(a.mode==5&&a.elapsed>=60000){finish(0,now);return 0;}interval=(a.diff==0?300:a.diff==1?230:160);interval=a.g.snake.eaten>=20?interval/2:interval-a.g.snake.eaten*interval/40;if((uint32_t)(now-a.last)>=interval){a.last=now;snake_step(now);}}
    else if(a.id==2){
        if(a.clear_mask && (int32_t)(now-a.flash_until)>=0){a.clear_mask=0;memset(a.g.tet.paint,255,sizeof a.g.tet.paint);draw_board();}
        interval=a.g.tet.lines>=40?120:650-a.g.tet.lines*13;if((uint32_t)(now-a.last)>=interval){a.last=now;tet_action(6,now);}
    }else if(a.id==5 && a.g.xo.ai_pending && (int32_t)(now-a.g.xo.ai_time)>=0)xo_ai(now);
    else if(a.id==7 && a.g.memory.second!=255 && (int32_t)(now-a.g.memory.hide_at)>=0){a.g.memory.first=a.g.memory.second=255;draw_board();}
    else if(a.id>=8&&(uint32_t)(now-a.last)>=20){a.last=now;action_step(now);}
    if(a.id==7&&a.variant&&a.elapsed>=90000&&a.state==PLAY)finish(0,now);
    if(a.state==PLAY && (uint32_t)(now-a.hud_at)>=1000){a.hud_at=now;hud();}
    return 0;
}
