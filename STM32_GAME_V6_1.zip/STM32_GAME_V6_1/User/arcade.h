#ifndef ARCADE_H
#define ARCADE_H
#include <stdint.h>
/* IDs: 1 snake, 2 tetris, 3 2048, 4 mines, 5 XO, 6 slide, 7 memory,
 * 8 bird, 9 racer, 10 dual-stick tank, 11 space, 12 Cavalier's Flame. */
void arcade_start(uint8_t id,uint32_t now);
void arcade_set_daily(uint32_t seed);
void arcade_result_panel(uint8_t id,uint8_t won,uint32_t score,uint32_t best_score);
/* Returns one only when the player chooses the hall. */
uint8_t arcade_tick(uint32_t now,uint16_t x,uint16_t y,uint8_t press,uint8_t release,uint8_t down);
#endif
