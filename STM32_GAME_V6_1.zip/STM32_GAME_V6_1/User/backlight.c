#include "console_service.h"
#include "./BSP/LCD/lcd.h"
/* PB0 = TIM3_CH3, no remap. Dedicated 20 kHz PWM; no timer interrupts.
 * Source: ST STM32F103xE datasheet, PB0 alternate-function table.
 * The existing project does not otherwise use TIM3. */
void console_backlight(uint8_t percent) {
    static uint8_t initialized;
    GPIO_InitTypeDef gpio={0};
    uint32_t timer_clock;
    if(percent>100)percent=100;
    if(!initialized){
        __HAL_RCC_GPIOB_CLK_ENABLE();__HAL_RCC_AFIO_CLK_ENABLE();__HAL_RCC_TIM3_CLK_ENABLE();
        /* Set a defined SWJ configuration explicitly. This bundled HAL's generic
         * remap macro ORs all SWJ bits, which must not be used for this write.
         * Keep SWD enabled on PA13/PA14; JTAG-only pins remain free. */
        AFIO->MAPR=(AFIO->MAPR & ~(AFIO_MAPR_TIM3_REMAP|AFIO_MAPR_SWJ_CFG))|AFIO_MAPR_SWJ_CFG_JTAGDISABLE;
        gpio.Pin=GPIO_PIN_0;gpio.Mode=GPIO_MODE_AF_PP;gpio.Speed=GPIO_SPEED_FREQ_HIGH;
        HAL_GPIO_Init(GPIOB,&gpio);
        timer_clock=HAL_RCC_GetPCLK1Freq();
        if((RCC->CFGR & RCC_CFGR_PPRE1)!=0)timer_clock*=2;
        TIM3->CR1=0;TIM3->PSC=timer_clock/2000000U-1;TIM3->ARR=99;
        TIM3->CCMR2=(6U<<4)|TIM_CCMR2_OC3PE;TIM3->CCER=TIM_CCER_CC3E;
        TIM3->CCR3=percent;TIM3->EGR=TIM_EGR_UG;TIM3->CR1=TIM_CR1_ARPE|TIM_CR1_CEN;
        initialized=1;
    }else TIM3->CCR3=percent;
}
