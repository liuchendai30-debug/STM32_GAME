#include "clock5.h"
#include "./SYSTEM/sys/sys.h"
/* LSE-backed RTC seconds since 2020-01-01, no RTC interrupts. No backup reset. */
static uint8_t rtc_ok;
static uint8_t month_days(uint16_t y,uint8_t m){static const uint8_t n[12]={31,28,31,30,31,30,31,31,30,31,30,31};return n[m-1]+(m==2&&y%4==0&&(y%100!=0||y%400==0));}
uint32_t clock5_encode(uint16_t y,uint8_t m,uint8_t d){uint32_t n=0;uint16_t i;uint8_t j;if(y<2020||y>2099||m<1||m>12||d<1||d>month_days(y,m))return 0xffffffffU;for(i=2020;i<y;i++)n+=365+(i%4==0);for(j=1;j<m;j++)n+=month_days(y,j);return n+d-1;}
void clock5_decode(uint32_t n,uint16_t *y,uint8_t *m,uint8_t *d){*y=2020;*m=1;if(n>29219)n=0;while(n>=(uint32_t)(365+(*y%4==0))){n-=365+(*y%4==0);(*y)++;}while(n>=month_days(*y,*m)){n-=month_days(*y,*m);(*m)++;}*d=n+1;}
#ifndef HOST_TEST
static uint8_t rtc_wait(uint32_t bit){uint32_t t=HAL_GetTick();while(!(RTC->CRL&bit))if(HAL_GetTick()-t>100)return 0;return 1;}
void clock5_init(void){uint32_t t;rtc_ok=0;RCC->APB1ENR|=RCC_APB1ENR_PWREN|RCC_APB1ENR_BKPEN;PWR->CR|=PWR_CR_DBP;
    if((RCC->BDCR&RCC_BDCR_RTCSEL)&&((RCC->BDCR&RCC_BDCR_RTCSEL)!=RCC_BDCR_RTCSEL_0))return;
    RCC->BDCR|=RCC_BDCR_LSEON;t=HAL_GetTick();while(!(RCC->BDCR&RCC_BDCR_LSERDY))if(HAL_GetTick()-t>1500)return;
    RCC->BDCR|=RCC_BDCR_RTCSEL_0|RCC_BDCR_RTCEN;RTC->CRL&=~RTC_CRL_RSF;if(!rtc_wait(RTC_CRL_RSF)||!rtc_wait(RTC_CRL_RTOFF))return;
    if(BKP->DR1!=0x5635){RTC->CRL|=RTC_CRL_CNF;RTC->PRLH=0;RTC->PRLL=32767;RTC->CRH=0;RTC->CRL&=~RTC_CRL_CNF;if(!rtc_wait(RTC_CRL_RTOFF))return;}rtc_ok=1;
}
uint8_t clock5_ready(void){return rtc_ok&&BKP->DR1==0x5635;}
uint32_t clock5_seconds(void){uint32_t hi,lo,next;if(!clock5_ready())return 0xffffffffU;do{hi=RTC->CNTH;lo=RTC->CNTL;next=RTC->CNTH;}while(hi!=next);return (hi<<16)|lo;}
uint32_t clock5_day(void){uint32_t n=clock5_seconds();return n==0xffffffffU?n:n/86400U;}
uint8_t clock5_set_time(uint16_t y,uint8_t m,uint8_t d,uint8_t h,uint8_t min){uint32_t n=clock5_encode(y,m,d);if(!rtc_ok||h>23||min>59||n==0xffffffffU||!rtc_wait(RTC_CRL_RTOFF))return 0;n=n*86400U+h*3600U+min*60U;BKP->DR1=0;RTC->CRL|=RTC_CRL_CNF;RTC->CNTH=n>>16;RTC->CNTL=n&65535;RTC->CRL&=~RTC_CRL_CNF;if(!rtc_wait(RTC_CRL_RTOFF))return 0;BKP->DR1=0x5635;return 1;}
#else
static uint32_t host_day=0xffffffffU;
static uint32_t host_offset;
void clock5_init(void){rtc_ok=1;}
uint8_t clock5_ready(void){return rtc_ok&&host_day!=0xffffffffU;}
uint32_t clock5_day(void){return host_day;}
uint32_t clock5_seconds(void){return clock5_ready()?host_day*86400U+host_offset:0xffffffffU;}
uint8_t clock5_set_time(uint16_t y,uint8_t m,uint8_t d,uint8_t h,uint8_t min){uint32_t n=clock5_encode(y,m,d);if(!rtc_ok||h>23||min>59||n==0xffffffffU)return 0;host_day=n;host_offset=h*3600U+min*60U;return 1;}
#endif
uint8_t clock5_set(uint16_t y,uint8_t m,uint8_t d){return clock5_set_time(y,m,d,0,0);}
