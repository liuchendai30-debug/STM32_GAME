#ifndef CLOCK5_H
#define CLOCK5_H
#include <stdint.h>
void clock5_init(void);
uint8_t clock5_ready(void);
uint32_t clock5_day(void);
uint8_t clock5_set(uint16_t year,uint8_t month,uint8_t day);
uint8_t clock5_set_time(uint16_t year,uint8_t month,uint8_t day,uint8_t hour,uint8_t minute);
uint32_t clock5_seconds(void);
uint32_t clock5_encode(uint16_t year,uint8_t month,uint8_t day);
void clock5_decode(uint32_t days,uint16_t *year,uint8_t *month,uint8_t *day);
#endif
