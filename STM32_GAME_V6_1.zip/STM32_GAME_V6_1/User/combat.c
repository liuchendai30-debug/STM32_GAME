#include "combat.h"
#include "arcade.h"
#include "console_service.h"
#include "./BSP/LCD/lcd.h"
#include "./BSP/TOUCH/touch.h"
#include "ui_zh.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

/* Fixed pools and tile compositing: RAM is independent of screen resolution. */
#define CO_SHOTS 48
#define CO_ENEMIES 6
typedef struct {int16_t x,y,w,h;} co_rect;
typedef struct {int16_t x,y;int8_t vx,vy;uint8_t alive,enemy,power;} co_shot;
typedef struct {int16_t x,y;uint8_t hp,type,dir;uint16_t cool;} co_enemy;
enum {CO_READY,CO_COUNT,CO_PLAY,CO_PAUSE,CO_OVER,CO_NEXT};
static struct {
    uint8_t id,state,diff,level,hp,dir,weapon,shield,armed,auto_fire,bombs,won;
    uint8_t map[180],dirty[180],spawned,kills,total,boss,boss_hp,boss_max;
    uint16_t frame,invul,fire_at,boss_fire,drop_life,boost;
    int16_t px,py,boss_x,drop_x,drop_y;uint8_t drop_kind;
    uint32_t seed,score,last,count_at,hud_at,elapsed;
    int bx,by,bw,bh,sx,sw;co_rect keys[6],menu[3];
    co_shot shots[CO_SHOTS];co_enemy enemies[CO_ENEMIES];
} co;
static uint16_t co_pixels[40*40];
static int co_tx,co_ty,co_tw,co_th;
static const int8_t co_dx[4]={0,1,0,-1},co_dy[4]={-1,0,1,0};
static uint32_t co_random(void){uint32_t n=co.seed;n^=n<<13;n^=n>>17;n^=n<<5;return co.seed=n?n:1;}
static int co_hit(co_rect r,int x,int y){return x>=r.x&&x<r.x+r.w&&y>=r.y&&y<r.y+r.h;}
static int co_overlap(int x,int y,int w,int h,int xx,int yy,int ww,int hh){return x<xx+ww&&x+w>xx&&y<yy+hh&&y+h>yy;}
static void co_mark(int x,int y,int w,int h){int i,j;for(j=0;j<12;j++)for(i=0;i<15;i++)if(co_overlap(x,y,w,h,i*16,j*16,16,16))co.dirty[j*15+i]=1;}
static void co_mark_actors(void){int i;co_mark(co.px-2,co.py-2,20,22);if(co.boss)co_mark(co.boss_x,6,56,26);if(co.drop_life)co_mark(co.drop_x,co.drop_y,10,10);for(i=0;i<CO_ENEMIES;i++)if(co.enemies[i].hp)co_mark(co.enemies[i].x-2,co.enemies[i].y-2,20,22);for(i=0;i<CO_SHOTS;i++)if(co.shots[i].alive)co_mark(co.shots[i].x-2,co.shots[i].y-2,6,12);}
/* Draw world rectangles into one dirty screen tile, then transfer once to LCD. */
static void co_paint(int x,int y,int w,int h,uint16_t color){int x0=co.bx+x*co.bw/240,y0=co.by+y*co.bh/192,x1=co.bx+(x+w)*co.bw/240,y1=co.by+(y+h)*co.bh/192,i,j;if(x0<co_tx)x0=co_tx;if(y0<co_ty)y0=co_ty;if(x1>co_tx+co_tw)x1=co_tx+co_tw;if(y1>co_ty+co_th)y1=co_ty+co_th;for(j=y0;j<y1;j++)for(i=x0;i<x1;i++)co_pixels[(j-co_ty)*co_tw+i-co_tx]=color;}
static void co_tank(int x,int y,int dir,uint16_t c){co_paint(x,y,14,14,0x2104);co_paint(x+2,y+1,10,12,c);co_paint(x+5,y+4,4,6,0xffff);if(dir==0)co_paint(x+6,y-1,2,8,c);if(dir==1)co_paint(x+7,y+6,8,2,c);if(dir==2)co_paint(x+6,y+7,2,8,c);if(dir==3)co_paint(x-1,y+6,8,2,c);}
static void co_render(void){int tile,i,j,x,y;co_enemy *e;co_shot *s;
    for(tile=0;tile<180;tile++)if(co.dirty[tile]){
        co.dirty[tile]=0;x=tile%15*16;y=tile/15*16;co_tx=co.bx+x*co.bw/240;co_ty=co.by+y*co.bh/192;co_tw=co.bx+(x+16)*co.bw/240-co_tx;co_th=co.by+(y+16)*co.bh/192-co_ty;
        for(i=0;i<co_tw*co_th;i++)co_pixels[i]=0x0842;
        if(co.id==10){
            j=co.map[tile];if(j==1){co_paint(x,y,16,16,0xa304);co_paint(x,y+7,16,1,0x2104);co_paint(x+7,y,1,8,0x2104);co_paint(x+3,y+8,1,8,0x2104);}
            if(j==2){co_paint(x,y,16,16,0x8410);co_paint(x+2,y+2,12,12,0xbdf7);}
            if(j==3){co_paint(x,y,16,16,0x1258);co_paint(x+2,y+5,10,2,0x4e9f);}
            if(j==5){co_paint(x+1,y+1,14,14,0xffe0);co_paint(x+4,y+4,8,8,0xf800);}
            co_tank(co.px,co.py,co.dir,co.invul&&co.frame%4<2?0xffff:0x07ff);
        }else{
            if(tile%7==0)co_paint(x+5,y+8,1,1,0x8410);
            co_paint(co.px+6,co.py,4,16,co.invul?0xffff:0x07ff);co_paint(co.px,co.py+8,16,6,0x07ff);co_paint(co.px+5,co.py+14,6,3,0xfd20);
            if(co.boss){co_paint(co.boss_x,10,56,20,0x780f);co_paint(co.boss_x+18,8,20,24,0xf81f);co_paint(co.boss_x+6,24,8,6,0xffe0);co_paint(co.boss_x+42,24,8,6,0xffe0);co_paint(co.boss_x,6,56*co.boss_hp/co.boss_max,2,0xf800);}
        }
        for(i=0;i<CO_ENEMIES;i++){e=&co.enemies[i];if(!e->hp)continue;if(co.id==10)co_tank(e->x,e->y,e->dir,e->type==2?0xf81f:e->type==1?0xfd20:0xf800);else{co_paint(e->x,e->y+3,16,8,e->type==2?0xf81f:e->type==1?0xfd20:0xf800);co_paint(e->x+6,e->y,4,16,0xffe0);}}
        for(i=0;i<CO_SHOTS;i++){s=&co.shots[i];if(s->alive)co_paint(s->x,s->y,co.id==11&&!s->enemy&&s->power>=3?3:2,co.id==11?6:3,s->enemy?0xf986:0x7ff8);}
        if(co.drop_life){co_paint(co.drop_x,co.drop_y,9,9,0x07e0);co_paint(co.drop_x+3,co.drop_y+1,3,7,0xffff);co_paint(co.drop_x+1,co.drop_y+3,7,3,0xffff);}
        if(co.id==10&&co.map[tile]==4){co_paint(x,y,16,3,0x0340);co_paint(x+2,y+5,3,10,0x05e0);co_paint(x+9,y+3,3,10,0x0340);}
        if(co.shield){co_paint(co.px-1,co.py-1,18,1,0xffe0);co_paint(co.px-1,co.py+17,18,1,0xffe0);}
        lcd_color_fill(co_tx,co_ty,co_tx+co_tw-1,co_ty+co_th-1,co_pixels);
    }
}
static void co_text(co_rect r,const char *s,uint16_t c){int w=zh_width(s,16),x=r.x+(r.w-w)/2;if(x<r.x)x=r.x;zh_draw(x,r.y+(r.h-16)/2,r.x+r.w-x,16,16,s,c,0x0842);}
static void co_button(co_rect r,const char *s){lcd_fill(r.x,r.y,r.x+r.w-1,r.y+r.h-1,0x0842);lcd_draw_rectangle(r.x,r.y,r.x+r.w-1,r.y+r.h-1,0x07ff);co_text(r,s,0xffff);}
static void co_hud(void){char b[72];co_rect r={8,36,(int16_t)(lcddev.width-16),20};lcd_fill(r.x,r.y,r.x+r.w-1,r.y+19,0x0842);sprintf(b,"%s %u   HP %u   %lu   W%u  S%u",co.id==10?"TANK":"SPACE",co.level,co.hp,(unsigned long)co.score,co.weapon+1,co.shield);co_text(r,b,0xffe0);}
static void co_end(uint8_t won){co.won=won;co.state=CO_OVER;co.armed=0;console_record(co.id,co.score);if(won)console_won(co.id);console_flush();combat_draw();}
static void co_drop(int x,int y){co.drop_life=300;co.drop_x=x;co.drop_y=y;co.drop_kind=co_random()%4;}
static void co_hurt(void){if(co.invul)return;if(co.shield){co.shield=0;co.invul=30;return;}if(co.hp)co.hp--;co.invul=60;if(!co.hp)co_end(0);}
static void co_shoot(int x,int y,int vx,int vy,int enemy,int power){int i;for(i=0;i<CO_SHOTS;i++)if(!co.shots[i].alive){co_shot *s=&co.shots[i];s->x=x;s->y=y;s->vx=vx;s->vy=vy;s->enemy=enemy;s->power=power;s->alive=1;return;}}
static int co_solid(int x,int y,int ignore){int i,xx,yy;if(x<0||y<0||x>226||y>178)return 1;for(yy=y/16;yy<=(y+13)/16;yy++)for(xx=x/16;xx<=(x+13)/16;xx++){i=co.map[yy*15+xx];if(i==1||i==2||i==3||i==5)return 1;}
    for(i=0;i<CO_ENEMIES;i++)if(i!=ignore&&co.enemies[i].hp&&co_overlap(x,y,14,14,co.enemies[i].x,co.enemies[i].y,14,14))return 1;
    if(ignore>=0&&co_overlap(x,y,14,14,co.px,co.py,14,14))return 1;return 0;
}
static void co_level(void){int x,y,i;memset(co.map,0,sizeof co.map);memset(co.enemies,0,sizeof co.enemies);memset(co.shots,0,sizeof co.shots);co.spawned=co.kills=co.boss=0;co.total=co.id==10?6+co.level*2:10+co.level*3;co.frame=co.fire_at=0;co.px=112;co.py=156;co.dir=0;co.drop_life=0;co.invul=60;co.bombs=1;
    if(co.id==10){for(y=2;y<10;y++)for(x=1;x<14;x++){i=0;if((x+co.level)%3==0&&y%4!=0)i=1;if(y==5&&(x==3||x==11))i=2;if(y==7&&(x==6||x==8))i=3;if(y==3&&(x==5||x==9))i=4;co.map[y*15+x]=i;}
        co.map[11*15+7]=5;co.map[10*15+6]=co.map[10*15+7]=co.map[10*15+8]=1;co.map[11*15+6]=co.map[11*15+8]=1;
        /* Keep spawn and initial player area clear. */co.py=144;co.map[9*15+7]=co.map[9*15+8]=0;
    }
    memset(co.dirty,1,sizeof co.dirty);
}
static void co_kill(co_enemy *e){int x=e->x,y=e->y;e->hp=0;co.kills++;co.score+=100*(1+e->type);if(co.kills%3==0)co_drop(x,y);console_record(co.id,co.score);}
static void co_step(uint8_t move,uint8_t fire,uint16_t tx,uint16_t ty,uint8_t drag){
    int i,j,d,x,y,v,speed;co_enemy *e;co_shot *s;co_mark_actors();co.frame++;co.elapsed+=30;if(co.invul)co.invul--;if(co.boost)co.boost--;
    if(co.id==10){if(move<4){co.dir=move;speed=co.boost?2:1;for(j=0;j<speed;j++){x=co.px+co_dx[move];y=co.py+co_dy[move];if(!co_solid(x,y,-1)){co.px=x;co.py=y;}}}}
    else if(drag){x=(int)(tx-co.bx)*240/co.bw-8;y=(int)(ty-co.by)*192/co.bh-8;if(x<0)x=0;if(x>224)x=224;if(y<36)y=36;if(y>174)y=174;co.px=x;co.py=y;}
    if((fire||co.id==11||co.auto_fire)&&(uint16_t)(co.frame-co.fire_at)>=(co.id==10?10:co.boost?4:7)){
        co.fire_at=co.frame;if(co.id==10)co_shoot(co.px+6+co_dx[co.dir]*9,co.py+6+co_dy[co.dir]*9,co_dx[co.dir]*5,co_dy[co.dir]*5,0,co.weapon+1);
        else{co_shoot(co.px+7,co.py-4,0,-6,0,co.weapon==2?3:1);if(co.weapon==1){co_shoot(co.px+2,co.py,-1,-5,0,1);co_shoot(co.px+12,co.py,1,-5,0,1);}}
    }
    if(co.spawned<co.total&&co.frame%40==1){for(i=0;i<CO_ENEMIES;i++)if(!co.enemies[i].hp){x=16+(co_random()%3)*96;if(co.id==10&&co_solid(x,1,i))break;e=&co.enemies[i];e->x=x;e->y=1;e->type=co_random()%3;e->hp=e->type==2?3:1;e->dir=2;e->cool=co.frame;co.spawned++;break;}}
    for(i=0;i<CO_ENEMIES;i++){e=&co.enemies[i];if(!e->hp)continue;
        if(co.id==10){if(co.frame%12==0){x=e->type==1?co.px:112;y=e->type==1?co.py:176;e->dir=abs(x-e->x)>abs(y-e->y)?(x>e->x?1:3):(y>e->y?2:0);if(co_random()%4==0)e->dir=co_random()%4;}
            if(e->type==1||co.frame%2==0){x=e->x+co_dx[e->dir];y=e->y+co_dy[e->dir];if(!co_solid(x,y,i)){e->x=x;e->y=y;}else e->dir=(e->dir+1)%4;}
        }else{if(e->type==1||co.frame%2==0)e->y++;if(e->type==1){e->x+=(co.frame/20)%2?1:-1;if(e->x<0)e->x=0;if(e->x>224)e->x=224;}
            if(e->y>=178){e->hp=0;co.kills++;co_hurt();if(co.state!=CO_PLAY)return;continue;}
            if(co_overlap(e->x,e->y,16,16,co.px,co.py,16,16)){e->hp=0;co.kills++;co_hurt();}
        }
        if(co.state!=CO_PLAY)return;
        if(!e->hp)continue;
        if((uint16_t)(co.frame-e->cool)>=(uint16_t)(65-co.diff*12-co.level*3)){e->cool=co.frame;d=co.id==10?e->dir:2;co_shoot(e->x+6+co_dx[d]*9,e->y+6+co_dy[d]*9,co_dx[d]*3,co_dy[d]*3,1,1);}
    }
    if(co.state!=CO_PLAY)return;
    if(co.id==11&&co.kills>=co.total&&!co.boss){co.boss=1;co.boss_x=90;co.boss_hp=co.boss_max=30+co.level*10+co.diff*10;co.boss_fire=co.frame;}
    if(co.boss){co.boss_x+=(co.frame/60)%2?1:-1;if(co.boss_x<8)co.boss_x=8;if(co.boss_x>176)co.boss_x=176;
        if((uint16_t)(co.frame-co.boss_fire)>=(co.boss_hp<co.boss_max/3?13:co.boss_hp<co.boss_max*2/3?20:28)){co.boss_fire=co.frame;v=co.boss_hp<co.boss_max/3?2:1;for(i=-v;i<=v;i++)co_shoot(co.boss_x+28,30,i,3,1,1);}
    }
    for(i=0;i<CO_SHOTS;i++){s=&co.shots[i];if(!s->alive)continue;s->x+=s->vx;s->y+=s->vy;if(s->x<0||s->x>=238||s->y<0||s->y>=190){s->alive=0;continue;}
        if(co.id==10){j=s->y/16*15+s->x/16;v=co.map[j];if(v==1||v==2||v==5){s->alive=0;if(v==1){co.map[j]=0;co.dirty[j]=1;}if(v==5){co_end(0);return;}continue;}}
        if(s->enemy){if(co_overlap(s->x,s->y,2,4,co.px,co.py,14,16)){s->alive=0;co_hurt();if(co.state!=CO_PLAY)return;}}
        else{for(j=0;j<CO_ENEMIES;j++){e=&co.enemies[j];if(e->hp&&co_overlap(s->x,s->y,3,6,e->x,e->y,14,16)){s->alive=0;if(e->hp<=s->power)co_kill(e);else e->hp-=s->power;break;}}
            if(s->alive&&co.boss&&co_overlap(s->x,s->y,3,6,co.boss_x,10,56,22)){s->alive=0;co.boss_hp=co.boss_hp>s->power?co.boss_hp-s->power:0;}
        }
    }
    if(co.drop_life){co.drop_life--;if(co.id==11&&co.frame%2==0)co.drop_y++;if(co.drop_y>181)co.drop_life=0;
        if(co_overlap(co.px,co.py,16,16,co.drop_x,co.drop_y,9,9)){if(co.drop_kind==0)co.shield=1;else if(co.drop_kind==1){if(co.hp<5)co.hp++;}else if(co.drop_kind==2)co.weapon=(co.weapon+1)%3;else co.boost=240;co.drop_life=0;console_beep(HAL_GetTick(),30);}
    }
    if((co.id==10&&co.kills>=co.total)||(co.id==11&&co.boss&&!co.boss_hp)){
        co.score+=1000*co.level;console_record(co.id,co.score);if(co.level==4){co_end(1);return;}co.level++;co.state=CO_NEXT;co.armed=0;console_flush();combat_draw();return;
    }
    co_mark_actors();co_render();if(co.frame%8==0)co_hud();
}
void combat_draw(void){int i;char b[16];co_rect r={8,8,(int16_t)(lcddev.width-104),28};lcd_clear(0x0842);co_text(r,co.id==10?"TANK":"SPACE",0x07ff);
    if(co.state==CO_PLAY){memset(co.dirty,1,sizeof co.dirty);co_render();co_hud();co_button(co.keys[5],"PAUSE");if(co.id==10){for(i=0;i<4;i++)co_button(co.keys[i],i==0?"UP":i==1?"RIGHT":i==2?"DOWN":"LEFT");co_button(co.keys[4],co.auto_fire?"AUTO_FIRE":"FIRE");}else co_button(co.keys[4],co.bombs?"BOMB":"BOMB_EMPTY");return;}
    r.x=8;r.w=lcddev.width-16;r.y=60;r.h=30;
    if(co.state==CO_OVER){arcade_result_panel(co.id,co.won,co.score,console_best(co.id));co_button(co.menu[0],"PLAY AGAIN");co_button(co.menu[2],"HOME");return;}
    if(co.state==CO_COUNT){sprintf(b,"%lu",(unsigned long)(3-(HAL_GetTick()-co.count_at)/1000));co_text(r,b,0xffe0);return;}
    co_text(r,co.state==CO_PAUSE?"GAME PAUSED":co.state==CO_NEXT?"NEXT_STAGE":co.id==10?"TANK_HELP":"SPACE_HELP",0xffff);
    co_button(co.menu[0],co.state==CO_PAUSE?"RESUME":"START");co_button(co.menu[1],co.state==CO_READY?(co.diff==0?"EASY":co.diff==1?"NORMAL":"HARD"):"RESTART");co_button(co.menu[2],"HOME");
}
void combat_start(uint8_t id,uint32_t now,uint32_t seed,uint8_t difficulty){int size,top,i;memset(&co,0,sizeof co);co.id=id;co.seed=seed?seed:1;co.diff=difficulty%3;co.hp=3;co.level=1;co.sx=lcddev.width*3/5;co.sw=lcddev.width-co.sx-12;co.bx=8;co.by=60;co.bw=co.sx-20;co.bh=lcddev.height-70;if(co.bh>co.bw*192/240)co.bh=co.bw*192/240;
    size=(co.sw-12)/3;if(size>(lcddev.height-120)/3)size=(lcddev.height-120)/3;top=108;
    for(i=0;i<4;i++){co.keys[i].x=co.sx+(co.sw-size)/2+co_dx[i]*(size+4);co.keys[i].y=top+(size+4)+co_dy[i]*(size+4);co.keys[i].w=co.keys[i].h=size;}
    co.keys[4].x=co.sx;co.keys[4].y=60;co.keys[4].w=co.sw;co.keys[4].h=36;co.keys[5].x=lcddev.width-88;co.keys[5].y=8;co.keys[5].w=80;co.keys[5].h=28;
    for(i=0;i<3;i++){co.menu[i].x=lcddev.width/2-100;co.menu[i].y=(lcddev.height>=400?210:128)+i*(lcddev.height>=400?65:46);co.menu[i].w=200;co.menu[i].h=lcddev.height>=400?48:36;}
    co.last=now;co_level();co.state=CO_READY;combat_draw();
}
uint8_t combat_tick(uint32_t now,uint16_t x,uint16_t y,uint8_t press,uint8_t down){int i;uint8_t move=255,fire=0,drag=0;uint16_t tx=x,ty=y;
    if(!down)co.armed=1;
    if(co.state==CO_COUNT){if(now-co.count_at>=3000){co.state=CO_PLAY;co.last=now;co.armed=0;combat_draw();}else if((now-co.count_at)/1000!=(co.hud_at-co.count_at)/1000){co.hud_at=now;combat_draw();}return 0;}
    if(co.state!=CO_PLAY){if(!press||!co.armed)return 0;
        if(co_hit(co.menu[2],x,y)){console_record(co.id,co.score);console_flush();return 1;}
        if(co_hit(co.menu[1],x,y)&&co.state!=CO_OVER){if(co.state==CO_READY){co.diff=(co.diff+1)%3;combat_draw();}else combat_start(co.id,now,co.seed,co.diff);return 0;}
        if(co_hit(co.menu[0],x,y)){if(co.state==CO_OVER){combat_start(co.id,now,co.seed,co.diff);return 0;}if(co.state==CO_READY)console_started(co.id);if(co.state==CO_NEXT)co_level();co.state=CO_COUNT;co.count_at=co.hud_at=now;co.armed=0;combat_draw();}return 0;
    }
    if(!co.armed)return 0;
    if(press&&co_hit(co.keys[5],x,y)){co.state=CO_PAUSE;co.armed=0;console_record(co.id,co.score);console_flush();combat_draw();return 0;}
    if(down){for(i=0;i<4;i++)if(co_hit(co.keys[i],x,y))move=i;fire=co_hit(co.keys[4],x,y);drag=x>=co.bx&&x<co.bx+co.bw&&y>=co.by&&y<co.by+co.bh;}
    /* Read every currently valid capacitive contact; finger ordering may change. */
    if(down&&(tp_dev.touchtype&0x80)&&(tp_dev.sta&TP_PRES_DOWN))for(i=0;i<5;i++)if((tp_dev.sta&(1U<<i))&&tp_dev.x[i]<lcddev.width&&tp_dev.y[i]<lcddev.height){int j;for(j=0;j<4;j++)if(co_hit(co.keys[j],tp_dev.x[i],tp_dev.y[i]))move=j;if(co_hit(co.keys[4],tp_dev.x[i],tp_dev.y[i]))fire=1;}
    if(co.id==11&&press&&fire&&co.bombs){co_mark_actors();co.bombs--;memset(co.shots,0,sizeof co.shots);for(i=0;i<CO_ENEMIES;i++)if(co.enemies[i].hp)co_kill(&co.enemies[i]);if(co.boss)co.boss_hp=co.boss_hp>20?co.boss_hp-20:0;co.invul=60;co_render();combat_draw();}
    if(co.id==10&&!(tp_dev.touchtype&0x80)&&press&&fire){co.auto_fire=!co.auto_fire;co_button(co.keys[4],co.auto_fire?"AUTO_FIRE":"FIRE");}
    if(now-co.last>=30){co.last=now;co_step(move,fire,tx,ty,drag);}return 0;
}
