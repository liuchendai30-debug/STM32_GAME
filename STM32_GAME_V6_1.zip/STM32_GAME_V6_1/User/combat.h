#ifndef COMBAT_H
#define COMBAT_H
#include <stdint.h>
void combat_start(uint8_t id,uint32_t now,uint32_t seed,uint8_t difficulty);
uint8_t combat_tick(uint32_t now,uint16_t x,uint16_t y,uint8_t press,uint8_t down);
void combat_draw(void);
#endif
