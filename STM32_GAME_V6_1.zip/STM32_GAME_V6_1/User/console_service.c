#include "console_service.h"
#include "./BSP/24CXX/24cxx.h"
#include "./BSP/BEEP/beep.h"
#include <string.h>

/* V4: 88-byte records at 64..151 and 160..247. Preserve calibration.
 * Migrate V3 by writing opposite its newest slot; V2 first stages a V3
 * record at 168 so every interrupted write retains a complete old record. */
#define RECORD_SIZE 88
static uint32_t best[12], sequence, beep_end;
static uint16_t plays[12];
static uint8_t wins[12],options[8],brightness,touch_ms,idle_on;
static uint8_t ext_dirty,ext_error,ext_seq,ext_slot;
static void ext_load(void);
static void ext_flush(void);
static uint8_t sound_on, dirty, save_error, current_slot, migrate_v2;
static uint32_t get32(const uint8_t *p) {
    return (uint32_t)p[0]|((uint32_t)p[1]<<8)|((uint32_t)p[2]<<16)|((uint32_t)p[3]<<24);
}
static void put32(uint8_t *p,uint32_t v) {
    uint8_t i; for(i=0;i<4;i++) p[i]=(uint8_t)(v>>(8*i));
}
static uint32_t crc(const uint8_t *p,uint8_t len) {
    uint32_t c=0xffffffffU; uint8_t i;
    while(len--) { c^=*p++; for(i=0;i<8;i++) c=(c>>1)^((c&1)?0xedb88320U:0); }
    return ~c;
}
static uint8_t valid_v3(const uint8_t *r) {
    return r[0]==0xa5 && r[1]=='G' && r[2]=='C' && r[3]==3 && r[4]<=1 &&
      r[5]>=20 && r[5]<=100 && r[6]>=10 && r[6]<=30 && r[7]<=1 &&
      r[68]<=2 && r[69]<=2 && r[70]<=2 && r[71]<=2 && r[72]<=1 && get32(r+76)==crc(r,76);
}
static uint8_t valid(const uint8_t *r){
    return r[0]==0xa5&&r[1]=='G'&&r[2]=='C'&&r[3]==4&&r[4]<=1&&
      r[5]>=20&&r[5]<=100&&r[6]>=10&&r[6]<=30&&r[7]<=1&&
      (r[82]&3)<=2&&((r[82]>>2)&3)<=2&&((r[82]>>4)&3)<=2&&((r[82]>>6)&3)<=2&&r[83]<=1&&get32(r+84)==crc(r,84);
}
static uint8_t valid_v2(const uint8_t *r) {
    return r[0]==0xa5 && r[1]=='G' && r[2]=='C' && r[3]==2 && r[4]<=1 && get32(r+36)==crc(r,36);
}
void console_init(void) {
    uint8_t a[RECORD_SIZE],b[RECORD_SIZE],*r=0,i,va,vb;
    beep_init();BEEP(0);at24cxx_init();
    memset(best,0,sizeof best);memset(plays,0,sizeof plays);memset(wins,0,sizeof wins);memset(options,0,sizeof options);
    options[1]=options[2]=options[3]=1; brightness=100;touch_ms=18;idle_on=1;
    sequence=0;current_slot=0;dirty=save_error=sound_on=migrate_v2=0;beep_end=0;
    at24cxx_read(64,a,88);at24cxx_read(160,b,88);va=valid(a);vb=valid(b);
    if(va && (!vb || (int32_t)(get32(a+8)-get32(b+8))>0)){r=a;current_slot=0;}
    else if(vb){r=b;current_slot=1;}
    if(r){
        sound_on=r[4];brightness=r[5];touch_ms=r[6];idle_on=r[7];sequence=get32(r+8);
        for(i=0;i<10;i++){best[i]=get32(r+12+4*i);plays[i]=r[52+2*i]|((uint16_t)r[53+2*i]<<8);wins[i]=r[72+i];}
        for(i=0;i<4;i++)options[i]=(r[82]>>(2*i))&3;options[4]=r[83];
    }else{
        at24cxx_read(64,a,80);at24cxx_read(168,b,80);va=valid_v3(a);vb=valid_v3(b);
        if(va&&(!vb||(int32_t)(get32(a+8)-get32(b+8))>0)){r=a;current_slot=0;}
        else if(vb){r=b;current_slot=1;}
        if(r){
            sound_on=r[4];brightness=r[5];touch_ms=r[6];idle_on=r[7];sequence=get32(r+8);
            for(i=0;i<8;i++){best[i]=get32(r+12+4*i);plays[i]=r[44+2*i]|((uint16_t)r[45+2*i]<<8);wins[i]=r[60+i];options[i]=r[68+i];}dirty=1;
        }else{
            at24cxx_read(64,a,40);at24cxx_read(128,b,40);va=valid_v2(a);vb=valid_v2(b);
            if(va&&(!vb||(int32_t)(get32(a+8)-get32(b+8))>0))r=a;else if(vb)r=b;
            if(r){sound_on=r[4];for(i=0;i<6;i++)best[i]=get32(r+12+4*i);dirty=migrate_v2=1;}
        }
    }
    ext_load();console_backlight(brightness);
}
uint32_t console_best(uint8_t id){return id<12?best[id]:0;}
void console_record(uint8_t id,uint32_t score){if(id<12&&score>best[id]){best[id]=score;if(id<10)dirty=1;else ext_dirty=1;}}
uint8_t console_option(uint8_t key){return key<8?options[key]:0;}
void console_set_option(uint8_t key,uint8_t value){if(key<8 && value<=(key==4?1:2)){options[key]=value;dirty=1;}}
uint16_t console_plays(uint8_t id){return id<12?plays[id]:0;}
uint8_t console_wins(uint8_t id){return id<12?wins[id]:0;}
void console_started(uint8_t id){if(id<12 && plays[id]<65535){plays[id]++;if(id<10)dirty=1;else ext_dirty=1;}}
void console_won(uint8_t id){if(id<12 && wins[id]<255){wins[id]++;if(id<10)dirty=1;else ext_dirty=1;}}
/* Derived from saved, monotonic records: trophies need no extra EEPROM writes. */
uint8_t console_trophy(uint8_t id){
    return console_medal(id)>0;
}
uint8_t console_medal(uint8_t id){static const uint32_t t[12][3]={{1000,4000,10000},{100,300,600},{1000,4000,10000},{2048,8000,20000},{500,1000,1400},{100,100,100},{1,7000,8500},{1,4000,4600},{10,25,50},{20,50,100},{1000,5000,15000},{1000,5000,15000}};uint8_t n=0;if(id>=12)return 0;if(id==5)return wins[id]>=10?3:wins[id]>=3?2:best[id]>=100?1:0;while(n<3&&best[id]>=t[id][n])n++;return n;}
uint32_t console_medal_goal(uint8_t id,uint8_t tier){static const uint32_t t[12][3]={{1000,4000,10000},{100,300,600},{1000,4000,10000},{2048,8000,20000},{500,1000,1400},{1,3,10},{1,7000,8500},{1,4000,4600},{10,25,50},{20,50,100},{1000,5000,15000},{1000,5000,15000}};return id<12&&tier<3?t[id][tier]:0;}
uint8_t console_brightness(void){return brightness;}
void console_set_brightness(uint8_t percent){if(percent>=20&&percent<=100){brightness=percent;dirty=1;console_backlight(percent);}}
uint8_t console_touch_ms(void){return touch_ms;}
void console_cycle_touch(void){touch_ms=touch_ms==18?10:touch_ms==10?30:18;dirty=1;}
uint8_t console_idle_enabled(void){return idle_on;}
void console_toggle_idle(void){idle_on=!idle_on;dirty=1;}
void console_defaults(void){sound_on=0;brightness=100;touch_ms=18;idle_on=1;memset(options,0,8);options[1]=options[2]=options[3]=1;dirty=1;BEEP(0);console_backlight(brightness);console_flush();}
uint8_t console_sound(void) {return sound_on;}
uint8_t console_save_error(void) {return save_error||ext_error;}
void console_toggle_sound(void) {sound_on=!sound_on;dirty=1;BEEP(0);beep_end=0;console_flush();}
void console_flush(void) {
    uint8_t r[RECORD_SIZE],verify[RECORD_SIZE],i,next; uint16_t base;
    ext_flush();if(!dirty)return;
    BEEP(0); beep_end=0;
    if(migrate_v2){
        memset(r,0,80);r[0]=0xa5;r[1]='G';r[2]='C';r[3]=3;r[4]=sound_on;r[5]=brightness;r[6]=touch_ms;r[7]=idle_on;
        put32(r+8,sequence+1);for(i=0;i<8;i++){put32(r+12+4*i,best[i]);r[44+2*i]=plays[i]&255;r[45+2*i]=plays[i]>>8;r[60+i]=wins[i];r[68+i]=options[i];}put32(r+76,crc(r,76));
        at24cxx_write_one_byte(168,0);at24cxx_write(169,r+1,79);at24cxx_write_one_byte(168,r[0]);at24cxx_read(168,verify,80);
        if(memcmp(r,verify,80)){save_error=1;return;}current_slot=1;sequence++;migrate_v2=0;
    }
    memset(r,0,sizeof r);r[0]=0xa5;r[1]='G';r[2]='C';r[3]=4;r[4]=sound_on;r[5]=brightness;r[6]=touch_ms;r[7]=idle_on;
    put32(r+8,sequence+1);for(i=0;i<10;i++){put32(r+12+4*i,best[i]);r[52+2*i]=plays[i]&255;r[53+2*i]=plays[i]>>8;r[72+i]=wins[i];}
    for(i=0;i<4;i++)r[82]|=options[i]<<(2*i);r[83]=options[4];put32(r+84,crc(r,84));
    next=current_slot^1;base=next?160:64;
    at24cxx_write_one_byte(base,0);
    at24cxx_write(base+1,r+1,RECORD_SIZE-1);
    at24cxx_write_one_byte(base,r[0]);
    at24cxx_read(base,verify,RECORD_SIZE);
    if(memcmp(r,verify,RECORD_SIZE)==0){current_slot=next;sequence++;dirty=0;save_error=0;}
    else save_error=1;
}
void console_beep(uint32_t now,uint16_t duration) {if(sound_on){BEEP(1);beep_end=now+duration;if(!beep_end)beep_end=1;}}
void console_service(uint32_t now) {if(beep_end && (int32_t)(now-beep_end)>=0){BEEP(0);beep_end=0;}}

/* Supplementary V5 records at 0..19 / 20..39, verified unused in this project's
 * drivers. Existing V4 slots and touch calibration are completely independent. */
static uint8_t ext_valid(const uint8_t *r){uint16_t c=(uint16_t)crc(r,18);return r[0]==0xb5&&r[16]==5&&r[17]==0&&r[18]==(uint8_t)c&&r[19]==(uint8_t)(c>>8);}
static void ext_load(void){uint8_t a[20],b[20],*r=0;int i;ext_dirty=ext_error=ext_seq=ext_slot=0;at24cxx_read(0,a,20);at24cxx_read(20,b,20);if(ext_valid(a)&&(!ext_valid(b)||(int8_t)(a[1]-b[1])>0))r=a;else if(ext_valid(b)){r=b;ext_slot=1;}if(!r)return;ext_seq=r[1];for(i=0;i<2;i++){best[10+i]=get32(r+2+4*i);plays[10+i]=r[10+2*i]|((uint16_t)r[11+2*i]<<8);wins[10+i]=r[14+i];}}
static void ext_flush(void){uint8_t r[20],v[20],slot=ext_slot^1;uint16_t c;int i;if(!ext_dirty)return;memset(r,0,20);r[0]=0xb5;r[1]=ext_seq+1;r[16]=5;for(i=0;i<2;i++){put32(r+2+4*i,best[10+i]);r[10+2*i]=plays[10+i];r[11+2*i]=plays[10+i]>>8;r[14+i]=wins[10+i];}c=(uint16_t)crc(r,18);r[18]=c;r[19]=c>>8;at24cxx_write_one_byte(slot*20,0);at24cxx_write(slot*20+1,r+1,19);at24cxx_write_one_byte(slot*20,r[0]);at24cxx_read(slot*20,v,20);if(!memcmp(r,v,20)){ext_slot=slot;ext_seq=r[1];ext_dirty=ext_error=0;}else ext_error=1;}
