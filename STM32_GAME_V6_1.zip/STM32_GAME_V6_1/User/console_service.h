#ifndef CONSOLE_SERVICE_H
#define CONSOLE_SERVICE_H
#include <stdint.h>
void console_init(void);
uint32_t console_best(uint8_t id);
void console_record(uint8_t id, uint32_t score);
uint8_t console_sound(void);
void console_toggle_sound(void);
void console_flush(void);
uint8_t console_save_error(void);
void console_beep(uint32_t now, uint16_t duration);
void console_service(uint32_t now);
uint8_t console_option(uint8_t key);
void console_set_option(uint8_t key,uint8_t value);
uint16_t console_plays(uint8_t id);
uint8_t console_wins(uint8_t id);
uint8_t console_trophy(uint8_t id);
uint8_t console_medal(uint8_t id);
uint32_t console_medal_goal(uint8_t id,uint8_t tier);
void console_started(uint8_t id);
void console_won(uint8_t id);
uint8_t console_brightness(void);
void console_set_brightness(uint8_t percent);
uint8_t console_touch_ms(void);
void console_cycle_touch(void);
uint8_t console_idle_enabled(void);
void console_toggle_idle(void);
void console_defaults(void);
void console_backlight(uint8_t percent);
#endif
