#include "ember_save.h"
#include "console_service.h"
#include "./BSP/24CXX/24cxx.h"
#include <string.h>
/* Two 13-byte records in the remaining EEPROM gaps. Migrate old console
 * records first: V2 formerly occupied part of the 152..159 gap. */
ember_record ember_stats;
static uint8_t em_slot,em_seq,em_error,em_loaded,em_cached[10];
static uint16_t em_address(uint8_t n){return n<11?53+n:n<19?152+n-11:248+n-19;}
static uint16_t em_crc(const uint8_t *p){uint16_t c=0xffff;int i,j;for(i=0;i<11;i++){c^=(uint16_t)p[i]<<8;for(j=0;j<8;j++)c=(c&0x8000)?(c<<1)^0x1021:c<<1;}return c;}
static void em_read(int slot,uint8_t *p){int i;for(i=0;i<13;i++)at24cxx_read(em_address(slot*13+i),p+i,1);}
static int em_valid(uint8_t *p){uint16_t c=em_crc(p);return p[0]==0xf6&&p[11]==(uint8_t)c&&p[12]==c>>8&&(p[10]&0xfe)==0;}
static void em_pack(uint8_t *p){uint16_t f;uint32_t score=ember_stats.score>0xffffff?0xffffff:ember_stats.score;memset(p,0,13);p[0]=0xf6;p[1]=em_seq;p[2]=score;p[3]=score>>8;p[4]=score>>16;p[5]=ember_stats.plays;p[6]=ember_stats.wins;p[7]=ember_stats.weapons;p[8]=ember_stats.boss_end;f=ember_stats.floors[0]|(ember_stats.floors[1]<<3)|(ember_stats.floors[2]<<6);p[9]=f;p[10]=f>>8;}
void ember_load(void){uint8_t a[13],b[13],*p=0;uint16_t f;console_flush();memset(&ember_stats,0,sizeof ember_stats);em_loaded=0;em_seq=em_slot=0;em_error=console_save_error();if(em_error)return;em_read(0,a);em_read(1,b);if(em_valid(a)&&(!em_valid(b)||(int8_t)(a[1]-b[1])>0))p=a;else if(em_valid(b)){p=b;em_slot=1;}if(p){em_seq=p[1];ember_stats.score=p[2]|((uint32_t)p[3]<<8)|((uint32_t)p[4]<<16);ember_stats.plays=p[5];ember_stats.wins=p[6];ember_stats.weapons=p[7];ember_stats.boss_end=p[8];f=p[9]|((uint16_t)p[10]<<8);ember_stats.floors[0]=f&7;ember_stats.floors[1]=(f>>3)&7;ember_stats.floors[2]=(f>>6)&7;}em_pack(a);memcpy(em_cached,a+1,10);em_loaded=1;}
void ember_flush(void){uint8_t p[13],q[13],next=em_slot^1;uint16_t c;int i;console_flush();if(!em_loaded||console_save_error()){em_error=1;return;}em_pack(p);if(!memcmp(em_cached,p+1,10)){em_error=0;return;}p[1]=em_seq+1;c=em_crc(p);p[11]=c;p[12]=c>>8;at24cxx_write_one_byte(em_address(next*13),0);for(i=1;i<13;i++)at24cxx_write_one_byte(em_address(next*13+i),p[i]);at24cxx_write_one_byte(em_address(next*13),0xf6);em_read(next,q);if(memcmp(p,q,13)){em_error=1;return;}em_slot=next;em_seq=p[1];memcpy(em_cached,p+1,10);em_error=0;}
uint8_t ember_error(void){return em_error;}
