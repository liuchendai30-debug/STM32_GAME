#ifndef EMBER_SAVE_H
#define EMBER_SAVE_H
#include <stdint.h>
typedef struct {uint32_t score;uint8_t plays,wins,weapons,boss_end,floors[3];} ember_record;
extern ember_record ember_stats;
void ember_load(void);
void ember_flush(void);
uint8_t ember_error(void);
#endif
