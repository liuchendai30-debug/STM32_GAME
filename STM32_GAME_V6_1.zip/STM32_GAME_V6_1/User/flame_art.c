#include "flame_art.h"
/* Original compact pixel silhouettes. Each nontransparent row is emitted in
 * runs into the existing tile compositor, never a second framebuffer. */
static const char * const hero_shape[24]={
 "........a........",".......aaa.......","......aaaa.......",".....aaabbb......",
 "......bcccb......",".....bcccccb.....","....bcccccccb....","....bceeeecb.....",
 ".....bccbccb.....",".....bbbbbb......","...aaabbbbaaa....","..aaacccccbaaa...",
 "..aabccfccbbaa...","..abbbcffcbbbba..","..abbccccccbba...","..aabccccccbaa...",
 "..aabbbggbbbaa...","..aaabbbbbbaaa...","..aaabccbcbaaa...","...aabccbcbaa....",
 "....abccbcba.....",".....bccbcbb.....",".....bddbddb.....",".....bbb.bbb....."};
static const char * const enemy_shape[6][16]={
 {"......aaa.......","....abbbba......","...abbbbbba.....","..abccbbcba.....","..abccbbcba.....","...abbbbbba.....","....abbbba......",".....addda......","..aaaddddaaa....",".abadddddaba....",".abadddddaba....","..aadddddaa.....","....adddda......","....ab..ba......","....ab..ba......","...aaa..aaa....."},
 {"......aa........",".....abba.......","....abbbba......","...abbbbbba.....","..abbbccbbba....","..abccccc bba...","...accbccca.....","...abbbbbbba....","..abbbbbbbbba...","..abbddddbbaa...","..abbbddbbbaa...","...abbddbbaa....","....abbbbba.....",".....abbba......","......aba.......",".......a........"},
 {".a..........a...",".aa........aa...",".aba..aa..aba...",".abbabbbbabba...","..abbbbbbbba....","...abccbcba.....","....abbbba......","...aaddddaa.....","..adddddddda....",".adddddddddda...",".abadddddaba....","..aadddddaa.....","....adddda......","...abb..bba.....","..abb....bba....","..aaa....aaa...."},
 {".......a........","......aba.......","......aba.......",".....abbba......","....abccbba.....","...abccccbba....","..abccddccbba...","...abccccbba....","....abccbba.....",".....abbba......","......aba.......","......aba.......",".....abbba......","....abbbbba.....","...abbbbbbba....","...aaaaaaaaa...."},
 {"..a.........a...","..aa.......aa...","...aa..a..aa....","....aaaaaaa.....","...abbbbbba.....","...abccbcba.....","....abbbba......",".....adda.......","....adddda......","...adddddda.....","..adddddddda....","..adddddddda....","...adddddda.....","....aadda.......",".....abba.......","....aaaaaa......"},
 {".....aaaaa......","....abbbbba.....","...abbbbbbba....","...abccccbba....","...abccccbba....","....abbbbba.....","..aaaabbbaaaa...",".abbbbddbbbbba..",".abbbbddbbbbba..",".abbbddddbbbba..","..abbddddbbaa...","...abbbbbba.....","....abb bba.....","....abb bba.....","...abbb bbba....","...aaaa aaaa...."}
};
static void sprite(int x,int y,const char * const *rows,int count,const uint16_t *colors,flame_painter p){int yy,xx,start;char c;for(yy=0;yy<count;yy++){xx=0;while(rows[yy][xx]){c=rows[yy][xx];start=xx;while(rows[yy][xx]==c)xx++;if(c>='a'&&c<='g')p(x+start,y+yy,xx-start,1,colors[c-'a']);}}}
void flame_hero(int x,int y,int hero,int frame,int moving,int flash,flame_painter p){uint16_t c[7]={0xa8a7,0x1083,0xa536,0x52cd,0x0842,0xe6b2,0xfe64};int bob=moving?((frame/6)&1):0;
 p(x-8,y+9,17,3,0x0802);if(hero==1){c[0]=0x226d;c[2]=0x8c96;c[4]=0x5fff;c[5]=0x4531;}if(hero==2){c[0]=0x238b;c[2]=0x7c91;c[4]=0xdead;c[5]=0x6b88;}if(flash)c[0]=c[2]=c[5]=0xffff;
 sprite(x-8,y-14-bob,hero_shape,24,c,p);if(hero==1){p(x-5,y-7-bob,4,2,0x67ff);p(x+1,y-7-bob,4,2,0x67ff);}if(hero==2){p(x-5,y-12-bob,11,3,0x2c2b);p(x+4,y-16-bob,2,4,0xbe75);}
}
void flame_enemy(int x,int y,int type,int frame,int flash,flame_painter p){uint16_t c[7]={0x1083,0x8bd1,0xff13,0x61a9,0,0,0};int bob=(type==1||type==3)?((frame/10)&1):0;type%=6;
 if(type==0){c[1]=0xc5b4;c[3]=0x7a89;}if(type==1){c[1]=0x5252;c[2]=0xafff;c[3]=0x2930;}if(type==2){c[1]=0xb2e7;c[2]=0xfe00;c[3]=0x8a04;}if(type==3){c[1]=0x59b1;c[2]=0xac7f;c[3]=0xe75f;}if(type==4){c[1]=0x436a;c[2]=0xdfe9;c[3]=0x21e7;}if(type==5){c[1]=0x8c72;c[2]=0xfa43;c[3]=0x422b;}if(flash)c[1]=c[3]=0xffff;
 p(x-7,y+9,15,2,0x0802);sprite(x-8,y-10-bob,enemy_shape[type],16,c,p);
}
void flame_tile(int x,int y,int kind,int chapter,int north,int south,flame_painter p){static const uint16_t floorc[5]={0x1084,0x1883,0x1105,0x1086,0x1805},wall[5]={0x4a4b,0x5207,0x32a9,0x39cf,0x49aa},light[5]={0x7bd1,0x936b,0x63ef,0x7378,0x9bb2},accent[5]={0xc389,0xfb66,0x5c2b,0x951f,0xd4ad};int v=((x/16)*13+(y/16)*7)%11;uint16_t base=floorc[chapter];
 p(x,y,16,16,base);
 if(kind==1||kind==2){p(x,y,16,16,wall[chapter]);p(x+1,y+(north?7:2),14,2,light[chapter]);p(x+(y/16%2?5:11),y+3,1,11,base);if(!north)p(x,y,16,2,light[chapter]);if(!south){p(x,y+12,16,4,0x0802);p(x,y+11,16,1,base);}if(kind==1){p(x+8,y+3,2,4,base);p(x+6,y+6,3,2,base);}if(chapter==2&&v<4){p(x+1,y+1,2,10,accent[2]);p(x+3,y+7,4,2,0x23a8);}if(chapter==1&&v<3){p(x+3,y+5,2,5,accent[1]);p(x+4,y+9,5,1,0xbb23);}return;}
 /* Sparse chips, seams and motifs, not the tank engine's square grid. */
 if(v<3){p(x+3,y+11,7,1,base+0x0821);p(x+8,y+12,3,1,base+0x0821);}if(v==4){p(x+6,y+4,3,2,base+0x0842);p(x+7,y+6,1,2,base+0x0821);}if(v==7&&chapter==2){p(x+9,y+9,2,5,0x2267);p(x+7,y+10,5,1,0x2b09);}if(v==8&&chapter==3){p(x+7,y+6,1,5,0x4a13);p(x+5,y+8,5,1,0x4a13);}if(chapter==4&&x>=144&&x<176){p(x,y,16,16,0x3008);if(x==144)p(x+1,y,1,16,0x8b6c);if(x==160)p(x+14,y,1,16,0x8b6c);}
}
void flame_boss(int x,int y,int chapter,int frame,flame_painter p){int i,w,bob=(frame/9)&1;uint16_t gold=0xe5cf,ink=0x1083;
 p(x-20,y+16,40,3,0x0802);
 if(chapter==0){/* Ruined guardian: stone pauldrons, furnace heart, no cannon. */p(x-15,y-12,30,27,ink);p(x-20,y-5,9,19,0x528c);p(x+12,y-5,9,19,0x528c);p(x-11,y-8,22,21,0x9c92);p(x-8,y-18,16,13,0xb576);p(x-7,y-10,14,3,ink);p(x-5,y-10,3,2,0xfe28);p(x+3,y-10,3,2,0xfe28);p(x-5,y,10,9,0x7a27);p(x-2,y+1,4,5,0xfdc5);p(x-12,y+12,8,7,0x738e);p(x+4,y+12,8,7,0x738e);}
 else if(chapter==1){/* Forge warden: broad apron and asymmetric hammer. */for(i=0;i<4;i++)p(x-12+i*7,y-19-(i%2)*3-bob,4,12,0xfbe4);p(x-13,y-9,26,24,0x7207);p(x-10,y-8,20,18,0xb347);p(x-6,y-15,12,10,gold);p(x-5,y-10,10,2,ink);p(x-8,y+1,16,17,0x3948);p(x+16,y-13,3,30,0xa3cd);p(x+10,y-17,14,9,0x9c72);p(x-21,y+1,8,12,0xda65);}
 else if(chapter==2){/* Thorn queen: branching antlers, tapering foliage. */for(i=0;i<5;i++){w=5+i*3;p(x-w,y-1+i*4,2*w,4,i%2?0x32e9:0x2247);}p(x-6,y-14,12,14,0x8c8e);p(x-5,y-9,3,2,0xefb0);p(x+2,y-9,3,2,0xefb0);for(i=0;i<4;i++){p(x-8-i*3,y-15-i*2,4,6,0x648c);p(x+5+i*3,y-15-i*2,4,6,0x648c);}p(x-3,y-22,6,7,gold);p(x-21,y+7,6,3,0x648c);p(x+16,y+4,6,3,0x648c);}
 else if(chapter==3){/* Astral eye: floating diamond and detached satellites. */for(i=-13;i<=13;i++){w=14-(i<0?-i:i);p(x-w,y+i-bob,w*2+1,1,i%4?0x4932:0x7359);}p(x-8,y-3-bob,17,7,0xc65d);p(x-2,y-4-bob,5,9,0x18cd);p(x,y-2-bob,2,4,0xffff);p(x-22,y-4,5,5,0x9c5f);p(x+18,y+3,5,5,0x9c5f);p(x-2,y-22,5,5,0xc65d);}
 else{/* Fallen knight: split cloak, silver crown, long sword. */for(i=0;i<9;i++)p(x-8-i,y-7+i*3,16+i*2,3,i%3?0x580d:0x38a9);p(x-8,y-17,16,15,0x9c96);p(x-9,y-18,18,3,gold);p(x-9,y-22,3,6,gold);p(x-1,y-24,3,7,gold);p(x+6,y-22,3,6,gold);p(x-6,y-9,12,3,ink);p(x-3,y-9,6,2,0xfd86);p(x-9,y-1,18,15,0x5ad0);p(x-3,y+1,6,7,gold);p(x+18,y-17,3,35,0xce9c);p(x+13,y+8,13,3,gold);p(x-9,y+14,7,6,0x9c96);p(x+3,y+14,7,6,0x9c96);}
}
