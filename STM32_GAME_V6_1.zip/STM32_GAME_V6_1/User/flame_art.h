#ifndef FLAME_ART_H
#define FLAME_ART_H
#include <stdint.h>
typedef void (*flame_painter)(int x,int y,int w,int h,uint16_t color);
void flame_tile(int x,int y,int kind,int chapter,int north,int south,flame_painter p);
void flame_hero(int x,int y,int hero,int frame,int moving,int flash,flame_painter p);
void flame_enemy(int x,int y,int type,int frame,int flash,flame_painter p);
void flame_boss(int x,int y,int chapter,int frame,flame_painter p);
#endif
