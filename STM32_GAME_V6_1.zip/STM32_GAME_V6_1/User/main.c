/*
 * STM32F103ZET6 touchscreen brick breaker
 *
 * Hardware base:
 *   ALIENTEK STM32F103ZET6 board
 *   ALIENTEK TFT LCD and touchscreen
 *
 * Control:
 *   Drag on the touchscreen to move the paddle.
 *   Tap the play field to launch the ball.
 */

#include "./SYSTEM/sys/sys.h"
#include "./SYSTEM/usart/usart.h"
#include "./SYSTEM/delay/delay.h"
#include "./BSP/LED/led.h"
#include "./BSP/LCD/lcd.h"
#include "./BSP/TOUCH/touch.h"

#include "ui_zh.h"
#include "arcade.h"
#include "shell.h"
#include "console_service.h"
#include "clock5.h"

#define GAME_MAX_ROWS              6
#define GAME_MAX_COLS              10
#define GAME_MAX_LEVEL             8
#define GAME_START_LIVES           3

#define GAME_FP_SHIFT              8
#define GAME_FP_ONE                (1L << GAME_FP_SHIFT)
#define GAME_FRAME_MS              16U
#define TOUCH_POLL_MS              5U
#define TOUCH_DEBOUNCE_MS          18U

#define COLOR_GAME_BG              0X0841
#define COLOR_PANEL_BG             0X10A2
#define COLOR_PANEL_LIGHT          0X2145
#define COLOR_BORDER               0X4A69
#define COLOR_ACCENT               0X07FF
#define COLOR_ACCENT_DARK          0X0451
#define COLOR_ORANGE               0XFD20
#define COLOR_BALL                 0XFFE0
#define COLOR_PADDLE               0X07FF
#define COLOR_DANGER               0XF986

typedef enum
{
    GAME_STATE_MENU = 0,
    GAME_STATE_READY,
    GAME_STATE_PLAYING,
    GAME_STATE_PAUSED,
    GAME_STATE_OVER,
    GAME_STATE_WIN
} game_state_t;

typedef struct
{
    int16_t x;
    int16_t y;
    int16_t w;
    int16_t h;
} ui_rect_t;

typedef struct
{
    uint16_t x;
    uint16_t y;
    uint8_t raw_down;
    uint8_t stable_down;
    uint8_t press_event;
    uint8_t release_event;
    uint32_t last_poll_ms;
    uint32_t raw_change_ms;
} touch_input_t;

typedef struct
{
    game_state_t state;
    game_state_t resume_state;

    uint16_t screen_w;
    uint16_t screen_h;
    uint16_t hud_h;
    uint16_t field_left;
    uint16_t field_right;
    uint16_t field_top;
    uint16_t field_bottom;

    int16_t paddle_x;
    int16_t paddle_target_x;
    int16_t paddle_y;
    int16_t paddle_w;
    int16_t paddle_h;
    int16_t base_paddle_w,power_x,power_y;
    uint8_t power_kind,shield;
    uint8_t slow,sticky,laser;
    int16_t laser_x[2],laser_y[2];
    uint32_t laser_at;

    int32_t ball_x;
    int32_t ball_y;
    int32_t ball_vx;
    int32_t ball_vy;
    uint8_t ball_r;

    uint8_t bricks[GAME_MAX_ROWS][GAME_MAX_COLS];
    uint8_t brick_rows;
    uint8_t brick_cols;
    uint16_t brick_x0;
    uint16_t brick_y0;
    uint16_t brick_w;
    uint16_t brick_h;
    uint16_t brick_gap;
    uint16_t bricks_left;

    uint32_t score;
    uint32_t best_score;
    uint8_t lives;
    uint8_t level;
    uint32_t last_frame_ms;
} brick_game_t;

static uint8_t g_extra_active;
static brick_game_t g_game;
static touch_input_t g_touch;
static ui_rect_t g_primary_button;
static ui_rect_t g_secondary_button;
static ui_rect_t g_tertiary_button;
static ui_rect_t g_ready_prompt;
static uint32_t g_led0_off_ms;
static uint32_t g_led1_off_ms;

static int32_t clamp_i32(int32_t value, int32_t low, int32_t high)
{
    if (value < low)
    {
        return low;
    }

    if (value > high)
    {
        return high;
    }

    return value;
}

static void ui_rect_set(ui_rect_t *rect, int16_t x, int16_t y, int16_t w, int16_t h)
{
    rect->x = x;
    rect->y = y;
    rect->w = w;
    rect->h = h;
}

static uint8_t ui_rect_contains(const ui_rect_t *rect, uint16_t x, uint16_t y)
{
    if ((int32_t)x < rect->x || (int32_t)y < rect->y)
    {
        return 0;
    }

    if ((int32_t)x >= ((int32_t)rect->x + rect->w))
    {
        return 0;
    }

    if ((int32_t)y >= ((int32_t)rect->y + rect->h))
    {
        return 0;
    }

    return 1;
}



static void ui_fill_rect(int32_t x1, int32_t y1, int32_t x2, int32_t y2, uint16_t color)
{
    x1 = clamp_i32(x1, 0, (int32_t)lcddev.width - 1);
    y1 = clamp_i32(y1, 0, (int32_t)lcddev.height - 1);
    x2 = clamp_i32(x2, 0, (int32_t)lcddev.width - 1);
    y2 = clamp_i32(y2, 0, (int32_t)lcddev.height - 1);

    if (x2 < x1 || y2 < y1)
    {
        return;
    }

    lcd_fill((uint16_t)x1, (uint16_t)y1, (uint16_t)x2, (uint16_t)y2, color);
}

static void ui_fill_circle(int16_t cx, int16_t cy, int16_t radius, uint16_t color)
{
    int16_t dy;
    int16_t dx;
    int32_t yy;

    for (dy = -radius; dy <= radius; dy++)
    {
        yy = (int32_t)cy + dy;

        if (yy < 0 || yy >= lcddev.height)
        {
            continue;
        }

        dx = radius;

        while (dx > 0 && ((int32_t)dx * dx + (int32_t)dy * dy) >
                         ((int32_t)radius * radius))
        {
            dx--;
        }

        ui_fill_rect((int32_t)cx - dx, yy, (int32_t)cx + dx, yy, color);
    }
}

static void ui_show_text(uint16_t x,
                         uint16_t y,
                         uint16_t width,
                         uint16_t height,
                         uint8_t font_size,
                         char *text,
                         uint16_t text_color,
                         uint16_t background_color)
{
    g_back_color = background_color;
    zh_draw(x, y, width, height, font_size, text, text_color, background_color);
}

static void ui_show_center_text(const ui_rect_t *area,
                                uint8_t font_size,
                                char *text,
                                uint16_t text_color,
                                uint16_t background_color)
{
    int32_t text_width;
    int32_t x;
    int32_t y;

    text_width = zh_width(text, font_size);
    x = area->x + ((int32_t)area->w - text_width) / 2;
    y = area->y + ((int32_t)area->h - font_size) / 2;

    if (x < area->x)
    {
        x = area->x;
    }

    if (y < area->y)
    {
        y = area->y;
    }

    ui_show_text((uint16_t)x,
                 (uint16_t)y,
                 (uint16_t)area->w,
                 (uint16_t)area->h,
                 font_size,
                 text,
                 text_color,
                 background_color);
}

static void ui_draw_button(const ui_rect_t *button,
                           char *text,
                           uint16_t fill_color,
                           uint16_t border_color,
                           uint16_t text_color,
                           uint8_t font_size)
{
    ui_fill_rect(button->x,
                 button->y,
                 (int32_t)button->x + button->w - 1,
                 (int32_t)button->y + button->h - 1,
                 fill_color);

    lcd_draw_rectangle((uint16_t)button->x,
                       (uint16_t)button->y,
                       (uint16_t)(button->x + button->w - 1),
                       (uint16_t)(button->y + button->h - 1),
                       border_color);

    if (button->w > 4 && button->h > 4)
    {
        lcd_draw_rectangle((uint16_t)(button->x + 1),
                           (uint16_t)(button->y + 1),
                           (uint16_t)(button->x + button->w - 2),
                           (uint16_t)(button->y + button->h - 2),
                           border_color);
    }

    ui_show_center_text(button, font_size, text, text_color, fill_color);
}

static void touch_input_update(uint32_t now_ms)
{
    uint8_t raw_down;

    g_touch.press_event = 0;
    g_touch.release_event = 0;

    if ((uint32_t)(now_ms - g_touch.last_poll_ms) < TOUCH_POLL_MS)
    {
        return;
    }

    g_touch.last_poll_ms = now_ms;
    tp_dev.scan(0);
    raw_down = (tp_dev.sta & TP_PRES_DOWN) ? 1U : 0U;

    if (raw_down &&
        tp_dev.x[0] < lcddev.width &&
        tp_dev.y[0] < lcddev.height)
    {
        g_touch.x = tp_dev.x[0];
        g_touch.y = tp_dev.y[0];
    }
    else if(raw_down)
    {
        raw_down=0; /* Invalid samples must not re-use a previous button position. */
    }

    if (raw_down != g_touch.raw_down)
    {
        g_touch.raw_down = raw_down;
        g_touch.raw_change_ms = now_ms;
    }

    if (g_touch.stable_down != g_touch.raw_down &&
        (uint32_t)(now_ms - g_touch.raw_change_ms) >=
        ((tp_dev.touchtype & 0x80) && g_touch.raw_down ? console_touch_ms()/3U : console_touch_ms()))
    {
        g_touch.stable_down = g_touch.raw_down;

        if (g_touch.stable_down)
        {
            g_touch.press_event = 1;
        }
        else
        {
            g_touch.release_event = 1;
        }
    }
}

static void feedback_hit(uint32_t now_ms)
{
    console_beep(now_ms, 20);
    LED0(0);
    g_led0_off_ms = now_ms + 35U;
}

static void feedback_miss(uint32_t now_ms)
{
    console_beep(now_ms, 100);
    LED1(0);
    g_led1_off_ms = now_ms + 180U;
}

static void feedback_service(uint32_t now_ms)
{
    if (g_led0_off_ms != 0U && (int32_t)(now_ms - g_led0_off_ms) >= 0)
    {
        LED0(1);
        g_led0_off_ms = 0U;
    }

    if (g_led1_off_ms != 0U && (int32_t)(now_ms - g_led1_off_ms) >= 0)
    {
        LED1(1);
        g_led1_off_ms = 0U;
    }
}

static ui_rect_t game_pause_button_rect(void)
{
    ui_rect_t rect;
    int16_t width;
    int16_t height;

    width = (g_game.screen_w >= 640U) ? 92 : 72;
    height = (g_game.screen_h >= 400U) ? 34 : 28;

    ui_rect_set(&rect,
                (int16_t)(g_game.screen_w - width - 10),
                (int16_t)((g_game.hud_h - height) / 2),
                width,
                height);

    return rect;
}

static void game_draw_hud_values(void)
{
    ui_rect_t pause_button=game_pause_button_rect();
    uint16_t y=(g_game.hud_h-16)/2, slot=pause_button.x/4, x;
    uint32_t values[4]; uint8_t i;
    static char *labels[4]={"SCORE","BEST","LEVEL","LIFE"};
    values[0]=g_game.score; values[1]=g_game.best_score;
    values[2]=g_game.level; values[3]=g_game.lives;
    for(i=0;i<4;i++) {
        x=i*slot+4;
        ui_show_text(x,y,32,20,16,labels[i],WHITE,COLOR_PANEL_BG);
        g_back_color=COLOR_PANEL_BG;
        lcd_show_xnum(x+34,y,values[i],i<2?5:1,16,0X80,i<2?COLOR_ACCENT:YELLOW);
    }
    ui_draw_button(&pause_button,"PAUSE",COLOR_ACCENT_DARK,COLOR_ACCENT,WHITE,16);
}

static void game_draw_hud(void)
{
    ui_fill_rect(0,
                 0,
                 (int32_t)g_game.screen_w - 1,
                 (int32_t)g_game.hud_h - 1,
                 COLOR_PANEL_BG);
    game_draw_hud_values();
}

static void game_draw_play_border(void)
{
    ui_fill_rect(g_game.field_left,
                 g_game.field_top,
                 g_game.field_right,
                 g_game.field_top + 2,
                 COLOR_BORDER);

    ui_fill_rect(g_game.field_left,
                 g_game.field_top,
                 g_game.field_left + 2,
                 g_game.field_bottom,
                 COLOR_BORDER);

    ui_fill_rect(g_game.field_right - 2,
                 g_game.field_top,
                 g_game.field_right,
                 g_game.field_bottom,
                 COLOR_BORDER);
}

static void game_restore_border_near_ball(int16_t ball_x, int16_t ball_y)
{
    int32_t radius;

    radius = (int32_t)g_game.ball_r + 2;

    if ((int32_t)ball_y - radius <= (int32_t)g_game.field_top + 2)
    {
        ui_fill_rect((int32_t)ball_x - radius,
                     g_game.field_top,
                     (int32_t)ball_x + radius,
                     g_game.field_top + 2,
                     COLOR_BORDER);
    }

    if ((int32_t)ball_x - radius <= (int32_t)g_game.field_left + 2)
    {
        ui_fill_rect(g_game.field_left,
                     (int32_t)ball_y - radius,
                     g_game.field_left + 2,
                     (int32_t)ball_y + radius,
                     COLOR_BORDER);
    }

    if ((int32_t)ball_x + radius >= (int32_t)g_game.field_right - 2)
    {
        ui_fill_rect(g_game.field_right - 2,
                     (int32_t)ball_y - radius,
                     g_game.field_right,
                     (int32_t)ball_y + radius,
                     COLOR_BORDER);
    }
}

static void game_get_brick_rect(uint8_t row, uint8_t col, ui_rect_t *rect)
{
    ui_rect_set(rect,
                (int16_t)(g_game.brick_x0 +
                          (uint16_t)col * (g_game.brick_w + g_game.brick_gap)),
                (int16_t)(g_game.brick_y0 +
                          (uint16_t)row * (g_game.brick_h + g_game.brick_gap)),
                (int16_t)g_game.brick_w,
                (int16_t)g_game.brick_h);
}

static uint16_t game_brick_color(uint8_t row)
{
    static const uint16_t colors[GAME_MAX_ROWS] =
    {
        RED,
        COLOR_ORANGE,
        YELLOW,
        GREEN,
        CYAN,
        MAGENTA
    };

    return colors[row % GAME_MAX_ROWS];
}

static void game_draw_brick(uint8_t row, uint8_t col)
{
    ui_rect_t rect;
    uint16_t color;

    game_get_brick_rect(row, col, &rect);
    color = g_game.bricks[row][col]==2?GRAY:g_game.bricks[row][col]==3?MAGENTA:game_brick_color(row);

    ui_fill_rect(rect.x,
                 rect.y,
                 (int32_t)rect.x + rect.w - 1,
                 (int32_t)rect.y + rect.h - 1,
                 color);

    lcd_draw_rectangle((uint16_t)rect.x,
                       (uint16_t)rect.y,
                       (uint16_t)(rect.x + rect.w - 1),
                       (uint16_t)(rect.y + rect.h - 1),
                       WHITE);
}

static void game_draw_all_bricks(void)
{
    uint8_t row;
    uint8_t col;

    for (row = 0; row < g_game.brick_rows; row++)
    {
        for (col = 0; col < g_game.brick_cols; col++)
        {
            if (g_game.bricks[row][col])
            {
                game_draw_brick(row, col);
            }
        }
    }
}

static void game_draw_paddle(void)
{
    ui_fill_rect(g_game.paddle_x,
                 g_game.paddle_y,
                 (int32_t)g_game.paddle_x + g_game.paddle_w - 1,
                 (int32_t)g_game.paddle_y + g_game.paddle_h - 1,
                 COLOR_PADDLE);

    ui_fill_rect(g_game.paddle_x + 4,
                 g_game.paddle_y + 2,
                 (int32_t)g_game.paddle_x + g_game.paddle_w - 5,
                 g_game.paddle_y + 3,
                 WHITE);
}

static void game_draw_ball(void)
{
    int16_t x;
    int16_t y;

    x = (int16_t)(g_game.ball_x >> GAME_FP_SHIFT);
    y = (int16_t)(g_game.ball_y >> GAME_FP_SHIFT);

    ui_fill_circle(x, y, g_game.ball_r, COLOR_BALL);
    ui_fill_circle((int16_t)(x - 2), (int16_t)(y - 2), 1, WHITE);
}

static void game_draw_ready_prompt(void)
{
    uint16_t bricks_bottom;
    int16_t prompt_width;
    int16_t prompt_height;
    int32_t prompt_y;

    bricks_bottom = (uint16_t)(g_game.brick_y0 +
                              g_game.brick_rows * g_game.brick_h +
                              (g_game.brick_rows - 1U) * g_game.brick_gap);

    prompt_width = (g_game.screen_w >= 640U) ? 270 : 190;
    prompt_height = (g_game.screen_h >= 400U) ? 48 : 38;
    prompt_y = ((int32_t)bricks_bottom + g_game.paddle_y - prompt_height) / 2;

    if (prompt_y < (int32_t)bricks_bottom + 8)
    {
        prompt_y = (int32_t)bricks_bottom + 8;
    }

    ui_rect_set(&g_ready_prompt,
                (int16_t)((g_game.screen_w - prompt_width) / 2),
                (int16_t)prompt_y,
                prompt_width,
                prompt_height);

    ui_draw_button(&g_ready_prompt,
                   "TOUCH TO LAUNCH",
                   COLOR_PANEL_LIGHT,
                   COLOR_ACCENT,
                   WHITE,
                   (g_game.screen_w >= 640U) ? 24 : 16);
}

static void game_clear_ready_prompt(void)
{
    ui_fill_rect(g_ready_prompt.x,
                 g_ready_prompt.y,
                 (int32_t)g_ready_prompt.x + g_ready_prompt.w - 1,
                 (int32_t)g_ready_prompt.y + g_ready_prompt.h - 1,
                 COLOR_GAME_BG);
}

static void game_restore_bricks_near_ball(int16_t ball_x, int16_t ball_y)
{
    uint8_t row;
    uint8_t col;
    ui_rect_t rect;
    int32_t ball_left;
    int32_t ball_right;
    int32_t ball_top;
    int32_t ball_bottom;

    ball_left = (int32_t)ball_x - g_game.ball_r;
    ball_right = (int32_t)ball_x + g_game.ball_r;
    ball_top = (int32_t)ball_y - g_game.ball_r;
    ball_bottom = (int32_t)ball_y + g_game.ball_r;

    for (row = 0; row < g_game.brick_rows; row++)
    {
        for (col = 0; col < g_game.brick_cols; col++)
        {
            if (!g_game.bricks[row][col])
            {
                continue;
            }

            game_get_brick_rect(row, col, &rect);

            if (ball_right >= rect.x &&
                ball_left <= (int32_t)rect.x + rect.w - 1 &&
                ball_bottom >= rect.y &&
                ball_top <= (int32_t)rect.y + rect.h - 1)
            {
                game_draw_brick(row, col);
            }
        }
    }
}

static void game_render_dynamic(int16_t old_paddle_x,
                                int16_t old_ball_x,
                                int16_t old_ball_y,int16_t old_paddle_w)
{
    int16_t new_ball_x;
    int16_t new_ball_y;

    ui_fill_circle(old_ball_x, old_ball_y, g_game.ball_r, COLOR_GAME_BG);

    if (old_paddle_x != g_game.paddle_x || old_paddle_w != g_game.paddle_w)
    {
        ui_fill_rect(old_paddle_x,
                     g_game.paddle_y,
                     (int32_t)old_paddle_x + old_paddle_w - 1,
                     (int32_t)g_game.paddle_y + g_game.paddle_h - 1,
                     COLOR_GAME_BG);
    }

    game_restore_bricks_near_ball(old_ball_x, old_ball_y);
    game_restore_border_near_ball(old_ball_x, old_ball_y);
    game_draw_paddle();

    new_ball_x = (int16_t)(g_game.ball_x >> GAME_FP_SHIFT);
    new_ball_y = (int16_t)(g_game.ball_y >> GAME_FP_SHIFT);
    ui_fill_circle(new_ball_x, new_ball_y, g_game.ball_r, COLOR_BALL);
    ui_fill_circle((int16_t)(new_ball_x - 2), (int16_t)(new_ball_y - 2), 1, WHITE);
}

static void game_draw_power(void)
{
    static const uint16_t colors[6]={WHITE,CYAN,YELLOW,GREEN,MAGENTA,RED};int i;
    if(g_game.power_kind)ui_fill_circle(g_game.power_x,g_game.power_y,g_game.ball_r,colors[g_game.power_kind]);
    if(g_game.shield)ui_fill_rect(g_game.field_left+2,g_game.field_bottom-2,g_game.field_right-2,g_game.field_bottom-1,YELLOW);
    for(i=0;i<2;i++)if(g_game.laser_y[i]>0)ui_fill_rect(g_game.laser_x[i],g_game.laser_y[i],g_game.laser_x[i]+1,g_game.laser_y[i]+5,RED);
}

static void game_draw_scene(void)
{
    lcd_clear(COLOR_GAME_BG);
    game_draw_hud();
    game_draw_play_border();
    game_draw_all_bricks();
    game_draw_paddle();
    game_draw_power();
    game_draw_ball();

    if (g_game.state == GAME_STATE_READY)
    {
        game_draw_ready_prompt();
    }
}



static void game_draw_menu(void){
    console_record(0,g_game.best_score);console_flush();shell_show();
}

static void game_draw_score_line(uint16_t y, char *label, uint32_t value, uint16_t color)
{
    uint16_t label_x;
    uint16_t value_x;

    label_x = (uint16_t)(g_game.screen_w / 2U - 92U);
    value_x = (uint16_t)(g_game.screen_w / 2U + 34U);

    ui_show_text(label_x,
                 y,
                 120,
                 28,
                 24,
                 label,
                 WHITE,
                 COLOR_GAME_BG);

    g_back_color = COLOR_GAME_BG;
    lcd_show_num(value_x, y, value, 5, 24, color);
}

static void game_draw_pause_screen(void)
{
    ui_rect_t title_area;
    int16_t button_width;
    int16_t button_height;
    int16_t first_y;

    lcd_clear(COLOR_GAME_BG);

    ui_rect_set(&title_area,
                0,
                (g_game.screen_h >= 400U) ? 42 : 20,
                (int16_t)g_game.screen_w,
                44);

    ui_show_center_text(&title_area,
                        (g_game.screen_w >= 640U) ? 32 : 24,
                        "GAME PAUSED",
                        COLOR_ACCENT,
                        COLOR_GAME_BG);

    game_draw_score_line((uint16_t)(title_area.y + 62), "SCORE", g_game.score, YELLOW);

    button_width = (g_game.screen_w >= 640U) ? 230 : 180;
    button_height = (g_game.screen_h >= 400U) ? 54 : 36;
    first_y = (g_game.screen_h >= 400U) ? (int16_t)(g_game.screen_h / 2 - 10) : (int16_t)(g_game.screen_h - 3 * button_height - 40);

    ui_rect_set(&g_primary_button,
                (int16_t)((g_game.screen_w - button_width) / 2),
                first_y,
                button_width,
                button_height);

    ui_rect_set(&g_secondary_button,
                g_primary_button.x,
                (int16_t)(g_primary_button.y + button_height + 14),
                button_width,
                button_height);

    ui_rect_set(&g_tertiary_button,
                g_primary_button.x,
                (int16_t)(g_secondary_button.y + button_height + 14),
                button_width,
                button_height);

    ui_draw_button(&g_primary_button,
                   "RESUME",
                   COLOR_ACCENT_DARK,
                   COLOR_ACCENT,
                   WHITE,
                   (g_game.screen_w >= 640U) ? 24 : 16);

    ui_draw_button(&g_secondary_button,
                   "RESTART",
                   COLOR_PANEL_LIGHT,
                   COLOR_ORANGE,
                   WHITE,
                   (g_game.screen_w >= 640U) ? 24 : 16);

    ui_draw_button(&g_tertiary_button,
                   "HOME",
                   COLOR_PANEL_LIGHT,
                   COLOR_BORDER,
                   WHITE,
                   (g_game.screen_w >= 640U) ? 24 : 16);
}

static void game_draw_end_screen(uint8_t won)
{
    int16_t button_width;
    int16_t button_height;
    int16_t first_y;

    arcade_result_panel(0,won,g_game.score,g_game.best_score);

    button_width = (g_game.screen_w >= 640U) ? 240 : 190;
    button_height = (g_game.screen_h >= 400U) ? 52 : 34;
    first_y = (g_game.screen_h >= 400U) ? 210 : 128;

    ui_rect_set(&g_primary_button,
                (int16_t)((g_game.screen_w - button_width) / 2),
                first_y,
                button_width,
                button_height);

    ui_rect_set(&g_secondary_button,
                g_primary_button.x,
                (int16_t)(g_primary_button.y + button_height + 18),
                button_width,
                button_height);

    ui_draw_button(&g_primary_button,
                   "PLAY AGAIN",
                   COLOR_ACCENT_DARK,
                   COLOR_ACCENT,
                   WHITE,
                   (g_game.screen_w >= 640U) ? 24 : 16);

    ui_draw_button(&g_secondary_button,
                   "HOME",
                   COLOR_PANEL_LIGHT,
                   COLOR_BORDER,
                   WHITE,
                   (g_game.screen_w >= 640U) ? 24 : 16);
}

static void game_reset_ball(void)
{
    g_game.paddle_w=g_game.base_paddle_w;g_game.power_kind=g_game.shield=0;
    g_game.slow=g_game.sticky=g_game.laser=0;g_game.laser_y[0]=g_game.laser_y[1]=0;g_game.laser_at=0;
    g_game.paddle_x = (int16_t)((g_game.screen_w - g_game.paddle_w) / 2);
    g_game.paddle_target_x = g_game.paddle_x;
    g_game.ball_x = ((int32_t)g_game.paddle_x + g_game.paddle_w / 2) << GAME_FP_SHIFT;
    g_game.ball_y = ((int32_t)g_game.paddle_y - g_game.ball_r - 3) << GAME_FP_SHIFT;
    g_game.ball_vx = 0;
    g_game.ball_vy = 0;
}

static void game_setup_level(void)
{
    uint8_t row;
    uint8_t col;
    uint16_t margin;
    uint16_t play_width;
    int16_t base_paddle_width;

    g_game.brick_cols = (g_game.screen_w >= 640U) ? 10 : 8;
    g_game.brick_rows = 4;

    if (g_game.level >= 3U)
    {
        g_game.brick_rows++;
    }

    if (g_game.level >= 5U)
    {
        g_game.brick_rows++;
    }

    g_game.brick_gap = (g_game.screen_w >= 640U) ? 6U : 4U;
    margin = (g_game.screen_w >= 640U) ? 24U : 12U;
    play_width = (uint16_t)(g_game.field_right - g_game.field_left + 1U);
    g_game.brick_x0 = (uint16_t)(g_game.field_left + margin);
    g_game.brick_y0 = (uint16_t)(g_game.field_top +
                                 ((g_game.screen_h >= 400U) ? 24U : 12U));
    g_game.brick_h = (g_game.screen_h >= 400U) ? 24U : 16U;
    g_game.brick_w = (uint16_t)((play_width -
                                 2U * margin -
                                 (g_game.brick_cols - 1U) * g_game.brick_gap) /
                                g_game.brick_cols);

    g_game.bricks_left = 0;

    for (row = 0; row < GAME_MAX_ROWS; row++)
    {
        for (col = 0; col < GAME_MAX_COLS; col++)
        {
            if (row < g_game.brick_rows && col < g_game.brick_cols)
            {
                g_game.bricks[row][col] = (g_game.level>=3 && (row+col)%5==0)?2:1;
                if(g_game.level>=2 && row==0 && col==g_game.level%g_game.brick_cols)g_game.bricks[row][col]=3;
                if(g_game.level%3==2 && (row+col)%3==0)g_game.bricks[row][col]=0;
                if(g_game.bricks[row][col])g_game.bricks_left++;
            }
            else
            {
                g_game.bricks[row][col] = 0;
            }
        }
    }

    base_paddle_width = (int16_t)(g_game.screen_w / 6U);

    if (base_paddle_width < 74)
    {
        base_paddle_width = 74;
    }

    g_game.paddle_w = (int16_t)(base_paddle_width - (g_game.level - 1U) * 6U);
    g_game.base_paddle_w=g_game.paddle_w;g_game.power_kind=g_game.shield=0;
    g_game.slow=g_game.sticky=g_game.laser=0;g_game.laser_y[0]=g_game.laser_y[1]=0;
    g_game.paddle_h = (g_game.screen_h >= 400U) ? 14 : 10;
    g_game.paddle_y = (int16_t)(g_game.field_bottom -
                                ((g_game.screen_h >= 400U) ? 30U : 22U));
    game_reset_ball();
}

static void game_start_new(uint32_t now_ms)
{
    console_started(0);
    g_game.score = 0;
    g_game.lives = GAME_START_LIVES;
    g_game.level = 1;
    g_game.state = GAME_STATE_READY;
    g_game.last_frame_ms = now_ms;
    game_setup_level();
    game_draw_scene();
}

static void game_finish(uint8_t won)
{
    if(won)console_won(0);
    if (g_game.score > g_game.best_score)
    {
        g_game.best_score = g_game.score;
        console_record(0, g_game.best_score);
    }

    g_game.state = won ? GAME_STATE_WIN : GAME_STATE_OVER;
    console_record(0, g_game.best_score);
    console_flush();
    game_draw_end_screen(won);
}

static void game_advance_level(uint32_t now_ms)
{
    if (g_game.level >= GAME_MAX_LEVEL)
    {
        game_finish(1);
        return;
    }

    g_game.level++;
    g_game.state = GAME_STATE_READY;
    g_game.last_frame_ms = now_ms;
    game_setup_level();
    game_draw_scene();
}

static void game_launch_ball(uint32_t now_ms)
{
    int32_t vx;
    int32_t vy;

    vx = 3L * GAME_FP_ONE + (int32_t)(g_game.level - 1U) * (GAME_FP_ONE / 4L);
    vy = 4L * GAME_FP_ONE + (int32_t)(g_game.level - 1U) * (GAME_FP_ONE / 2L);
    if(g_game.slow){vx=vx*2/3;vy=vy*2/3;}

    if (now_ms & 0X01U)
    {
        vx = -vx;
    }

    game_clear_ready_prompt();
    g_game.ball_vx = vx;
    g_game.ball_vy = -vy;
    g_game.state = GAME_STATE_PLAYING;
    g_game.last_frame_ms = now_ms;
}

static void game_set_paddle_target(uint16_t touch_x)
{
    int32_t target;
    int32_t minimum;
    int32_t maximum;

    target = (int32_t)touch_x - g_game.paddle_w / 2;
    minimum = (int32_t)g_game.field_left + 6;
    maximum = (int32_t)g_game.field_right - 6 - g_game.paddle_w + 1;
    g_game.paddle_target_x = (int16_t)clamp_i32(target, minimum, maximum);
}

static uint8_t game_circle_hits_rect(int16_t cx,
                                     int16_t cy,
                                     int16_t radius,
                                     const ui_rect_t *rect)
{
    int32_t nearest_x;
    int32_t nearest_y;
    int32_t dx;
    int32_t dy;

    nearest_x = clamp_i32(cx,
                         rect->x,
                         (int32_t)rect->x + rect->w - 1);
    nearest_y = clamp_i32(cy,
                         rect->y,
                         (int32_t)rect->y + rect->h - 1);
    dx = (int32_t)cx - nearest_x;
    dy = (int32_t)cy - nearest_y;

    return ((dx * dx + dy * dy) <= ((int32_t)radius * radius)) ? 1U : 0U;
}

static void game_destroy_brick(uint8_t row, uint8_t col, uint32_t now_ms)
{
    ui_rect_t rect;

    if(g_game.bricks[row][col]==2){g_game.bricks[row][col]=1;game_draw_brick(row,col);feedback_hit(now_ms);return;}
    if(g_game.bricks[row][col]==3 && g_game.lives<5)g_game.lives++;
    g_game.bricks[row][col] = 0;

    if (g_game.bricks_left > 0U)
    {
        g_game.bricks_left--;
    }

    g_game.score += (uint32_t)g_game.level * 10U;

    if (g_game.score > g_game.best_score)
    {
        g_game.best_score = g_game.score;
        console_record(0, g_game.best_score);
    }

    game_get_brick_rect(row, col, &rect);
    ui_fill_rect(rect.x,
                 rect.y,
                 (int32_t)rect.x + rect.w - 1,
                 (int32_t)rect.y + rect.h - 1,
                 COLOR_GAME_BG);

    if(!g_game.power_kind && (g_game.bricks_left%7)==0){g_game.power_kind=(g_game.bricks_left/7)%5+1;g_game.power_x=rect.x+rect.w/2;g_game.power_y=rect.y+rect.h/2;}

    game_draw_hud_values();
    feedback_hit(now_ms);
}

static uint8_t game_check_brick_collision(int16_t previous_x,
                                          int16_t previous_y,
                                          uint32_t now_ms)
{
    uint8_t row;
    uint8_t col;
    int16_t ball_x;
    int16_t ball_y;
    ui_rect_t rect;

    ball_x = (int16_t)(g_game.ball_x >> GAME_FP_SHIFT);
    ball_y = (int16_t)(g_game.ball_y >> GAME_FP_SHIFT);

    for (row = 0; row < g_game.brick_rows; row++)
    {
        for (col = 0; col < g_game.brick_cols; col++)
        {
            if (!g_game.bricks[row][col])
            {
                continue;
            }

            game_get_brick_rect(row, col, &rect);

            if (!game_circle_hits_rect(ball_x, ball_y, g_game.ball_r, &rect))
            {
                continue;
            }

            game_destroy_brick(row, col, now_ms);

            if ((int32_t)previous_y + g_game.ball_r <= rect.y)
            {
                g_game.ball_y = ((int32_t)rect.y - g_game.ball_r - 1) << GAME_FP_SHIFT;
                g_game.ball_vy = -((g_game.ball_vy > 0) ? g_game.ball_vy : -g_game.ball_vy);
            }
            else if ((int32_t)previous_y - g_game.ball_r >=
                     (int32_t)rect.y + rect.h - 1)
            {
                g_game.ball_y = ((int32_t)rect.y + rect.h + g_game.ball_r) << GAME_FP_SHIFT;
                g_game.ball_vy = (g_game.ball_vy > 0) ? g_game.ball_vy : -g_game.ball_vy;
            }
            else if (previous_x < rect.x)
            {
                g_game.ball_x = ((int32_t)rect.x - g_game.ball_r - 1) << GAME_FP_SHIFT;
                g_game.ball_vx = -((g_game.ball_vx > 0) ? g_game.ball_vx : -g_game.ball_vx);
            }
            else
            {
                g_game.ball_x = ((int32_t)rect.x + rect.w + g_game.ball_r) << GAME_FP_SHIFT;
                g_game.ball_vx = (g_game.ball_vx > 0) ? g_game.ball_vx : -g_game.ball_vx;
            }

            return 1;
        }
    }

    return 0;
}

static uint8_t game_step_physics(uint32_t now_ms)
{
    int16_t previous_x;
    int16_t previous_y;
    int16_t ball_x;
    int16_t ball_y;
    int32_t impact;
    int32_t max_vx;
    ui_rect_t paddle_rect;

    previous_x = (int16_t)(g_game.ball_x >> GAME_FP_SHIFT);
    previous_y = (int16_t)(g_game.ball_y >> GAME_FP_SHIFT);

    g_game.ball_x += g_game.ball_vx;
    g_game.ball_y += g_game.ball_vy;

    ball_x = (int16_t)(g_game.ball_x >> GAME_FP_SHIFT);
    ball_y = (int16_t)(g_game.ball_y >> GAME_FP_SHIFT);

    if ((int32_t)ball_x - g_game.ball_r <= (int32_t)g_game.field_left + 3)
    {
        ball_x = (int16_t)(g_game.field_left + 3 + g_game.ball_r);
        g_game.ball_x = (int32_t)ball_x << GAME_FP_SHIFT;
        g_game.ball_vx = (g_game.ball_vx > 0) ? g_game.ball_vx : -g_game.ball_vx;
    }
    else if ((int32_t)ball_x + g_game.ball_r >= (int32_t)g_game.field_right - 3)
    {
        ball_x = (int16_t)(g_game.field_right - 3 - g_game.ball_r);
        g_game.ball_x = (int32_t)ball_x << GAME_FP_SHIFT;
        g_game.ball_vx = -((g_game.ball_vx > 0) ? g_game.ball_vx : -g_game.ball_vx);
    }

    if ((int32_t)ball_y - g_game.ball_r <= (int32_t)g_game.field_top + 3)
    {
        ball_y = (int16_t)(g_game.field_top + 3 + g_game.ball_r);
        g_game.ball_y = (int32_t)ball_y << GAME_FP_SHIFT;
        g_game.ball_vy = (g_game.ball_vy > 0) ? g_game.ball_vy : -g_game.ball_vy;
    }

    ui_rect_set(&paddle_rect,
                g_game.paddle_x,
                g_game.paddle_y,
                g_game.paddle_w,
                g_game.paddle_h);

    ball_x = (int16_t)(g_game.ball_x >> GAME_FP_SHIFT);
    ball_y = (int16_t)(g_game.ball_y >> GAME_FP_SHIFT);

    if (g_game.ball_vy > 0 &&
        game_circle_hits_rect(ball_x, ball_y, g_game.ball_r, &paddle_rect) &&
        previous_y < (int16_t)(g_game.paddle_y + g_game.paddle_h / 2))
    {
        g_game.ball_y = ((int32_t)g_game.paddle_y - g_game.ball_r - 1) << GAME_FP_SHIFT;
        g_game.ball_vy = -g_game.ball_vy;

        if(g_game.sticky){g_game.sticky=0;g_game.ball_vx=g_game.ball_vy=0;g_game.state=GAME_STATE_READY;game_draw_scene();return 0;}

        impact = (int32_t)ball_x -
                 ((int32_t)g_game.paddle_x + g_game.paddle_w / 2);
        max_vx = 5L * GAME_FP_ONE +
                 (int32_t)(g_game.level - 1U) * (GAME_FP_ONE / 4L);
        g_game.ball_vx = impact * max_vx / (g_game.paddle_w / 2);

        if (g_game.ball_vx > -(2L * GAME_FP_ONE) &&
            g_game.ball_vx < (2L * GAME_FP_ONE))
        {
            g_game.ball_vx = (impact < 0) ?
                             -(2L * GAME_FP_ONE) :
                             (2L * GAME_FP_ONE);
        }
    }

    game_check_brick_collision(previous_x, previous_y, now_ms);

    if (g_game.bricks_left == 0U)
    {
        game_advance_level(now_ms);
        return 0;
    }

    ball_y = (int16_t)(g_game.ball_y >> GAME_FP_SHIFT);

    if ((int32_t)ball_y + g_game.ball_r >= g_game.field_bottom)
    {
        if(g_game.shield){
            g_game.shield=0;g_game.ball_y=((int32_t)g_game.field_bottom-g_game.ball_r-3)<<GAME_FP_SHIFT;
            if(g_game.ball_vy>0)g_game.ball_vy=-g_game.ball_vy;
            ui_fill_rect(g_game.field_left+2,g_game.field_bottom-2,g_game.field_right-2,g_game.field_bottom-1,COLOR_GAME_BG);
            feedback_hit(now_ms);return 1;
        }
        feedback_miss(now_ms);

        if (g_game.lives > 0U)
        {
            g_game.lives--;
        }

        if (g_game.lives == 0U)
        {
            game_finish(0);
        }
        else
        {
            g_game.state = GAME_STATE_READY;
            g_game.last_frame_ms = now_ms;
            game_reset_ball();
            game_draw_scene();
        }

        return 0;
    }

    return 1;
}

static void game_step_power(uint32_t now_ms)
{
    int16_t r=g_game.ball_r;
    if(!g_game.power_kind)return;
    ui_fill_circle(g_game.power_x,g_game.power_y,r,COLOR_GAME_BG);
    game_restore_bricks_near_ball(g_game.power_x,g_game.power_y);
    g_game.power_y+=g_game.screen_h>=400?3:2;
    if(g_game.power_y+r>=g_game.paddle_y && g_game.power_y-r<=g_game.paddle_y+g_game.paddle_h &&
       g_game.power_x+r>=g_game.paddle_x && g_game.power_x-r<g_game.paddle_x+g_game.paddle_w){
        if(g_game.power_kind==1){
            ui_fill_rect(g_game.paddle_x,g_game.paddle_y,g_game.paddle_x+g_game.paddle_w-1,g_game.paddle_y+g_game.paddle_h-1,COLOR_GAME_BG);
            g_game.paddle_w=g_game.base_paddle_w+g_game.base_paddle_w/2;
            game_set_paddle_target(g_game.paddle_x+g_game.paddle_w/2);g_game.paddle_x=g_game.paddle_target_x;
        }else if(g_game.power_kind==2)g_game.shield=1;
        else if(g_game.power_kind==3&&!g_game.slow){g_game.slow=1;g_game.ball_vx=g_game.ball_vx*2/3;g_game.ball_vy=g_game.ball_vy*2/3;}
        else if(g_game.power_kind==4)g_game.sticky=1;
        else if(g_game.power_kind==5)g_game.laser=1;
        g_game.power_kind=0;feedback_hit(now_ms);
    }else if(g_game.power_y+r>=g_game.field_bottom)g_game.power_kind=0;
}

static void game_step_laser(uint32_t now_ms){int i,r,c;ui_rect_t rect;
    for(i=0;i<2;i++)if(g_game.laser_y[i]>0){
        ui_fill_rect(g_game.laser_x[i],g_game.laser_y[i],g_game.laser_x[i]+1,g_game.laser_y[i]+5,COLOR_GAME_BG);game_restore_bricks_near_ball(g_game.laser_x[i],g_game.laser_y[i]+2);
        g_game.laser_y[i]-=6;if(g_game.laser_y[i]<=g_game.field_top){g_game.laser_y[i]=0;continue;}
        for(r=0;r<g_game.brick_rows&&g_game.laser_y[i];r++)for(c=0;c<g_game.brick_cols&&g_game.laser_y[i];c++)if(g_game.bricks[r][c]){game_get_brick_rect(r,c,&rect);if(ui_rect_contains(&rect,g_game.laser_x[i],g_game.laser_y[i])){game_destroy_brick(r,c,now_ms);g_game.laser_y[i]=0;}}
    }
    if(g_game.laser&&!g_game.laser_y[0]&&!g_game.laser_y[1]&&now_ms-g_game.laser_at>450){g_game.laser_at=now_ms;g_game.laser_x[0]=g_game.paddle_x+3;g_game.laser_x[1]=g_game.paddle_x+g_game.paddle_w-4;g_game.laser_y[0]=g_game.laser_y[1]=g_game.paddle_y-8;}
}

static void game_update(uint32_t now_ms)
{
    int16_t old_paddle_x;
    int16_t old_paddle_w;
    int16_t old_ball_x;
    int16_t old_ball_y;

    if (g_game.state != GAME_STATE_READY &&
        g_game.state != GAME_STATE_PLAYING)
    {
        return;
    }

    if ((uint32_t)(now_ms - g_game.last_frame_ms) < GAME_FRAME_MS)
    {
        return;
    }

    g_game.last_frame_ms = now_ms;
    old_paddle_x = g_game.paddle_x;
    old_paddle_w = g_game.paddle_w;
    old_ball_x = (int16_t)(g_game.ball_x >> GAME_FP_SHIFT);
    old_ball_y = (int16_t)(g_game.ball_y >> GAME_FP_SHIFT);
    g_game.paddle_x = g_game.paddle_target_x;

    if (g_game.state == GAME_STATE_READY)
    {
        g_game.ball_x = ((int32_t)g_game.paddle_x + g_game.paddle_w / 2) << GAME_FP_SHIFT;
        g_game.ball_y = ((int32_t)g_game.paddle_y - g_game.ball_r - 3) << GAME_FP_SHIFT;
        game_render_dynamic(old_paddle_x, old_ball_x, old_ball_y,old_paddle_w);
        return;
    }

    game_step_power(now_ms);
    game_step_laser(now_ms);
    if (game_step_physics(now_ms))
    {
        game_render_dynamic(old_paddle_x, old_ball_x, old_ball_y,old_paddle_w);
        game_draw_power();
    }
}

static void game_pause(void)
{
    console_record(0, g_game.best_score);
    console_flush();
    g_game.resume_state = g_game.state;
    g_game.state = GAME_STATE_PAUSED;
    game_draw_pause_screen();
}

static void game_resume(uint32_t now_ms)
{
    g_game.state = g_game.resume_state;
    g_game.last_frame_ms = now_ms;
    game_draw_scene();
}

static void game_handle_touch(uint32_t now_ms)
{
    ui_rect_t pause_button;

    if (g_game.state == GAME_STATE_MENU){
        uint8_t selected=shell_tick(now_ms,g_touch.x,g_touch.y,g_touch.press_event,g_touch.release_event,g_touch.stable_down);
        if(selected==1)game_start_new(now_ms);
        else if(selected){arcade_start(selected-1,now_ms);g_extra_active=1;}
        return;
    }

    if (g_game.state == GAME_STATE_READY ||
        g_game.state == GAME_STATE_PLAYING)
    {
        pause_button = game_pause_button_rect();

        if (g_touch.press_event &&
            ui_rect_contains(&pause_button, g_touch.x, g_touch.y))
        {
            game_pause();
            return;
        }

        if (g_touch.stable_down && g_touch.y >= g_game.field_top)
        {
            game_set_paddle_target(g_touch.x);
        }

        if (g_game.state == GAME_STATE_READY &&
            g_touch.press_event &&
            g_touch.y >= g_game.field_top)
        {
            game_launch_ball(now_ms);
        }

        return;
    }

    if (g_game.state == GAME_STATE_PAUSED)
    {
        if (!g_touch.press_event)
        {
            return;
        }

        if (ui_rect_contains(&g_primary_button, g_touch.x, g_touch.y))
        {
            game_resume(now_ms);
        }
        else if (ui_rect_contains(&g_secondary_button, g_touch.x, g_touch.y))
        {
            game_start_new(now_ms);
        }
        else if (ui_rect_contains(&g_tertiary_button, g_touch.x, g_touch.y))
        {
            g_game.state = GAME_STATE_MENU;
            game_draw_menu();
        }

        return;
    }

    if (g_game.state == GAME_STATE_OVER ||
        g_game.state == GAME_STATE_WIN)
    {
        if (!g_touch.press_event)
        {
            return;
        }

        if (ui_rect_contains(&g_primary_button, g_touch.x, g_touch.y))
        {
            game_start_new(now_ms);
        }
        else if (ui_rect_contains(&g_secondary_button, g_touch.x, g_touch.y))
        {
            g_game.state = GAME_STATE_MENU;
            game_draw_menu();
        }
    }
}

static void game_init(void)
{
    g_game.screen_w = lcddev.width;
    g_game.screen_h = lcddev.height;
    g_game.hud_h = (g_game.screen_h >= 400U) ? 50U : 40U;
    g_game.field_left = 4U;
    g_game.field_right = (uint16_t)(g_game.screen_w - 5U);
    g_game.field_top = g_game.hud_h;
    g_game.field_bottom = (uint16_t)(g_game.screen_h - 5U);
    g_game.ball_r = (g_game.screen_h >= 400U) ? 7U : 5U;
    g_game.best_score = console_best(0);
    g_game.state = GAME_STATE_MENU;
    game_draw_menu();
}

int main(void)
{
    uint32_t now_ms;

    HAL_Init();
    sys_stm32_clock_init(RCC_PLL_MUL9);
    delay_init(72);
    usart_init(115200);
    led_init();
    lcd_init();

    /* The game uses landscape mode. Set it before touchscreen initialization. */
    lcd_display_dir(1);
    tp_dev.init();

    LED0(1);
    LED1(1);
    console_init();
    clock5_init();
    game_init();

    while (1)
    {
        now_ms = HAL_GetTick();
        touch_input_update(now_ms);
        if(g_extra_active) {
            if(arcade_tick(now_ms,g_touch.x,g_touch.y,g_touch.press_event,g_touch.release_event,g_touch.stable_down)) {
                g_extra_active=0;
                game_draw_menu();
            }
        } else {
            game_handle_touch(now_ms);
            game_update(now_ms);
        }
        console_service(now_ms);
        feedback_service(now_ms);

        /* Sleep until the next interrupt. SysTick wakes the CPU every 1 ms. */
        sys_wfi_set();
    }
}
