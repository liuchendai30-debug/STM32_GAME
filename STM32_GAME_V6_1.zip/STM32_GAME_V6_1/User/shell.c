#include "shell.h"
#include "sticks.h"
#include "ui_zh.h"
#include "console_service.h"
#include "arcade.h"
#include "clock5.h"
#include "./BSP/LCD/lcd.h"
#include "./BSP/TOUCH/touch.h"
#include <stdio.h>

#define SH_BG 0x0842
#define SH_PANEL 0x1126
#define SH_EDGE 0x328b
#define SH_ACCENT 0x3ff9
typedef struct {int16_t x,y,w,h;} sh_rect;
static uint8_t sh_page,sh_view,sh_sleep,sh_armed;
static uint32_t sh_active,sh_frame,sh_page_anim;
static uint16_t sh_year=2026;static uint8_t sh_month=9,sh_day=14,sh_date_error,sh_hour,sh_minute;
static sh_rect sh_cards[4],sh_left,sh_right,sh_back,sh_options[8];
static const char *sh_names[16]={"BRICKS","SNAKE","TETRIS","2048","MINES","XO","SLIDE","MEMORY","BIRD","RACER","TANK","SPACE","TROPHIES","DAILY","DATE_SET","ABOUT"};
static const char *sh_hints[16]={"CARD_BRICKS","CARD_SNAKE","CARD_TETRIS","CARD_2048","CARD_MINES","CARD_XO","CARD_SLIDE","CARD_MEMORY","BIRD_HELP","RACER_HELP","TANK_HELP","SPACE_HELP","TROPHY_HELP","DAILY_HELP","DATE_HELP","VERSION"};
static const uint16_t sh_colors[16]={0xfd20,0x67ec,0xbc7f,0xff26,0x4e9f,0xff99,0x7ff8,0xfbd7,0xffe0,0x07ff,0x07e0,0xf81f,0xffe0,0x07ff,0xffff,0xffff};
static const uint8_t sh_icons[12][8]={
 {0xee,0xee,0,0x77,0x77,0,0x10,0x7c},{0x3c,0x24,0x24,0x27,0x21,0x3d,0x01,0x03},
 {0x38,0x10,0,0x02,0x06,0x42,0xee,0xfe},{0x7e,0x42,0x5a,0x4a,0x52,0x5a,0x42,0x7e},
 {0x10,0x54,0x38,0xfe,0x38,0x54,0x10,0},{0x24,0xff,0x24,0x24,0xff,0x24,0x24,0},
 {0xff,0x89,0xa9,0xff,0x89,0xab,0x88,0xf8},{0x7e,0x42,0x66,0x7e,0x3c,0x18,0x42,0x7e},
 {0,0x38,0x7c,0x76,0xfc,0x78,0x30,0},{0x18,0x3c,0x7e,0x5a,0x5a,0x7e,0x3c,0x24},
 {0x18,0x18,0x7e,0xdb,0xff,0xdb,0x7e,0x66},{0x18,0x18,0x3c,0x3c,0x7e,0xff,0x18,0x24}};
static uint8_t sh_hit(sh_rect r,uint16_t x,uint16_t y){return x>=r.x&&y>=r.y&&x<r.x+r.w&&y<r.y+r.h;}
static void sh_fill(sh_rect r,uint16_t c){lcd_fill(r.x,r.y,r.x+r.w-1,r.y+r.h-1,c);}
static void sh_text(sh_rect r,const char *s,uint8_t size,uint16_t c){int w=zh_width(s,size);int x=r.x+(r.w-w)/2;if(x<r.x)x=r.x;zh_draw(x,r.y+(r.h-size)/2,r.x+r.w-x,r.h,size,s,c,SH_BG);}
static void sh_button(sh_rect r,const char *s){int x=r.x+(r.w-zh_width(s,16))/2;if(x<r.x)x=r.x;sh_fill(r,SH_PANEL);lcd_draw_rectangle(r.x,r.y,r.x+r.w-1,r.y+r.h-1,SH_EDGE);zh_draw(x,r.y+(r.h-16)/2,r.x+r.w-x,16,16,s,WHITE,SH_PANEL);}
static void sh_icon(int id,int x,int y,int scale){int i,j;for(i=0;i<8;i++)for(j=0;j<8;j++)if(sh_icons[id%12][i]&(128>>j)){sh_rect r={x+j*scale,y+i*scale,scale-1,scale-1};sh_fill(r,sh_colors[id]);}}
static void sh_draw(void){
    sh_rect r;int i,id,gap=12,top=sh_view==0?98:66,cw,ch;char b[64];const char *labels[8];
    lcd_clear(SH_BG);
    r.x=12;r.y=12;r.w=lcddev.width-130;r.h=32;
    sh_text(r,sh_view==0?"HALL":sh_view==1?"SETTINGS":sh_view==2?"TOUCH_TEST":sh_view==3?"ABOUT":sh_view==5?"TROPHIES":sh_view==6?"DAILY":sh_view>=7?"DATE_SET":"RESET_CONFIRM",lcddev.width>=640?24:16,SH_ACCENT);
    sh_back.x=lcddev.width-108;sh_back.y=12;sh_back.w=96;sh_back.h=32;
    sh_button(sh_back,sh_view?"BACK":"SETTINGS");
    if(sh_view==0){
        sh_options[7].x=12;sh_options[7].y=51;sh_options[7].w=lcddev.width-24;sh_options[7].h=36;
        sh_button(sh_options[7],"FLAME_FEATURED");
        cw=(lcddev.width-gap*3)/2;ch=(lcddev.height-top-50-gap)/2;
        for(i=0;i<4;i++){
            id=sh_page*4+i;r.x=gap+(i%2)*(cw+gap);r.y=top+(i/2)*(ch+gap);r.w=cw;r.h=ch;sh_cards[i]=r;
            sh_fill(r,SH_PANEL);lcd_draw_rectangle(r.x,r.y,r.x+r.w-1,r.y+r.h-1,SH_EDGE);
            sh_icon(id,r.x+10,r.y+10,lcddev.width>=640?5:3);
            zh_draw(r.x+(lcddev.width>=640?65:42),r.y+10,r.w-50,32,lcddev.width>=640?24:16,sh_names[id],sh_colors[id],SH_PANEL);
            if(lcddev.height>=400)zh_draw(r.x+12,r.y+68,r.w-24,24,16,sh_hints[id],0xa575,SH_PANEL);
            if(id>=12){zh_draw(r.x+12,r.y+r.h-26,r.w-24,20,12,sh_hints[id],WHITE,SH_PANEL);continue;}
            if(lcddev.height<400){zh_draw(r.x+12,r.y+r.h-16,28,12,12,"BEST",WHITE,SH_PANEL);sprintf(b,"%lu",(unsigned long)console_best(id));zh_draw(r.x+44,r.y+r.h-16,r.w-52,12,12,b,WHITE,SH_PANEL);continue;}
            zh_draw(r.x+12,r.y+r.h-38,40,18,16,"BEST",WHITE,SH_PANEL);
            sprintf(b,"%lu",(unsigned long)console_best(id));zh_draw(r.x+52,r.y+r.h-38,r.w-64,18,16,b,WHITE,SH_PANEL);
            zh_draw(r.x+12,r.y+r.h-18,28,16,12,"PLAYS",0xa575,SH_PANEL);sprintf(b,"%u",console_plays(id));zh_draw(r.x+42,r.y+r.h-18,40,16,12,b,0xa575,SH_PANEL);
            zh_draw(r.x+92,r.y+r.h-18,28,16,12,"WINS",0xa575,SH_PANEL);sprintf(b,"%u",console_wins(id));zh_draw(r.x+122,r.y+r.h-18,40,16,12,b,0xa575,SH_PANEL);
        }
        sh_left.x=12;sh_left.y=lcddev.height-38;sh_left.w=100;sh_left.h=28;
        sh_right=sh_left;sh_right.x=lcddev.width-112;
        sh_button(sh_left,"PREV");sh_button(sh_right,"NEXT_PAGE");
        r.x=116;r.y=lcddev.height-38;r.w=lcddev.width-232;r.h=28;
        sh_text(r,console_save_error()?"SAVE_ERROR":sh_page==3?"PAGE4":sh_page==2?"PAGE3":sh_page?"PAGE2":"PAGE1",12,console_save_error()?RED:WHITE);
    }else if(sh_view==1){
        labels[0]=console_sound()?"SOUND_ON":"SOUND_OFF";
        sprintf(b,"%u%%",console_brightness());
        labels[1]="";labels[2]=console_touch_ms()==10?"TOUCH_FAST":console_touch_ms()==30?"TOUCH_STABLE":"TOUCH_NORMAL";
        labels[3]=console_idle_enabled()?"IDLE_ON":"IDLE_OFF";labels[4]="TOUCH_TEST";labels[5]=sticks_sensitivity()==0?"STICK_LOW":sticks_sensitivity()==1?"STICK_MED":"STICK_HIGH";labels[6]="DEFAULTS";labels[7]="SAVE_BACK";
        ch=(lcddev.height-80)/4-8;cw=(lcddev.width-36)/2;
        for(i=0;i<8;i++){r.x=12+(i%2)*(cw+12);r.y=64+(i/2)*(ch+8);r.w=cw;r.h=ch;sh_options[i]=r;sh_button(r,labels[i]);}
        r=sh_options[1];zh_draw(r.x+12,r.y+(r.h-16)/2,64,16,16,"BRIGHTNESS",WHITE,SH_PANEL);zh_draw(r.x+r.w-60,r.y+(r.h-16)/2,56,16,16,b,SH_ACCENT,SH_PANEL);
    }else if(sh_view==2){
        r.x=12;r.y=64;r.w=lcddev.width-24;r.h=32;sh_text(r,(tp_dev.touchtype&0x80)?"CAP_TEST":"RES_TEST",16,WHITE);
        r.y=100;sh_text(r,"TOUCH_DRAW",16,WHITE);
        if(!(tp_dev.touchtype&0x80)){sh_options[0].x=12;sh_options[0].y=lcddev.height-45;sh_options[0].w=180;sh_options[0].h=32;sh_button(sh_options[0],"CALIBRATE");}
    }else if(sh_view==3){
        r.x=12;r.y=70;r.w=lcddev.width-24;r.h=32;sh_text(r,"VERSION",24,SH_ACCENT);
        r.y+=42;sh_text(r,"STM32F103ZET6 / HAL",16,WHITE);
        r.y+=34;sprintf(b,"LCD %u x %u  ID %04X",lcddev.width,lcddev.height,lcddev.id);sh_text(r,b,16,WHITE);
        r.y+=34;sh_text(r,"SAVE_HINT",16,WHITE);
        r.y+=34;sh_text(r,"TEN_GAMES",16,WHITE);
    }else if(sh_view==5){
        cw=(lcddev.width-36)/2;ch=(lcddev.height-70)/6;
        zh_draw(12,46,lcddev.width-24,12,12,"MEDAL_HINT",WHITE,SH_BG);
        for(i=0;i<12;i++){
            r.x=12+(i%2)*(cw+12);r.y=64+(i/2)*ch;r.w=cw;r.h=ch-4;sh_fill(r,SH_PANEL);
            zh_draw(r.x+8,r.y+2,r.w-80,16,12,sh_names[i],console_trophy(i)?0xffe0:WHITE,SH_PANEL);
            id=console_medal(i);zh_draw(r.x+r.w-66,r.y+2,64,12,12,id==3?"GOLD":id==2?"SILVER":id==1?"BRONZE":"LOCKED",id?0xffe0:0xa575,SH_PANEL);
            sprintf(b,"%lu / %lu / %lu",(unsigned long)console_medal_goal(i,0),(unsigned long)console_medal_goal(i,1),(unsigned long)console_medal_goal(i,2));zh_draw(r.x+8,r.y+16,r.w-16,12,12,b,0xa575,SH_PANEL);
        }
    }else if(sh_view==6){
        r.x=12;r.y=70;r.w=lcddev.width-24;r.h=30;sh_text(r,clock5_ready()?"DAILY_HELP":"DATE_REQUIRED",16,WHITE);
        if(clock5_ready()){uint16_t yy;uint8_t mm,dd;uint32_t day=clock5_day();clock5_decode(day,&yy,&mm,&dd);sprintf(b,"%04u-%02u-%02u",yy,mm,dd);r.y=106;sh_text(r,b,24,SH_ACCENT);r.y=140;sh_text(r,day%3==0?"SLIDE":day%3==1?"MEMORY":"MINES",16,WHITE);}
        sh_options[0].x=lcddev.width/2-100;sh_options[0].y=lcddev.height-60;sh_options[0].w=200;sh_options[0].h=40;sh_button(sh_options[0],clock5_ready()?"START":"DATE_SET");
    }else if(sh_view==7||sh_view==8){
        r.x=12;r.y=64;r.w=lcddev.width-24;r.h=28;if(sh_view==7)sprintf(b,"%04u-%02u-%02u",sh_year,sh_month,sh_day);else sprintf(b,"%02u:%02u",sh_hour,sh_minute);sh_text(r,b,24,SH_ACCENT);
        labels[0]="YEAR_MINUS";labels[1]="YEAR_PLUS";labels[2]="MONTH_MINUS";labels[3]="MONTH_PLUS";labels[4]="DAY_MINUS";labels[5]="DAY_PLUS";
        if(sh_view==8){labels[0]="HOUR_MINUS";labels[1]="HOUR_PLUS";labels[2]="MINUTE_MINUS";labels[3]="MINUTE_PLUS";labels[4]="MINUTE_TEN_MINUS";labels[5]="MINUTE_TEN_PLUS";}
        for(i=0;i<6;i++){r.x=12+(i%2)*(lcddev.width/2);r.y=100+i/2*36;r.w=lcddev.width/2-24;r.h=30;sh_options[i]=r;sh_button(r,labels[i]);}
        sh_options[6].x=12;sh_options[6].y=lcddev.height-42;sh_options[6].w=lcddev.width-24;sh_options[6].h=32;sh_button(sh_options[6],sh_date_error?"RTC_ERROR":sh_view==7?"SET_TIME":"DATE_CONFIRM");
    }else{
        r.x=12;r.y=72;r.w=lcddev.width-24;r.h=32;sh_text(r,"KEEP_RECORDS",16,WHITE);
        sh_options[0].x=24;sh_options[0].y=140;sh_options[0].w=(lcddev.width-60)/2;sh_options[0].h=48;
        sh_options[1]=sh_options[0];sh_options[1].x+=sh_options[0].w+12;
        sh_button(sh_options[0],"CONFIRM");sh_button(sh_options[1],"CANCEL");
    }
}
void shell_show(void){arcade_set_daily(0);sh_view=0;sh_sleep=0;sh_armed=0;sh_active=HAL_GetTick();console_backlight(console_brightness());sh_draw();}
uint8_t shell_tick(uint32_t now,uint16_t x,uint16_t y,uint8_t press,uint8_t release,uint8_t down){
    uint8_t i;sh_rect r;(void)release;
    if(!down)sh_armed=1;
    if(down){sh_active=now;if(sh_sleep){sh_sleep=0;sh_armed=0;console_backlight(console_brightness());sh_draw();return 0;}}
    if(sh_sleep){
        if((uint32_t)(now-sh_frame)>1000){sh_frame=now;lcd_clear(SH_BG);r.x=20+(now/1000*11)%(lcddev.width-220);r.y=30+(now/1000*7)%(lcddev.height-70);r.w=200;r.h=32;sh_text(r,"WAKE",24,SH_ACCENT);}return 0;
    }
    if(sh_view==0 && console_idle_enabled() && (uint32_t)(now-sh_active)>60000){console_flush();sh_sleep=1;sh_frame=now-1100;console_backlight(20);return 0;}
    if(sh_view==0&&sh_page_anim){uint32_t t=now-sh_page_anim;int w=(lcddev.width-24)*(t>180?180:t)/180;r.x=12;r.y=54;r.w=lcddev.width-24;r.h=3;sh_fill(r,SH_BG);if(w>0){r.w=w;sh_fill(r,SH_ACCENT);}if(t>=180)sh_page_anim=0;}
    if(sh_view==2&&down&&y>138&&y<lcddev.height-50&&x>3&&x<lcddev.width-4)lcd_fill(x-2,y-2,x+2,y+2,SH_ACCENT);
    if(!press||!sh_armed)return 0;
    if(sh_hit(sh_back,x,y)){console_flush();sh_view=sh_view?0:1;sh_draw();return 0;}
    if(sh_view==0){
        if(sh_hit(sh_options[7],x,y))return 13;
        if(sh_hit(sh_left,x,y)||sh_hit(sh_right,x,y)){sh_page=(sh_page+(sh_hit(sh_left,x,y)?3:1))%4;sh_page_anim=now?now:1;sh_draw();return 0;}
        for(i=0;i<4;i++)if(sh_hit(sh_cards[i],x,y)){if(sh_page==3){sh_view=i==0?5:i==1?6:i==2?7:3;if(sh_view==7&&clock5_ready())clock5_decode(clock5_day(),&sh_year,&sh_month,&sh_day);sh_draw();return 0;}r=sh_cards[i];lcd_draw_rectangle(r.x+2,r.y+2,r.x+r.w-3,r.y+r.h-3,WHITE);return sh_page*4+i+1;}
    }else if(sh_view==1){
        for(i=0;i<8;i++)if(sh_hit(sh_options[i],x,y)){
            if(i==0){console_toggle_sound();console_beep(HAL_GetTick(),50);}
            if(i==1)console_set_brightness(console_brightness()>=100?20:console_brightness()+20);
            if(i==2)console_cycle_touch();if(i==3)console_toggle_idle();if(i==4)sh_view=2;if(i==5)sticks_cycle_sensitivity();if(i==6)sh_view=4;if(i==7)sh_view=0;
            console_flush();sh_draw();break;
        }
    }else if(sh_view==6&&sh_hit(sh_options[0],x,y)){if(clock5_ready()){uint32_t day=clock5_day();arcade_set_daily((day+1)*2654435761U);return day%3==0?7:day%3==1?8:5;}sh_view=7;sh_draw();}
    else if(sh_view==7){for(i=0;i<7;i++)if(sh_hit(sh_options[i],x,y)){sh_date_error=0;if(i==0&&sh_year>2020)sh_year--;if(i==1&&sh_year<2099)sh_year++;if(i==2)sh_month=sh_month==1?12:sh_month-1;if(i==3)sh_month=sh_month==12?1:sh_month+1;if(i==4)sh_day=sh_day==1?31:sh_day-1;if(i==5)sh_day=sh_day==31?1:sh_day+1;if(i==6){if(clock5_encode(sh_year,sh_month,sh_day)!=0xffffffffU){sh_view=8;if(clock5_ready()){sh_hour=clock5_seconds()/3600%24;sh_minute=clock5_seconds()/60%60;}}else sh_date_error=1;}sh_draw();break;}}
    else if(sh_view==8){for(i=0;i<7;i++)if(sh_hit(sh_options[i],x,y)){sh_date_error=0;if(i==0)sh_hour=(sh_hour+23)%24;if(i==1)sh_hour=(sh_hour+1)%24;if(i==2)sh_minute=(sh_minute+59)%60;if(i==3)sh_minute=(sh_minute+1)%60;if(i==4)sh_minute=(sh_minute+50)%60;if(i==5)sh_minute=(sh_minute+10)%60;if(i==6){if(clock5_set_time(sh_year,sh_month,sh_day,sh_hour,sh_minute))sh_view=6;else sh_date_error=1;}sh_draw();break;}}
    else if(sh_view==4){if(sh_hit(sh_options[0],x,y)){console_defaults();sh_view=1;sh_draw();}else if(sh_hit(sh_options[1],x,y)){sh_view=1;sh_draw();}}
    else if(sh_view==2&&!(tp_dev.touchtype&0x80)&&sh_hit(sh_options[0],x,y)){tp_dev.adjust();sh_armed=0;sh_draw();}
    return 0;
}
