#ifndef GAME_SHELL_H
#define GAME_SHELL_H
#include <stdint.h>
void shell_show(void);
/* Returns game ID + 1, zero when staying in the shell. */
uint8_t shell_tick(uint32_t now,uint16_t x,uint16_t y,uint8_t press,uint8_t release,uint8_t down);
#endif
