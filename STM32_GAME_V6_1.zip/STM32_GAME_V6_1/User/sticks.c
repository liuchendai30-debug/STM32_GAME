#include "sticks.h"
#include "./BSP/LCD/lcd.h"
#include "./BSP/TOUCH/touch.h"
#include <string.h>
#include <stdlib.h>
sticks_t sticks;
const int16_t stick_dx[16]={256,237,181,98,0,-98,-181,-237,-256,-237,-181,-98,0,98,181,237};
const int16_t stick_dy[16]={0,98,181,237,256,237,181,98,0,-98,-181,-237,-256,-237,-181,-98};
/* Session preference: no changes to the V6 EEPROM record layout. */
static uint8_t stick_sense=2,button_count;
static struct {int16_t x,y;uint8_t kind;} button_contacts[5];
uint8_t sticks_sensitivity(void){return stick_sense;}
void sticks_cycle_sensitivity(void){stick_sense=(stick_sense+1)%3;}
int v6_hit(v6_rect r,int x,int y){return x>=r.x&&x<r.x+r.w&&y>=r.y&&y<r.y+r.h;}
static int stick_ring(int x,int y,int cx,int cy,int r){int dx=x-cx,dy=y-cy;return dx*dx+dy*dy<=r*r;}
static int stick_button(v6_rect r,int x,int y){return stick_ring(x,y,r.x+r.w/2,r.y+r.h/2,r.w/2+6);}
int stick_direction(int x,int y){int i,best=0;int32_t dot,max=-2147483647;for(i=0;i<16;i++){dot=(int32_t)x*stick_dx[i]+(int32_t)y*stick_dy[i];if(dot>max){max=dot;best=i;}}return best;}
void sticks_reset(void){sticks.blocked=1;sticks.tracking=0;sticks.held=sticks.fire=sticks.power=0;sticks.move=-1;sticks.skill_press=sticks.swap_press=sticks.pause_press=0;sticks.mx=sticks.my=sticks.ax=sticks.ay=0;button_count=0;}
void sticks_init(void){int w=lcddev.width,h=lcddev.height,large=h>=400;memset(&sticks,0,sizeof sticks);sticks.r=large?62:38;sticks.top=h-(large?158:102);sticks.lx=large?78:52;sticks.rx=w-(large?78:52);sticks.ly=sticks.ry=h-(large?68:44);
 sticks.skill.w=sticks.skill.h=large?88:56;sticks.skill.x=w-(large?181:116)-sticks.skill.w/2;sticks.skill.y=h-(large?114:74)-sticks.skill.h/2;
 sticks.swap.w=sticks.swap.h=large?76:48;sticks.swap.x=w-(large?272:176)-sticks.swap.w/2;sticks.swap.y=h-(large?46:28)-sticks.swap.h/2;
 sticks.pause.x=w-76;sticks.pause.y=3;sticks.pause.w=72;sticks.pause.h=34;sticks.aim=12;sticks_reset();}
void sticks_sample(uint16_t x,uint16_t y,uint8_t down){int i,j,n=0,xx[5],yy[5],dx,dy,m,mask=0,selected[2]={-1,-1},used=0,d,best,track=0,prev_move=sticks.move,oldbuttons=button_count,newbuttons=0,kind,found,dead=sticks.r/(stick_sense==0?5:stick_sense==1?8:12);uint8_t raw=tp_dev.sta&TP_PRES_DOWN?1:0;
 if(tp_dev.touchtype&0x80){if(raw)for(i=0;i<5;i++)if((tp_dev.sta&(1<<i))&&tp_dev.x[i]<lcddev.width&&tp_dev.y[i]<lcddev.height){xx[n]=tp_dev.x[i];yy[n++]=tp_dev.y[i];}}
 else if(down){xx[n]=x;yy[n++]=y;}
 sticks.skill_press=sticks.swap_press=sticks.pause_press=0;sticks.fire=sticks.power=0;sticks.move=-1;sticks.mx=sticks.my=sticks.ax=sticks.ay=0;
 if(sticks.blocked){if(!n&&!down){sticks.blocked=0;sticks.held=0;}return;}
 /* Retain button owners before acquiring sticks. Sliding off a button must
  * not activate its neighbor. The controller can reorder contact slots. */
 for(j=0;j<oldbuttons;j++){found=-1;best=sticks.r;for(i=0;i<n;i++)if(!(used&(1<<i))){d=abs(xx[i]-button_contacts[j].x)+abs(yy[i]-button_contacts[j].y);if(d<best){best=d;found=i;}}if(found>=0){used|=1<<found;button_contacts[newbuttons].x=xx[found];button_contacts[newbuttons].y=yy[found];button_contacts[newbuttons++].kind=button_contacts[j].kind;}}
 for(j=0;j<2;j++)if(sticks.tracking&(1<<j)){best=sticks.r*2;for(i=0;i<n;i++)if(!(used&(1<<i))){d=abs(xx[i]-sticks.previous_x[j])+abs(yy[i]-sticks.previous_y[j]);if(d<best){best=d;selected[j]=i;}}if(selected[j]>=0)used|=1<<selected[j];}
 /* New buttons have priority over the expanded circular stick rim. */
 for(i=0;i<n;i++)if(!(used&(1<<i))){kind=v6_hit(sticks.pause,xx[i],yy[i])?4:stick_button(sticks.skill,xx[i],yy[i])?1:stick_button(sticks.swap,xx[i],yy[i])?2:0;if(kind){mask|=kind;used|=1<<i;button_contacts[newbuttons].x=xx[i];button_contacts[newbuttons].y=yy[i];button_contacts[newbuttons++].kind=kind;}}
 button_count=newbuttons;
 for(j=0;j<2;j++){if(selected[j]<0)for(i=0;i<n;i++)if(!(used&(1<<i))&&stick_ring(xx[i],yy[i],j?sticks.rx:sticks.lx,sticks.ly,sticks.r+8)){selected[j]=i;used|=1<<i;break;}
  i=selected[j];if(i<0)continue;track|=1<<j;sticks.previous_x[j]=xx[i];sticks.previous_y[j]=yy[i];dx=xx[i]-(j?sticks.rx:sticks.lx);dy=yy[i]-sticks.ly;m=abs(dx)>abs(dy)?abs(dx):abs(dy);if(m>sticks.r){dx=dx*sticks.r/m;dy=dy*sticks.r/m;m=sticks.r;}
  if(j){sticks.ax=dx;sticks.ay=dy;if(m>dead){d=stick_direction(dx,dy);if(dx*stick_dx[d]+dy*stick_dy[d]>dx*stick_dx[sticks.aim]+dy*stick_dy[sticks.aim]+m*3)sticks.aim=d;}sticks.fire=1;}
  else{sticks.mx=dx;sticks.my=dy;if(m>dead){d=stick_direction(dx,dy);if(prev_move>=0&&dx*stick_dx[d]+dy*stick_dy[d]<=dx*stick_dx[prev_move]+dy*stick_dy[prev_move]+m*3)d=prev_move;sticks.move=d;sticks.power=96+(m-dead)*159/(sticks.r-dead);}}
 }
 sticks.tracking=track;sticks.skill_press=(mask&1)!=0;sticks.swap_press=(mask&2)!=0;sticks.pause_press=(mask&4)!=0;sticks.held=0;for(i=0;i<button_count;i++)sticks.held|=button_contacts[i].kind;
}
