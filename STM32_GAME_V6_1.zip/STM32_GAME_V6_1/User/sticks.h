#ifndef STICKS_H
#define STICKS_H
#include <stdint.h>
typedef struct {int16_t x,y,w,h;} v6_rect;
typedef struct {int16_t lx,ly,rx,ry,r,top;v6_rect skill,swap,pause;int8_t move,aim;uint8_t power,fire,skill_press,swap_press,pause_press,held,blocked,tracking;int16_t mx,my,ax,ay,previous_x[2],previous_y[2];} sticks_t;
extern sticks_t sticks;
extern const int16_t stick_dx[16],stick_dy[16];
int stick_direction(int x,int y);
int v6_hit(v6_rect r,int x,int y);
uint8_t sticks_sensitivity(void);
void sticks_cycle_sensitivity(void);
void sticks_init(void);
void sticks_reset(void);
void sticks_sample(uint16_t x,uint16_t y,uint8_t down);
#endif
