#ifndef UI_ZH_H
#define UI_ZH_H
#include <stdint.h>
uint16_t zh_width(const char *key, uint8_t size);
void zh_draw(uint16_t x, uint16_t y, uint16_t w, uint16_t h,
             uint8_t size, const char *key, uint16_t fg, uint16_t bg);
#endif
