STM32 Touchscreen Game Console V6.1

Open Projects/MDK-ARM/atk_f103.uvprojx in Keil5.
Target: STM32F103ZET6 / ALIENTEK Elite V2 / 4.3-inch touchscreen.
The BRICK_BREAKER build target includes all thirteen games.
Prebuilt firmware: Output/atk_f103.hex
Build evidence: Output/build_v6_1.log
Host verification: Output/host/results.txt

Read the Chinese V6.1 usage guide in this folder before flashing.
V6.1 improves controls and art while retaining all thirteen games.
Cavalier's Flame has 3 heroes, 12 weapons (4 melee), 5 chapters and 3 endings.
Larger dual sticks, curved skill/swap controls and session sensitivity settings.
Original knight/enemy/boss sprites and chapter scenery distinguish Flame from Tank.
Tank retains 4 tanks, 4 modes and 5 maps, with the improved controls.
V6 record format, old scores, sound settings and touch calibration are preserved.
The four melee entries are always visible in the codex, not new EEPROM bits.
Real-board performance and touch response require hardware validation.
