from pathlib import Path
import re
from PIL import Image, ImageDraw, ImageFont

root = Path(__file__).resolve().parents[1]
labels = {
    'SCORE':'得分', 'BEST':'最高', 'LEVEL':'关卡', 'LIFE':'生命',
    'PAUSE':'暂停', 'TOUCH TO LAUNCH':'点击发球', 'GAME PAUSED':'游戏暂停',
    'RESUME':'继续游戏', 'RESTART':'重新开始', 'HOME':'返回大厅',
    'YOU WIN!':'闯关成功', 'GAME OVER':'游戏结束', 'PLAY AGAIN':'再玩一次',
    'HALL':'掌上游戏机', 'HINT':'选择游戏开始游玩',
    'BRICKS':'打砖块', 'SNAKE':'贪吃蛇', 'TETRIS':'俄罗斯方块',
    '2048':'2048', 'MINES':'扫雷', 'XO':'井字棋',
    'READY':'点击开始', 'SOON':'待加入',
    'FOOTER':'第一阶段测试版  /  默认静音',
    'UNAVAILABLE':'此游戏将在后续阶段加入',
}
labels.update({'FOOTER': '六款小游戏  /  记录自动保存', 'SOUND_ON': '声音：开', 'SOUND_OFF': '声音：关', 'SAVE_ERROR': '存档失败，请检查 EEPROM', 'UP': '上', 'DOWN': '下', 'LEFT': '左', 'RIGHT': '右', 'ROTATE': '旋转', 'DROP': '落到底', 'FLAG_ON': '插旗模式', 'REVEAL_ON': '翻格模式', 'FLAG_SWITCH': '切换模式', 'YOU_X': '你执 X', 'CPU_O': '电脑 O', 'START': '开始游戏', 'READY_HELP': '准备好后点击开始', 'DRAW': '平局', 'END_HINT': '本局得分', 'SNAKE_HELP': '方向键转向，吃食物加分', 'TETRIS_HELP': '填满一行即可消除', 'PUZZLE_HELP': '滑动或方向键合并数字', 'MINE_HELP': '十颗雷，首点安全', 'XO_HELP': '你先手，连成三格获胜'})
labels.update({'SLIDE': '数字华容道', 'MEMORY': '记忆翻牌', 'SETTINGS': '设置', 'BACK': '返回', 'PREV': '上一页', 'NEXT_PAGE': '下一页', 'PAGE1': '经典街机  1 / 2', 'PAGE2': '益智挑战  2 / 2', 'SAVE_ERROR': '保存失败，请重试', 'BRIGHTNESS': '亮度', 'TOUCH_FAST': '触摸：灵敏', 'TOUCH_NORMAL': '触摸：标准', 'TOUCH_STABLE': '触摸：稳健', 'IDLE_ON': '待机屏保：开', 'IDLE_OFF': '待机屏保：关', 'TOUCH_TEST': '触摸检测', 'ABOUT': '关于游戏机', 'DEFAULTS': '恢复默认设置', 'SAVE_BACK': '保存并返回', 'RESET_CONFIRM': '恢复默认设置？', 'KEEP_RECORDS': '仅恢复设置，保留游戏记录', 'CONFIRM': '确认', 'CANCEL': '取消', 'CAP_TEST': '电容屏：使用原生坐标，无需四点校准', 'RES_TEST': '电阻屏：可检测坐标或重新校准', 'TOUCH_DRAW': '在下方滑动手指，检查轨迹是否跟手', 'CALIBRATE': '启动触摸校准', 'VERSION': '掌上游戏机 V3', 'SAVE_HINT': '暂停或返回大厅后保存记录', 'EIGHT_GAMES': '八款游戏，随时切换', 'WAKE': '轻触屏幕唤醒', 'EASY': '难度：简单', 'NORMAL': '难度：普通', 'HARD': '难度：困难', 'WALL_MODE': '模式：经典', 'WRAP_MODE': '模式：穿墙', 'OBSTACLE_MODE': '模式：障碍', 'CPU_FIRST': '电脑先手', 'HUMAN_FIRST': '玩家先手', 'UNDO': '撤销一步', 'CONTINUE': '继续挑战', 'SLIDE_HELP': '点相邻数字，按顺序排列', 'MEMORY_HELP': '翻开两张，找到相同数字', 'READY_HELP': '准备好后点击开始', 'HINT': '选择喜爱的游戏', 'MINE_HELP': '首次翻格及相邻格安全', 'XO_HELP': '连成三格即可获胜'})
labels.update({'PLAYS': '游玩', 'WINS': '胜利', 'CARD_BRICKS': '反弹小球，收集生命砖块', 'CARD_SNAKE': '经典、穿墙与障碍挑战', 'CARD_TETRIS': '旋转拼接，挑战连续消行', 'CARD_2048': '滑动合并，向更高数字进发', 'CARD_MINES': '观察数字，找出安全区域', 'CARD_XO': '选择难度，与电脑较量', 'CARD_SLIDE': '移动数字，还原有序棋盘', 'CARD_MEMORY': '记住位置，翻出相同卡片'})
labels.update({'NEXT_PIECE': '下一个', 'TIME': '用时', 'MINES_LEFT': '余雷', 'MOVES': '步数', 'TRIES': '次数'})
labels.update({'VERSION':'掌上游戏机 V4','TEN_GAMES':'十款游戏，随时切换','PAGE1':'经典街机  1 / 3','PAGE2':'益智挑战  2 / 3','PAGE3':'反应挑战  3 / 3',
 'BIRD':'像素小鸟','RACER':'躲避赛车','BIRD_HELP':'点击振翅，穿过管道','RACER_HELP':'左右换道，避开车辆','FLAP':'振翅','HOLD':'暂存','HELD_PIECE':'已暂存','TROPHIES':'成就奖杯',
 'TROPHY_HELP':'挑战目标，点亮十枚奖杯','UNLOCKED':'已达成','LOCKED':'未达成',
 'GOAL_BRICKS':'最高分达到 1000','GOAL_SNAKE':'最高分达到 100','GOAL_TETRIS':'最高分达到 1000','GOAL_2048':'最高分达到 2048','GOAL_MINES':'最高分达到 500','GOAL_XO':'战胜电脑一次','GOAL_SLIDE':'完成一次华容道','GOAL_MEMORY':'完成一次翻牌','GOAL_BIRD':'单局穿过 10 道管道','GOAL_RACER':'单局躲过 20 辆车',
 'CARD_BRICKS':'接住道具，加宽挡板护球','SNAKE_HELP':'十字方向键控制转向','POWER_HELP':'青色加宽，金色护盾'})
labels.update({'VERSION':'掌上游戏机 V5','TEN_GAMES':'十二款游戏，三十六枚奖章','PAGE1':'经典街机  1 / 4','PAGE2':'益智挑战  2 / 4','PAGE3':'动作挑战  3 / 4','PAGE4':'成就与每日挑战  4 / 4',
 'TANK':'坦克大战','SPACE':'太空战机','TANK_HELP':'保护基地，消灭敌人','SPACE_HELP':'拖动战机，自动射击','FIRE':'开火','AUTO_FIRE':'自动开火','BOMB':'清屏炸弹','BOMB_EMPTY':'炸弹已用','NEXT_STAGE':'本关完成，进入下一关',
 'SNAKE_GOAL':'目标：吃十五个','PORTALS':'模式：传送门','SNAKE_TIMED':'限时六十秒','TWO3':'双人：三连棋','TWO4':'双人：四连棋','GRID3':'棋盘：3 x 3','GRID4':'棋盘：4 x 4','GRID5':'棋盘：5 x 5','MEM_TIMED':'限时九十秒','MEM_CLASSIC':'经典翻牌','BIRD_HARD':'变化管道','BIRD_CLASSIC':'经典管道','RACER_FUEL':'燃油挑战','RACER_CLASSIC':'经典赛车','NITRO':'氮气加速','FUEL':'燃油','TURN_X':'轮到 X 落子','TURN_O':'轮到 O 落子','X_WIN':'玩家 X 获胜','O_WIN':'玩家 O 获胜',
 'DAILY':'每日挑战','DAILY_HELP':'每日相同开局，挑战更高分','DAILY_FIXED':'每日固定难度与棋盘','DATE_SET':'日期设置','DATE_HELP':'校准日期后开启每日挑战','DATE_REQUIRED':'请先设置板载时钟日期','YEAR_MINUS':'年份减','YEAR_PLUS':'年份加','MONTH_MINUS':'月份减','MONTH_PLUS':'月份加','DAY_MINUS':'日期减','DAY_PLUS':'日期加','DATE_CONFIRM':'保存日期','RTC_ERROR':'日期无效或时钟未就绪',
 'MEDAL_HINT':'目标顺序：铜 / 银 / 金；井字棋按胜局','BRONZE':'铜牌','SILVER':'银牌','GOLD':'金牌','TROPHY_HELP':'十二款游戏，铜银金三级目标'})
labels.update({'HOUR_MINUS':'小时减','HOUR_PLUS':'小时加','MINUTE_MINUS':'分钟减','MINUTE_PLUS':'分钟加','MINUTE_TEN_MINUS':'减十分钟','MINUTE_TEN_PLUS':'加十分钟','SET_TIME':'下一步：设置时间','DATE_CONFIRM':'保存日期和时间','DATE_SET':'时钟设置','DATE_HELP':'校准日期时间后开启每日挑战'})
labels.update({'PLAYER_X':'玩家 X','PLAYER_O':'玩家 O'})
labels.update({
 'VERSION':'掌上游戏机 V6','TEN_GAMES':'十三款游戏，骑士之火登场',
 'FLAME':'骑士之火','FLAME_FEATURED':'招牌冒险：骑士之火  Cavalier\'s Flame','FLAME_MOTTO':'守护微光，直至长夜终结',
 'TANK_V6':'坦克大战：钢铁战线','TANK_TAG':'独立炮塔 · 双摇杆战斗',
 'BEGIN_ADVENTURE':'开始冒险','SELECT_HERO':'角色与模式','WEAPON_CODEX':'武器图鉴','RECORDS':'冒险记录','CHANGE_HERO':'切换角色','SKILL':'技能','SWAP_WEAPON':'换武器',
 'TANK_SKILL_HINT':'双摇杆','MOVE_STICK':'移动','FIRE_STICK':'瞄准开火','TANK_GUIDE':'操作指南','CONTROL_HELP':'左手移动，右手瞄准并持续开火',
 'TANK_MODES_HELP':'战役守基地，生存迎敌，占领守点', 'TANK_MAPS_HELP':'城市、沼泽、沙漠、冰原、要塞', 'TANK_SKILLS_HELP':'技能有冷却，重炮与基地都会受弹',
 'H_KNIGHT':'烬火骑士','H_ENGINEER':'余烬工匠','H_RANGER':'灰羽游侠',
 'T_ASSAULT':'突击坦克','T_HEAVY':'重型坦克','T_ROCKET':'火箭坦克','T_LASER':'激光坦克',
 'SK_KNIGHT':'焰怒：短时间提升射速','SK_ENGINEER':'守火炮台：部署自动攻击炮台','SK_RANGER':'闪避翻滚：突进并短暂无敌',
 'SK_ASSAULT':'突击：提升射速和移动速度','SK_HEAVY':'钢铁壁垒：短时间免疫伤害','SK_ROCKET':'火箭齐射：五枚爆炸弹','SK_LASER':'过载光束：穿透弹幕',
 'M_CAMPAIGN':'模式：基地战役','M_SURVIVAL':'模式：无尽生存','M_CAPTURE':'模式：据点占领','M_BOSS':'模式：首领挑战',
 'MAP_CITY':'地图：灰砖城市','MAP_SWAMP':'地图：沉沼湿地','MAP_DESERT':'地图：赤砂荒漠','MAP_ICE':'地图：寒霜冰原','MAP_FORT':'地图：黑钢要塞',
 'W_PISTOL':'守誓手枪','W_SMG':'余烬冲锋枪','W_SHOTGUN':'烈火霰弹枪','W_SNIPER':'破晓狙击枪','W_ROCKET':'熔岩火箭筒','W_LASER':'星光激光枪','W_BOUNCE':'回响弹射枪','W_ICE':'寒霜冰冻枪',
 'P_HEALTH':'坚韧：增加生命并治疗','P_DAMAGE':'锋芒：提升弹丸伤害','P_RATE':'迅击：缩短射击间隔','P_SPEED':'疾步：提升移动速度','P_ARMOR':'护甲：增加护甲上限','P_ENERGY':'火种：增加能量上限','P_CRIT':'会心：提高暴击几率','P_RECOVER':'汲能：击败敌人回复能量','P_SHIELD':'屏障：补满护甲并短暂无敌','P_PIERCE':'贯穿：弹丸可穿透敌人','P_COOL':'专注：缩短技能冷却','P_VAMP':'复苏：每五次击败回复生命',
 'CH_ASH':'第一章：灰烬地牢','CH_FORGE':'第二章：沉默工坊','CH_GARDEN':'第三章：遗忘花园','CH_TOWER':'第四章：破碎星塔','CH_THRONE':'最终章：无火王座',
 'B_MECH':'废弃机甲','B_FORGE':'熔炉监工','B_THORN':'荆棘女王','B_STAR':'星核观测者','B_LOST':'失焰骑士',
 'INTRO_1':'永燃圣殿的火焰，在无月之夜熄灭。','INTRO_2':'失踪骑士的记忆，被锁进黑钢军团。','INTRO_3':'你握着最后的微光，踏入移动的地牢。','INTRO_4':'夺回五枚火种，查明长夜的真相。',
 'MEMORY_0_A':'我们制造武器，','MEMORY_0_B':'是为了让骑士能够回家。',
 'MEMORY_1_A':'如果胜利需要失去灵魂，','MEMORY_1_B':'那么这场战争从未真正结束。',
 'MEMORY_2_A':'守护不是把一切留在原地，','MEMORY_2_B':'而是让它们有继续生长的机会。',
 'MEMORY_3_A':'团长关闭圣殿大门，说要保护世界。','MEMORY_3_B':'但他已经不再相信任何人。',
 'MEMORY_4_A':'火焰不只是力量。','MEMORY_4_B':'它让迷路的人知道回去的方向。',
 'CHOOSE_PERK':'房间已净化 · 选择一项强化','CHOOSE_ROUTE':'选择下一段路线','ROUTE_BATTLE':'直达下一间战斗房','ROUTE_CHEST':'探索遗物室与骑士记忆','ROUTE_SHOP':'拜访流浪商人',
 'FOUND_WEAPON':'遗物箱中发现武器','TAKE_WEAPON':'拾取并装备，旧武器转为备用','KEEP_WEAPON':'保留当前武器，继续前进',
 'BUY_HEALTH':'治疗四点生命 · 八金币','BUY_WEAPON':'购买随机武器 · 十二金币','LEAVE_SHOP':'离开商店，继续冒险',
 'FINAL_QUESTION':'火焰终会引发争夺，为何还要点燃？','ENDING_LIGHT':'重新点燃圣殿','ENDING_SCATTER':'带走火种，分给世人','ENDING_KEEPER':'唤醒失焰骑士 · 最后的守火者','MEMORIES_MISSING':'隐藏结局：需收集五章骑士记忆',
 'END_LIGHT_TEXT':'火焰属于每一个愿意照亮他人的人。','END_SCATTER_TEXT':'无数微光，亮起在归家的路上。','END_KEEPER_TEXT':'蓝色火焰记住，曾有人走过这里。',
 'PLAYS_WINS':'冒险次数 / 通关次数','HERO_FLOORS':'骑士 / 工匠 / 游侠 · 最深章节',
 'MEMORY_FOUND':'你解救了一段被黑钢囚禁的记忆','BASE_HP':'基地耐久','WAVE':'敌军波次','CAPTURE':'占领进度','BOSS_STAGE':'首领关卡',
 'SECRET_0_A':'徽章背面，刻着失踪骑士的誓言。','SECRET_0_B':'守护微光，直至长夜终结。',
 'SECRET_1_A':'工坊记录：团长将火种植入铠甲。','SECRET_1_B':'他想造出永不疲倦的和平军队。',
 'SECRET_2_A':'守花人主动与黑钢融合。','SECRET_2_B':'花园活了下来，她却忘记了自己。',
 'SECRET_3_A':'骑士之火来自自由的意志。','SECRET_3_B':'被强迫服从的记忆，成了黑钢核心。',
 'SECRET_4_A':'失焰骑士，就是最后的骑士团团长。','SECRET_4_B':'带回全部记忆，或许能让他醒来。'
})
labels.update({'VERSION':'掌上游戏机 V6.1','TEN_GAMES':'十三款游戏 · 操作与画面优化',
 'W_SWORD':'守誓长剑','W_GREATSWORD':'熔火重剑','W_SPEAR':'破晓长枪','W_CIRCLE':'回旋刃',
 'AIM_ATTACK':'瞄准攻击','ACTION_FURY':'焰怒','ACTION_TURRET':'炮台','ACTION_ROLL':'翻滚','ACTION_SWAP':'切换','COOLDOWN':'冷却','BACKUP':'备用武器','PISTOL_ASSIST':'手枪支援',
 'STICK_LOW':'摇杆：稳健（本次）','STICK_MED':'摇杆：标准（本次）','STICK_HIGH':'摇杆：灵敏（本次）',
 'SK_KNIGHT':'焰怒：提升开火与挥砍速度','SK_RANGER':'闪避翻滚：短暂无敌并强化下一次近战',
 'P_DAMAGE':'锋芒：提升武器伤害','P_RATE':'迅击：缩短攻击间隔'})
chars = sorted(set(''.join(labels.values())) - set(chr(i) for i in range(128)))
def cstr(s):
    return '"' + ''.join('\\%03o'%b for b in s.encode('utf-8')) + '"'

header = '''#ifndef UI_ZH_H
#define UI_ZH_H
#include <stdint.h>
uint16_t zh_width(const char *key, uint8_t size);
void zh_draw(uint16_t x, uint16_t y, uint16_t w, uint16_t h,
             uint8_t size, const char *key, uint16_t fg, uint16_t bg);
#endif
'''
(root/'User/ui_zh.h').write_text(header,encoding='ascii')
out = ['#include "ui_zh.h"', '#include "./BSP/LCD/lcd.h"', '#include <string.h>',
       'typedef struct { const char *key; const char *value; } label_t;',
       'static const label_t labels[] = {']
out += ['{%s,%s},'%(cstr(k),cstr(v)) for k,v in labels.items()]
out += ['};', 'static const uint16_t codes[] = {'+','.join(str(ord(c)) for c in chars)+'};']
for size in (12,16,24,32):
    font = ImageFont.truetype('C:/Windows/Fonts/simhei.ttf',size)
    out.append('static const uint8_t glyph%d[%d][%d] = {'%(size,len(chars),size*((size+7)//8)))
    for ch in chars:
        im=Image.new('1',(size,size)); d=ImageDraw.Draw(im)
        box=d.textbbox((0,0),ch,font=font)
        d.text(((size-(box[2]-box[0]))//2-box[0],(size-(box[3]-box[1]))//2-box[1]),ch,font=font,fill=1)
        data=[]
        for y in range(size):
            for bx in range((size+7)//8):
                byte=0
                for bit in range(8):
                    x=bx*8+bit
                    if x<size and im.getpixel((x,y)): byte |= 128>>bit
                data.append(byte)
        out.append('{'+','.join('0x%02x'%v for v in data)+'},')
    out.append('};')
out.append(r'''
static const char *lookup(const char *key) {
    unsigned i;
    for(i=0;i<sizeof(labels)/sizeof(labels[0]);i++)
        if(strcmp(key,labels[i].key)==0) return labels[i].value;
    return key;
}
/* All translated strings are generated, validated UTF-8 BMP literals. */
static uint16_t next_char(const char **s) {
    const unsigned char *p=(const unsigned char *)*s;
    uint16_t c;
    if(*p<128) { c=*p; *s+=1; }
    else { c=(uint16_t)(((p[0]&15)<<12)|((p[1]&63)<<6)|(p[2]&63)); *s+=3; }
    return c;
}
uint16_t zh_width(const char *key, uint8_t size) {
    const char *s=lookup(key); uint16_t w=0;
    while(*s) w+=(next_char(&s)<128)?size/2:size;
    return w;
}
void zh_draw(uint16_t x,uint16_t y,uint16_t w,uint16_t h,uint8_t size,
             const char *key,uint16_t fg,uint16_t bg) {
    const char *s=lookup(key); uint16_t c,advance,xx,yy; unsigned i;
    uint32_t end=(uint32_t)x+w; const uint8_t *bits; uint8_t stride=(size+7)/8;
    if(size!=12 && size!=16 && size!=24 && size!=32) return;
    if(h<size || (uint32_t)y+size>lcddev.height) return;
    while(*s) {
        c=next_char(&s); advance=(c<128)?size/2:size;
        if((uint32_t)x+advance>end || (uint32_t)x+advance>lcddev.width) break;
        if(c<128) { g_back_color=bg; lcd_show_char(x,y,(char)c,size,0,fg); }
        else {
            for(i=0;i<sizeof(codes)/sizeof(codes[0]);i++) if(codes[i]==c) break;
            if(i<sizeof(codes)/sizeof(codes[0])) {
                bits=(size==12)?glyph12[i]:(size==16)?glyph16[i]:(size==24)?glyph24[i]:glyph32[i];
                for(yy=0;yy<size;yy++) for(xx=0;xx<size;xx++)
                    lcd_draw_point(x+xx,y+yy,(bits[yy*stride+xx/8]&(128>>(xx%8)))?fg:bg);
            }
        }
        x+=advance;
    }
}
''')
(root/'User/ui_zh.c').write_text('\n'.join(out),encoding='ascii')
