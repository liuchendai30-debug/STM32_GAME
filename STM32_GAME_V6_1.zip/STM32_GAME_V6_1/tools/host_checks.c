static void shot(const char *name) {
    char path[128];unsigned x,y;FILE *f;snprintf(path,sizeof path,"%s_%u.ppm",name,lcddev.width);f=fopen(path,"wb");assert(f);
    fprintf(f,"P6\n%u %u\n255\n",lcddev.width,lcddev.height);
    for(y=0;y<lcddev.height;y++)for(x=0;x<lcddev.width;x++){uint16_t c=frame[y][x];fputc(((c>>11)&31)*255/31,f);fputc(((c>>5)&63)*255/63,f);fputc((c&31)*255/31,f);}fclose(f);
}
/* Legacy checks skip the new countdown; V5 checks exercise it explicitly. */
static uint8_t tap_extra(rect_t r,uint32_t now){uint8_t result;mock_now=now;result=arcade_tick(now,r.x+r.w/2,r.y+r.h/2,1,0,1);if(a.state==COUNTDOWN){a.state=PLAY;a.last=a.tick=now;scene();}return result;}
static void start_extra(int id,uint32_t now){arcade_start(id,now);assert(a.state==READY);tap_extra(a.modal[0],now+1);assert(a.state==PLAY);}
static void v2_record(int base,uint32_t seq,uint32_t score){uint8_t *r=eeprom+base;memset(r,0,40);r[0]=0xa5;r[1]='G';r[2]='C';r[3]=2;r[4]=1;put32(r+8,seq);put32(r+12,score);put32(r+36,crc(r,36));}
static void storage_checks(void){
    uint8_t backup[256];int i,cut,choice;
    memset(eeprom,0xff,256);memset(eeprom+40,0x57,13);write_budget=-1;console_init();
    assert(!console_sound()&&console_brightness()==100&&console_touch_ms()==18);
    for(choice=0;choice<2;choice++){
        memset(eeprom+64,0xff,192);v2_record(64,choice?3:1,123);v2_record(128,2,456);memcpy(backup,eeprom,256);
        for(cut=0;cut<=170;cut++){
            memcpy(eeprom,backup,256);write_budget=-1;console_init();assert(console_best(0)==(choice?123:456)&&console_sound());
            write_budget=cut;console_flush();write_budget=-1;console_init();assert(console_best(0)==(choice?123:456));
            for(i=40;i<53;i++)assert(eeprom[i]==0x57);
        }
    }
    console_set_brightness(60);console_set_option(0,2);console_cycle_touch();console_record(7,4500);console_started(7);console_won(7);console_flush();console_init();
    assert(console_brightness()==60&&backlight_value==60&&console_option(0)==2&&console_touch_ms()==10&&console_best(7)==4500&&console_plays(7)==1&&console_wins(7)==1);
    memcpy(backup,eeprom,256);
    for(cut=0;cut<=89;cut++){
        memcpy(eeprom,backup,256);write_budget=-1;console_init();console_record(7,4600);write_budget=cut;console_flush();write_budget=-1;console_init();assert(console_best(7)==4500||console_best(7)==4600);
    }
    console_defaults();console_init();assert(console_best(7)>=4500&&console_plays(7)==1&&!console_sound()&&console_brightness()==100);
    console_toggle_sound();console_beep(100,20);assert(beep_output);console_service(120);assert(!beep_output);
    write_budget=0;console_record(6,200);console_flush();assert(console_save_error());write_budget=-1;
    puts("PASS storage: V2 migration with either newest slot at all 171 cuts; V4 writes at all 90 cuts; settings/stats; calibration isolation; defaults preserve scores; beep timer.");
}
static void rules_checks(void){
    int i,j,k,d,n,inv,b,cnt[16],first,second;uint32_t before[16],score;
    console_defaults();
    game_init();game_start_new(100);g_game.level=3;game_setup_level();
    for(i=1;i<=GAME_MAX_LEVEL;i++){g_game.level=i;game_setup_level();b=0;for(j=0;j<GAME_MAX_ROWS;j++)for(k=0;k<GAME_MAX_COLS;k++)b+=g_game.bricks[j][k]!=0;assert(b>0&&b==g_game.bricks_left);}
    g_game.bricks[0][0]=2;b=g_game.bricks_left;game_destroy_brick(0,0,150);assert(g_game.bricks[0][0]==1&&g_game.bricks_left==b);
    game_destroy_brick(0,0,160);assert(!g_game.bricks[0][0]&&g_game.bricks_left==b-1);
    g_game.bricks[0][1]=3;g_game.lives=4;game_destroy_brick(0,1,170);assert(g_game.lives==5);
    g_game.bricks[0][2]=3;game_destroy_brick(0,2,180);assert(g_game.lives==5);
    start_extra(3,1000);memset(a.g.puzzle.v,0,sizeof a.g.puzzle.v);for(i=0;i<4;i++)a.g.puzzle.v[i]=2;memcpy(before,a.g.puzzle.v,sizeof before);
    puzzle_move(3,1100);assert(a.g.puzzle.v[0]==4&&a.g.puzzle.v[1]==4&&a.score==8);puzzle_undo();assert(a.score==0&&memcmp(before,a.g.puzzle.v,sizeof before)==0&&!a.g.puzzle.can_undo);
    memset(a.g.puzzle.v,0,sizeof a.g.puzzle.v);a.g.puzzle.v[0]=a.g.puzzle.v[1]=1024;puzzle_move(3,1200);assert(a.state==OVER&&a.won);
    tap_extra(a.modal[0],1300);assert(a.state==PLAY&&a.g.puzzle.target==4096&&a.started);
    for(d=0;d<3;d++){
        console_set_option(0,d);start_extra(1,2000);a.g.snake.dir=a.g.snake.pending=3;a.g.snake.x[0]=0;
        snake_step(2100);if(d==1)assert(a.state==PLAY&&a.g.snake.x[0]==19);else assert(a.state==OVER);
    }
    console_set_option(0,2);start_extra(1,2200);a.g.snake.x[0]=4;a.g.snake.y[0]=4;a.g.snake.dir=a.g.snake.pending=1;snake_step(2300);assert(a.state==OVER);
    start_extra(2,3000);memset(a.g.tet.cells,0,sizeof a.g.tet.cells);for(i=0;i<10;i++)a.g.tet.cells[19][i]=1;for(i=3;i<7;i++)a.g.tet.cells[19][i]=0;
    a.g.tet.kind=0;a.g.tet.rot=0;a.g.tet.x=3;a.g.tet.y=18;tet_lock(3100);assert(a.g.tet.lines==1&&a.score==100&&a.clear_mask);
    arcade_tick(3300,0,0,0,0,0);assert(!a.clear_mask);
    start_extra(2,3400);a.g.tet.x=3;tap_extra(a.controls[0],3500);b=a.g.tet.x;arcade_tick(3850,a.controls[0].x+5,a.controls[0].y+5,0,0,1);assert(a.g.tet.x<b);
    arcade_tick(3860,0,0,0,1,0);assert(a.held==255);
    for(d=0;d<3;d++){
        console_set_option(2,d);start_extra(4,4000+d);n=a.cols*a.rows;mines_place(n/2);
        b=0;for(i=0;i<n;i++){b+=a.g.mines.bombs[i];if(abs(i%a.cols-(n/2)%a.cols)<=1&&abs(i/a.cols-(n/2)/a.cols)<=1)assert(!a.g.mines.bombs[i]);}assert(b==a.mine_count);
        for(i=0;i<n&&a.state==PLAY;i++)if(!a.g.mines.bombs[i])mines_reveal(i,4100+i);assert(a.state==OVER&&a.won&&a.g.mines.revealed==n-a.mine_count);
    }
    console_set_option(3,2);console_set_option(4,0);start_extra(5,5000);a.g.xo.v[0]=a.g.xo.v[1]=1;a.g.xo.v[4]=-1;xo_ai(5100);assert(a.g.xo.v[2]==-1);
    console_set_option(4,1);start_extra(5,5200);assert(a.g.xo.ai_pending);arcade_tick(5500,0,0,0,0,0);b=0;for(i=0;i<9;i++)b+=a.g.xo.v[i]==-1;assert(b==1);
    for(k=0;k<100;k++){
        start_extra(6,6000+k);memset(cnt,0,sizeof cnt);inv=0;for(i=0;i<16;i++){cnt[a.g.slide.v[i]]++;for(j=i+1;j<16;j++)if(a.g.slide.v[i]&&a.g.slide.v[j]&&a.g.slide.v[i]>a.g.slide.v[j])inv++;}
        for(i=0;i<16;i++)assert(cnt[i]==1);assert((inv+4-a.g.slide.blank/4)%2==1);assert(!slide_solved());
    }
    for(i=0;i<15;i++)a.g.slide.v[i]=i+1;a.g.slide.v[14]=0;a.g.slide.v[15]=15;a.g.slide.blank=14;a.g.slide.moves=0;slide_move(15,7000);assert(a.state==OVER&&a.won&&a.score>0);
    start_extra(7,8000);memset(cnt,0,sizeof cnt);for(i=0;i<16;i++)cnt[a.g.memory.v[i]]++;for(i=0;i<8;i++)assert(cnt[i]==2);
    first=0;second=1;while(a.g.memory.v[second]==a.g.memory.v[first])second++;memory_pick(first,8100);memory_pick(second,8150);b=a.g.memory.first;
    memory_pick(15,8200);assert(a.g.memory.first==b);arcade_tick(8900,0,0,0,0,0);assert(a.g.memory.first==255&&a.g.memory.second==255);
    for(i=0;i<8;i++){first=second=-1;for(j=0;j<16;j++)if(a.g.memory.v[j]==i){if(first<0)first=j;else second=j;}memory_pick(first,9000+i*10);memory_pick(second,9005+i*10);}
    assert(a.state==OVER&&a.won&&a.g.memory.pairs==8);
    score=a.score;assert(score>0);puts("PASS rules: 8 brick layouts/armor/life cap; undo/continue 2048; snake 3 modes; tetris clear/repeat; mines 3 sizes; hard AI/first player; 100 solvable puzzles; memory mismatches and full win.");
}
static uint8_t sh_tap(sh_rect r,uint32_t now){sh_active=now-1;shell_tick(now-1,0,0,0,1,0);return shell_tick(now,r.x+r.w/2,r.y+r.h/2,1,0,1);}
static void route_checks(void){
    int k,id,v;uint8_t selected;char name[40];uint32_t elapsed;
    console_defaults();
    for(k=0;k<2;k++){
        lcddev.width=k?800:480;lcddev.height=k?480:272;lcddev.id=0x5310;
        memset(&g_game,0,sizeof g_game);game_init();sh_page=0;shell_show();shot("hall_page1");
        sh_tap(sh_right,1000);assert(sh_page==1);shot("hall_page2");sh_tap(sh_right,1002);assert(sh_page==2);shot("hall_page3");sh_tap(sh_right,1003);assert(sh_page==3);shot("hall_page4");sh_tap(sh_cards[0],1004);assert(sh_view==5);shot("trophies");sh_tap(sh_back,1006);assert(sh_view==0);sh_tap(sh_back,1010);assert(sh_view==1);
        for(v=1;v<=5;v++){sh_view=v;sh_draw();sprintf(name,"system_%d",v);shot(name);}
        for(id=0;id<10;id++){
            sh_page=id/4;shell_show();selected=sh_tap(sh_cards[id%4],1100+id);assert(selected==id+1);
            if(!id){game_start_new(1200);shot("bricks_v4");g_game.level=3;game_setup_level();game_draw_scene();shot("bricks_armor");game_finish(0);shot("bricks_result");continue;}
            arcade_start(id,2000);sprintf(name,"ready_%d",id);shot(name);tap_extra(a.modal[0],2100);assert(a.state==PLAY);
            sprintf(name,"game_%d",id);shot(name);
            tap_extra(a.pause,2200);assert(a.state==PAUSED);elapsed=a.elapsed;sprintf(name,"pause_%d",id);shot(name);
            arcade_tick(9000,0,0,0,0,0);assert(a.elapsed==elapsed);tap_extra(a.modal[0],9100);assert(a.state==PLAY);
            tap_extra(a.pause,9200);assert(tap_extra(a.modal[2],9300));
            arcade_start(id,9400);finish(1,9500);sprintf(name,"win_%d",id);shot(name);
        }
        shell_show();sh_active=0;shell_tick(60001,0,0,0,0,0);assert(sh_sleep&&backlight_value==20);
        assert(shell_tick(60100,100,100,1,0,1)==0&&!sh_sleep&&backlight_value==console_brightness());
        assert(shell_tick(60105,sh_cards[0].x+5,sh_cards[0].y+5,1,0,1)==0);
    }
    puts("PASS routes/render: 480x272 and 800x480, 10 games and trophy room, settings/touch/about/defaults, all game pause/resume/home, paused clocks, sleep/wake touch suppression.");
}
static void v3_record(int base,uint32_t seq,uint32_t offset){
    uint8_t *r=eeprom+base;int i;memset(r,0,80);r[0]=0xa5;r[1]='G';r[2]='C';r[3]=3;r[4]=1;r[5]=60;r[6]=30;r[7]=1;put32(r+8,seq);
    for(i=0;i<8;i++){put32(r+12+4*i,offset+i);r[44+2*i]=20+i;r[45+2*i]=3;r[60+i]=5+i;}
    r[68]=2;r[69]=1;r[70]=2;r[71]=1;r[72]=1;put32(r+76,crc(r,76));
}
static void v4_storage_checks(void){
    int choice,cut,i;uint8_t backup[256];uint32_t wanted;
    for(choice=0;choice<2;choice++){
        memset(eeprom,0xff,256);memset(eeprom+40,0x39,13);v3_record(64,choice?11:9,2000);v3_record(168,10,3000);memcpy(backup,eeprom,256);wanted=choice?2000:3000;
        for(cut=0;cut<=89;cut++){
            memcpy(eeprom,backup,256);write_budget=-1;console_init();assert(console_best(0)==wanted);
            write_budget=cut;console_flush();write_budget=-1;console_init();
            for(i=0;i<8;i++){assert(console_best(i)==wanted+i);assert(console_plays(i)==788+i);assert(console_wins(i)==5+i);}
            assert(console_brightness()==60&&console_touch_ms()==30&&console_sound()&&console_option(0)==2&&console_option(4)==1);
            for(i=40;i<53;i++)assert(eeprom[i]==0x39);assert(eeprom[255]==255);
        }
    }
    console_record(8,25);console_record(9,35);console_started(8);console_started(9);console_flush();console_init();
    assert(console_best(8)==25&&console_best(9)==35&&console_plays(8)==1&&console_plays(9)==1&&console_trophy(8)&&console_trophy(9));
    console_defaults();console_init();assert(console_best(8)==25&&console_trophy(9));
    puts("PASS V4 migration: both newest V3 slots, all 90 interruption points, full scores/stats/settings preserved, new game records and derived trophies survive reboot.");
}
static void v4_rules_checks(void){
    int k,i,j,old,next,w,lives;uint32_t score,elapsed;
    for(k=0;k<2;k++){
        lcddev.width=k?800:480;lcddev.height=k?480:272;console_defaults();start_extra(1,10000);
        assert(a.controls[0].x==a.controls[1].x&&a.controls[2].y==a.controls[3].y);
        assert(a.controls[0].y<a.controls[2].y&&a.controls[1].y>a.controls[2].y);
        assert(a.controls[2].x<a.controls[0].x&&a.controls[3].x>a.controls[0].x);
        for(i=0;i<4;i++){assert(a.controls[i].w>=40&&a.controls[i].h>=40);for(j=0;j<4;j++)if(i!=j)assert(!inside(a.controls[i],a.controls[j].x+a.controls[j].w/2,a.controls[j].y+a.controls[j].h/2));}
        a.g.snake.dir=a.g.snake.pending=1;tap_extra(a.controls[2],10002);assert(a.g.snake.pending==1);
        tap_extra(a.controls[0],10003);tap_extra(a.controls[2],10004);assert(a.g.snake.pending==0);
        arcade_tick(10005,a.controls[0].x+5,a.controls[2].y+5,1,0,1);assert(a.state==PLAY);
        start_extra(2,11000);old=a.g.tet.kind;next=a.g.tet.next;tet_action(5,11001);
        assert(a.g.tet.hold==old&&a.g.tet.kind==next&&a.g.tet.held_once);tet_action(5,11002);assert(a.g.tet.kind==next);
        tet_action(4,11003);assert(!a.g.tet.held_once);tet_action(5,11004);assert(a.g.tet.kind==old&&a.g.tet.held_once);
        start_extra(2,12000);j=0;for(i=0;i<200;i++)if(a.g.tet.paint[i/10][i%10]==8)j++;assert(j==4);
        shot("tetris_ghost");tet_action(5,12001);shot("tetris_hold");
        start_extra(8,13000);control_action(0,13001);assert(a.g.bird.vy<0);a.g.bird.y=100L<<8;a.g.bird.vy=0;a.g.bird.pipe_x=16;a.g.bird.gap_y=100;
        action_step(13020);assert(a.state==PLAY&&a.score==1);action_step(13040);assert(a.score==1);
        a.g.bird.pipe_x=48;a.g.bird.y=30L<<8;a.g.bird.vy=0;action_step(13060);assert(a.state==OVER);
        start_extra(8,14000);a.g.bird.y=2L<<8;action_step(14020);assert(a.state==OVER);
        start_extra(8,15000);tap_extra(a.pause,15010);old=a.g.bird.y;elapsed=a.elapsed;arcade_tick(19000,0,0,0,0,0);assert(a.g.bird.y==old&&a.elapsed==elapsed);tap_extra(a.modal[0],19001);assert(a.state==PLAY);arcade_tick(19002,0,0,0,0,0);assert(a.g.bird.y==old);
        start_extra(9,20000);control_action(0,20001);control_action(0,20002);assert(a.g.racer.lane==0);control_action(1,20003);control_action(1,20004);control_action(1,20005);assert(a.g.racer.lane==2);
        a.g.racer.obstacle_lane=0;a.g.racer.obstacle_y=199;action_step(20020);assert(a.score==1&&a.g.racer.obstacle_y==-40);
        a.g.racer.obstacle_lane=2;a.g.racer.obstacle_y=150;action_step(20040);assert(a.state==OVER);
        game_init();game_start_new(21000);w=g_game.paddle_w;g_game.power_kind=1;g_game.power_x=g_game.paddle_x+w/2;g_game.power_y=g_game.paddle_y-2;game_step_power(21001);assert(g_game.paddle_w==w+w/2&&!g_game.power_kind);
        g_game.power_kind=2;g_game.power_x=g_game.paddle_x+5;g_game.power_y=g_game.paddle_y;game_step_power(21002);assert(g_game.shield&&!g_game.power_kind);
        game_draw_scene();shot("bricks_power");game_launch_ball(21003);lives=g_game.lives;g_game.ball_x=((int32_t)g_game.field_left+10)<<8;g_game.ball_y=((int32_t)g_game.field_bottom-2)<<8;g_game.ball_vy=500;
        game_step_physics(21020);assert(!g_game.shield&&g_game.lives==lives&&g_game.ball_vy<0);
        game_reset_ball();assert(g_game.paddle_w==w&&!g_game.power_kind&&!g_game.shield);
        score=console_best(8);console_record(8,0);assert(console_best(8)==score);
    }
    puts("PASS V4 controls/rules: cross D-pad geometry and reversal guard, inert center, hold once per piece, four ghost cells, bird flap/scoring/collisions/pause, racer lanes/scoring/collision, caught powerups and one-use shield.");
}
static uint32_t board_hash(void){int x,y;uint32_t h=2166136261U;for(y=a.by;y<a.by+a.cell*a.rows;y++)for(x=a.bx;x<a.bx+a.cell*a.cols;x++)h=(h^frame[y][x])*16777619U;return h;}
static void action_render_checks(void){
    int k,id,i;uint32_t h;char name[32];
    for(k=0;k<2;k++){
        lcddev.width=k?800:480;lcddev.height=k?480:272;
        for(id=8;id<=9;id++){
            start_extra(id,30000);
            if(id==8){a.g.bird.pipe_x=180;a.g.bird.vy=-350;}else{a.g.racer.obstacle_y=10;a.g.racer.obstacle_lane=0;}
            draw_board();
            for(i=0;i<20;i++){
                action_step(30020+i*20);assert(a.state==PLAY);h=board_hash();draw_board();assert(board_hash()==h);
            }
            sprintf(name,"action_%d",id);shot(name);
        }
    }
    puts("PASS action rendering: moving sprites and pipes leave no trails; partial redraw matches full redraw over 20 frames for each new game at both resolutions.");
}
static void legacy_checks(void){lcddev.width=800;lcddev.height=480;storage_checks();v4_storage_checks();rules_checks();v4_rules_checks();route_checks();action_render_checks();}
