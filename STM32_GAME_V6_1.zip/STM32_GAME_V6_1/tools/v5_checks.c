static void ext_checks(void){
    uint8_t snapshot[256];int cut,i;memset(eeprom,255,256);write_budget=-1;console_init();console_record(0,2345);console_set_brightness(40);console_flush();console_record(10,1500);console_record(11,2000);console_started(10);console_won(11);console_flush();memcpy(snapshot,eeprom,256);
    for(cut=0;cut<=21;cut++){memcpy(eeprom,snapshot,256);write_budget=-1;console_init();console_record(10,3000);write_budget=cut;console_flush();write_budget=-1;console_init();assert(console_best(10)==1500||console_best(10)==3000);assert(console_best(11)==2000&&console_best(0)==2345&&console_brightness()==40);assert(!memcmp(eeprom+40,snapshot+40,216));}
    for(i=0;i<260;i++){console_record(11,3000+i);console_flush();console_init();assert(console_best(11)==3000U+i);}
    console_record(10,15000);console_flush();console_init();assert(console_medal(10)==3);console_defaults();assert(console_best(10)==15000);
    puts("PASS V5 storage: supplemental slots all 22 cuts; V4/calibration untouched; sequence wrap; both new game records; medal/default preservation.");
}
static void v5_old_rules(void){int i,j,n,k,inv;uint8_t counts[25],saved[25];uint32_t score;uint16_t yy;uint8_t mm,dd;
    memset(variants,0,sizeof variants);arcade_set_daily(0);console_defaults();
    start_extra(1,100);a.g.snake.fx=9;a.g.snake.fy=8;snake_step(120);assert(a.score==10);a.g.snake.fx=10;a.g.snake.fy=8;snake_step(140);assert(a.score==30&&a.g.snake.combo==2);
    variants[1]=5;start_extra(1,200);a.g.snake.x[0]=1;a.g.snake.y[0]=2;a.g.snake.dir=a.g.snake.pending=0;snake_step(220);assert(a.g.snake.x[0]==18&&a.g.snake.y[0]==14);
    for(i=0;i<1000;i++){snake_food();assert(!(a.g.snake.fx==1&&a.g.snake.fy==1)&&!(a.g.snake.fx==18&&a.g.snake.fy==14));}
    variants[1]=6;start_extra(1,300);a.elapsed=60001;arcade_tick(301,0,0,0,0,0);assert(a.state==OVER);
    start_extra(2,400);a.g.tet.bag_at=7;for(k=0;k<20;k++){memset(counts,0,sizeof counts);for(i=0;i<7;i++)counts[tet_bag()]++;for(i=0;i<7;i++)assert(counts[i]==1);}
    score=a.score;tet_action(3,410);assert(a.score==score+1);score=a.score;tet_action(6,420);assert(a.score==score);
    variants[3]=1;start_extra(3,500);assert(a.cols==5);memset(a.g.puzzle.v,0,sizeof a.g.puzzle.v);for(i=0;i<5;i++)a.g.puzzle.v[i]=2;puzzle_move(3,510);assert(a.g.puzzle.v[0]==4&&a.g.puzzle.v[1]==4&&a.g.puzzle.v[2]==2&&a.score==8&&a.g.puzzle.moves==1);puzzle_undo();for(i=0;i<5;i++)assert(a.g.puzzle.v[i]==2);
    for(k=0;k<3;k++){variants[6]=k;for(j=0;j<40;j++){start_extra(6,600+j);n=a.cols*a.rows;memset(counts,0,sizeof counts);inv=0;for(i=0;i<n;i++){counts[a.g.slide.v[i]]++;for(int z=i+1;z<n;z++)if(a.g.slide.v[i]&&a.g.slide.v[z]&&a.g.slide.v[i]>a.g.slide.v[z])inv++;}for(i=0;i<n;i++)assert(counts[i]==1);assert(a.cols%2?inv%2==0:(inv+a.rows-a.g.slide.blank/a.cols)%2==1);}}
    variants[5]=4;start_extra(5,800);assert(a.cols==4&&a.mode==3);for(i=0;i<4;i++)a.g.xo.v[i]=-1;assert(xo_result()==-1);xo_check(810);assert(a.state==OVER&&a.won==3&&a.score==0);
    variants[7]=1;start_extra(7,900);a.elapsed=90001;arcade_tick(901,0,0,0,0,0);assert(a.state==OVER);
    start_extra(4,1000);i=a.bx+2;j=a.by+2;arcade_tick(1010,i,j,1,0,1);assert(!a.g.mines.revealed);arcade_tick(1520,i,j,0,0,1);assert(a.g.mines.flags[0]);arcade_tick(1530,i,j,0,1,0);assert(!a.g.mines.revealed);
    start_extra(4,1600);i=a.bx+2;j=a.by+2;arcade_tick(1610,i,j,1,0,1);arcade_tick(1620,i,j,0,1,0);assert(a.g.mines.open[0]&&!a.g.mines.bombs[0]);
    variants[9]=1;start_extra(9,1800);a.g.racer.fuel=40;control_action(4,1810);assert(a.g.racer.fuel==20&&a.g.racer.boost_until>0);a.g.racer.lane=2;a.g.racer.obstacle_lane=0;a.g.racer.obstacle_y=199;action_step(1820);assert(a.score==2);
    clock5_init();assert(!clock5_set(2025,2,29));assert(clock5_set_time(2024,2,29,23,59));assert(clock5_seconds()%86400==86340);assert(!clock5_set_time(2024,2,29,24,0));
    for(i=0;i<29200;i+=137){clock5_decode(i,&yy,&mm,&dd);assert(clock5_encode(yy,mm,dd)==(uint32_t)i);}
    arcade_set_daily(12345);arcade_start(6,1900);memcpy(saved,a.g.slide.v,25);arcade_start(6,2000);assert(!memcmp(saved,a.g.slide.v,25)&&a.cols==4);arcade_set_daily(0);
    memset(variants,0,sizeof variants);arcade_start(1,3000);arcade_tick(3010,a.modal[0].x+2,a.modal[0].y+2,1,0,1);assert(a.state==COUNTDOWN);i=a.g.snake.x[0];arcade_tick(5000,0,0,0,0,0);assert(a.g.snake.x[0]==i&&a.elapsed==0);arcade_tick(6010,0,0,0,0,0);assert(a.state==PLAY&&a.elapsed==0);
    puts("PASS V5 old-game enhancements: snake combo/portals/timer, 20 tetromino bags, soft drop, 5x5 merging/undo, 120 solvable size variants, 4x4 PvP, memory timer, mine long press/release, nitro, calendar/leap/time, deterministic daily, countdown freeze.");
}
static void brick_v5_checks(void){int k,kind;ui_rect_t rect;
    for(k=0;k<2;k++){lcddev.width=k?800:480;lcddev.height=k?480:272;game_init();game_start_new(40000);game_launch_ball(40001);
        g_game.ball_vx=600;g_game.ball_vy=-900;
        for(kind=3;kind<=5;kind++){g_game.power_kind=kind;g_game.power_x=g_game.paddle_x+5;g_game.power_y=g_game.paddle_y;game_step_power(40002+kind);assert(!g_game.power_kind);}
        assert(g_game.slow&&g_game.sticky&&g_game.laser&&g_game.ball_vx==400&&g_game.ball_vy==-600);
        g_game.ball_x=((int32_t)g_game.paddle_x+g_game.paddle_w/2)<<8;g_game.ball_y=((int32_t)g_game.paddle_y-g_game.ball_r-1)<<8;g_game.ball_vx=0;g_game.ball_vy=512;
        game_step_physics(40010);assert(g_game.state==GAME_STATE_READY&&!g_game.sticky&&!g_game.ball_vy);
        game_launch_ball(40011);game_step_laser(41000);assert(g_game.laser_y[0]>0&&g_game.laser_y[1]>0);
        game_get_brick_rect(0,0,&rect);g_game.bricks[0][0]=1;g_game.laser_x[0]=rect.x+rect.w/2;g_game.laser_y[0]=rect.y+rect.h/2+6;game_step_laser(41001);assert(!g_game.bricks[0][0]);
        game_reset_ball();assert(!g_game.slow&&!g_game.laser&&!g_game.sticky&&!g_game.laser_y[0]);
    }puts("PASS V5 brick powerups: slow velocity, sticky paddle catch/relaunch, dual laser spawn/hit, reset cleanup at both resolutions.");
}
static void start_combat(int id,uint32_t now){combat_start(id,now,12345,1);mock_now=now;combat_tick(now,0,0,0,0);combat_tick(now+1,co.menu[0].x+4,co.menu[0].y+4,1,1);assert(co.state==CO_COUNT);mock_now=now+3001;combat_tick(mock_now,0,0,0,0);assert(co.state==CO_PLAY);combat_tick(mock_now+1,0,0,0,0);}
static uint32_t combat_hash(void){uint32_t h=2166136261U;int x,y;for(y=co.by;y<co.by+co.bh;y++)for(x=co.bx;x<co.bx+co.bw;x++)h=(h^frame[y][x])*16777619U;return h;}
static void combat_checks(void){int k,id,i,j,hp,px;uint32_t h;char name[40];
    for(k=0;k<2;k++){lcddev.width=k?800:480;lcddev.height=k?480:272;
        for(id=10;id<12;id++){start_combat(id,10000);sprintf(name,"v5_combat_%d_ready",id);combat_draw();shot(name);
            for(i=0;i<25;i++){co_step(255,id==10,co.bx+co.bw/2,co.by+co.bh-25,id==11);assert(co.state==CO_PLAY);h=combat_hash();memset(co.dirty,1,sizeof co.dirty);co_render();assert(h==combat_hash());}
            sprintf(name,"v5_combat_%d_play",id);shot(name);
            mock_now=15000;combat_tick(15000,co.keys[5].x+2,co.keys[5].y+2,1,1);assert(co.state==CO_PAUSE);px=co.px;i=co.frame;combat_tick(19000,0,0,0,0);assert(co.px==px&&co.frame==i);sprintf(name,"v5_combat_%d_pause",id);shot(name);
            co_end(1);sprintf(name,"v5_combat_%d_end",id);shot(name);
        }
        start_combat(10,20000);memset(co.map,0,sizeof co.map);co.spawned=co.total;co.px=80;co.py=144;px=co.px;tp_dev.sta=TP_PRES_DOWN|3;tp_dev.x[0]=co.keys[1].x+4;tp_dev.y[0]=co.keys[1].y+4;tp_dev.x[1]=co.keys[4].x+4;tp_dev.y[1]=co.keys[4].y+4;
        co.frame=20;combat_tick(24000,tp_dev.x[0],tp_dev.y[0],1,1);assert(co.px>px);j=0;for(i=0;i<CO_SHOTS;i++)j+=co.shots[i].alive;assert(j>0);tp_dev.sta=0;
        memset(co.shots,0,sizeof co.shots);co.map[4*15+4]=1;co_shoot(65,61,0,3,0,1);co_step(255,0,0,0,0);assert(co.map[4*15+4]==0);
        co.map[4*15+4]=2;co_shoot(65,61,0,3,0,1);co_step(255,0,0,0,0);assert(co.map[4*15+4]==2);
        co.map[4*15+4]=5;co_shoot(65,61,0,3,1,1);co_step(255,0,0,0,0);assert(co.state==CO_OVER);
        start_combat(11,25000);co.spawned=co.total;co.kills=co.total;co_step(255,0,0,0,0);assert(co.boss&&co.boss_hp>0);co.boss_hp=co.boss_max/4;co.boss_fire=co.frame-30;co_step(255,0,0,0,0);j=0;for(i=0;i<CO_SHOTS;i++)j+=co.shots[i].alive&&co.shots[i].enemy;assert(j>=5);shot("v5_boss");
        hp=co.boss_hp;co.armed=1;mock_now=30000;combat_tick(30000,co.keys[4].x+2,co.keys[4].y+2,1,1);assert(!co.bombs);assert(co.state==CO_NEXT||co.boss_hp<hp);
        start_combat(11,31000);co.invul=0;co.shield=1;hp=co.hp;co_hurt();assert(co.hp==hp&&!co.shield);co.invul=0;co_hurt();assert(co.hp==hp-1);
        for(id=10;id<12;id++){start_combat(id,35000);for(i=1;i<=4;i++){co.spawned=co.total;co.kills=co.total;if(id==11){co.boss=1;co.boss_hp=0;co.boss_max=50;}co_step(255,0,0,0,0);if(i==4)assert(co.state==CO_OVER&&co.won);else{assert(co.state==CO_NEXT&&co.level==i+1);co_level();co.state=CO_PLAY;}}}
        sh_page=3;shell_show();sh_view=5;sh_draw();shot("v5_medals");sh_view=6;sh_draw();shot("v5_daily");sh_view=7;sh_draw();shot("v5_date");sh_view=8;sh_draw();shot("v5_time");
    }
    puts("PASS combat: both resolutions, dirty rendering equals full redraw, multi-contact move+fire, brick/steel/base collisions, boss phase bullets/bomb, shield/life, four-stage wins, pause freeze, all new screens.");
}
int main(void){legacy_checks();ext_checks();v5_old_rules();brick_v5_checks();combat_checks();return 0;}
