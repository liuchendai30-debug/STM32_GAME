static void v61_release(void){v6_contacts(0,0,0,0,0);sticks_sample(0,0,0);}
static void v61_input_checks(void){int k,i,cx,cy,old;
 for(k=0;k<2;k++){lcddev.width=k?800:480;lcddev.height=k?480:272;sticks_init();v61_release();
  /* Three concurrent contacts; slot compaction must not transfer ownership. */
  cx=sticks.skill.x+sticks.skill.w/2;cy=sticks.skill.y+sticks.skill.h/2;
  v6_contacts(2,sticks.lx+12,sticks.ly,sticks.rx,sticks.ry-sticks.r/2);tp_dev.sta|=4;tp_dev.x[2]=cx;tp_dev.y[2]=cy;sticks_sample(0,0,1);assert(sticks.fire&&sticks.move==0&&sticks.skill_press);
  old=tp_dev.x[0];tp_dev.x[0]=tp_dev.x[2];tp_dev.x[2]=old;old=tp_dev.y[0];tp_dev.y[0]=tp_dev.y[2];tp_dev.y[2]=old;sticks_sample(0,0,1);assert(sticks.fire&&sticks.move==0&&!sticks.skill_press);
  v6_contacts(2,sticks.lx+12,sticks.ly,sticks.rx,sticks.ry-sticks.r/2);sticks_sample(0,0,1);assert(sticks.fire&&sticks.move==0&&!sticks.skill_press);v61_release();
  /* A held skill dragged into the attack stick never starts firing. */
  v6_contacts(1,cx,cy,0,0);sticks_sample(0,0,1);assert(sticks.skill_press);
  for(i=1;i<=8;i++){v6_contacts(1,cx+(sticks.rx-cx)*i/8,cy+(sticks.ry-cy)*i/8,0,0);sticks_sample(0,0,1);assert(!sticks.skill_press&&!sticks.fire&&!sticks.swap_press);}v61_release();
  /* Visible rim + seven pixels remains a useful full-speed movement target. */
  v6_contacts(1,sticks.lx+sticks.r+7,sticks.ly,0,0);sticks_sample(0,0,1);assert(sticks.move==0&&sticks.power==255);v61_release();
  while(sticks_sensitivity()!=2)sticks_cycle_sensitivity();v6_contacts(1,sticks.lx+sticks.r/8,sticks.ly,0,0);sticks_sample(0,0,1);assert(sticks.move==0);v61_release();sticks_cycle_sensitivity();v6_contacts(1,sticks.lx+sticks.r/8,sticks.ly,0,0);sticks_sample(0,0,1);assert(sticks.move==-1);v61_release();while(sticks_sensitivity()!=2)sticks_cycle_sensitivity();
  sticks.aim=0;v6_contacts(1,sticks.rx+20,sticks.ry+4,0,0);sticks_sample(0,0,1);assert(sticks.aim==0);v6_contacts(1,sticks.rx+20,sticks.ry+6,0,0);sticks_sample(0,0,1);assert(sticks.aim==1);v61_release();
 }
 /* The shared menu path still filters release noise and invalid coordinates. */
 memset(&g_touch,0,sizeof g_touch);console_defaults();tp_dev.touchtype=0x80;v6_contacts(1,50,50,0,0);touch_input_update(10);assert(!g_touch.press_event);touch_input_update(20);assert(g_touch.press_event&&g_touch.stable_down);touch_input_update(25);assert(!g_touch.press_event);v6_contacts(0,0,0,0,0);touch_input_update(30);assert(g_touch.stable_down);touch_input_update(50);assert(g_touch.release_event&&!g_touch.stable_down);v6_contacts(1,900,900,0,0);touch_input_update(70);touch_input_update(100);assert(!g_touch.stable_down);
 puts("PASS V6.1 input: both resolutions, three-finger reorder/release, button drag ownership, enlarged hit rim, sensitivity levels, aim hysteresis, faster capacitive press, filtered release and invalid samples.");
}
static void v61_arena(void){v6_start(0,0,0,0);memset(av.map,0,sizeof av.map);memset(av.enemies,0,sizeof av.enemies);memset(av.bullets,0,sizeof av.bullets);av.px=160*16;av.py=88*16;av.frame=200;av.shot_at=0;av.aim=0;av.energy=0;av.boss=0;av.total=av.spawned=1;av.invul=1000;}
static void v61_enemy(int i,int x,int y){av.enemies[i].hp=30;av.enemies[i].x=x*16;av.enemies[i].y=y*16;}
static void v61_melee_checks(void){int k,w,j,hp,x,energy;uint32_t hash;uint8_t saved;char name[60];
 for(k=0;k<2;k++){lcddev.width=k?800:480;lcddev.height=k?480:272;
  for(w=8;w<12;w++){v61_arena();v61_enemy(0,180,88);v61_enemy(1,140,88);v61_enemy(2,198,88);v61_enemy(3,182,108);av.weapon=w;av_fire();assert(av.energy==0&&av.melee_life);assert(av.enemies[0].hp<30);assert((av.enemies[1].hp<30)==(w==11));assert((av.enemies[2].hp<30)==(w==10));if(w==10)assert(av.enemies[3].hp==30);hp=av.enemies[0].hp;av_fire();assert(av.enemies[0].hp==hp);av.frame+=50;av_fire();assert(av.enemies[0].hp<hp);for(j=0;j<48;j++)assert(!av.bullets[j].life);
   av_transition(AV_PLAY);sprintf(name,"v61_melee_%d",w);shot(name);
   for(j=0;j<12;j++){sticks.move=-1;sticks.fire=0;av_step();hash=v6_hash();memset(av.dirty,1,sizeof av.dirty);av_render();assert(v6_hash()==hash);}
  }
  v61_arena();av.weapon=8;av_emit(180*16,88*16,8,40,1,0,1);av_emit(140*16,88*16,0,40,1,0,1);av_emit(180*16,88*16,8,40,1,AP_BLAST,1);av_fire();assert(!av.bullets[12].life&&av.bullets[13].life&&av.bullets[14].life);
  for(w=8;w<12;w++){v61_arena();av.weapon=w;v61_enemy(0,190,88);av.map[5*20+11]=2;av_fire();assert(av.enemies[0].hp==30&&av.map[5*20+11]==2);}
  v61_arena();av.weapon=9;v61_enemy(0,178,88);x=av.enemies[0].x;av_fire();assert(av.enemies[0].x>x);av.frame+=50;av.map[5*20+11]=1;av.map[5*20+12]=2;av_fire();assert(av.map[5*20+11]==0&&av.map[5*20+12]==2);
  v61_arena();av.weapon=10;v61_enemy(0,182,88);v61_enemy(1,200,88);av.boss=1;av.boss_hp=av.boss_max=30;av.bx=203*16;av.by=88*16;av_fire();assert(av.enemies[0].hp<30&&av.enemies[1].hp<30&&av.boss_hp<30);
  v61_arena();av.hero=2;sticks.move=-1;av.body=0;av_skill();assert(av.roll_boost);av.px=160*16;av.py=88*16;av.weapon=8;v61_enemy(0,180,88);av_fire();assert(av.enemies[0].hp==23&&!av.roll_boost);
  v61_arena();av.weapon=2;av.second=8;av_fire();assert(av.fallback&&av.weapon==2&&av.second==8&&!av.energy);j=0;for(w=0;w<48;w++)j+=av.bullets[w].life!=0;assert(j==1);
  /* Every melee weapon can be acquired without truncating old gun records. */
  saved=0xa5;for(w=8;w<12;w++){ember_stats.weapons=saved;av.room_weapon=w;av_transition(AV_CHEST);v6_tap(0);assert(av.weapon==w&&ember_stats.weapons==saved);}
  ember_flush();ember_load();assert(ember_stats.weapons==saved);
  /* Compare an adjacent connected wall edge after a projectile destroys it. */
  v61_arena();v61_enemy(0,260,100);av.map[4*20+11]=1;av.map[5*20+11]=1;av_transition(AV_PLAY);av_emit(176*16,75*16,0,80,2,0,0);av_projectiles();av_mark_actors();av_render();hash=v6_hash();memset(av.dirty,1,sizeof av.dirty);av_render();assert(v6_hash()==hash);
  /* Updated screens, independently of the old V6 screenshot fixtures. */
  adventure_start(0,1,555);shot("v61_flame_title");av_transition(AV_CODEX);shot("v61_codex");av_transition(AV_SELECT);shot("v61_hero_select");
  v6_start(0,0,0,0);av.py=100*16;av.px=150*16;av.weapon=8;av.second=4;av.invul=0;av.frame=200;av.shot_at=0;av.aim=0;av.enemies[0].hp=18;av.enemies[0].x=170*16;av.enemies[0].y=105*16;av.enemies[0].type=2;av_fire();av_transition(AV_PLAY);shot("v61_flame_battle");
  for(w=0;w<5;w++){av.floor=w;av.room=3;av_room();av_transition(AV_PLAY);sprintf(name,"v61_boss_%d",w);shot(name);}
  v6_start(1,2,0,0);av.skill_cd=165;av_scene();shot("v61_tank_battle");sh_view=1;sh_draw();shot("v61_settings");sh_page=0;shell_show();shot("v61_hall");(void)energy;
 }
 puts("PASS V6.1 combat/art: four melee ranges, held-attack cooldown, no energy cost, sword projectile parry, heavy knockback/masonry, spear multi-hit, radial rear hit, wall occlusion, boss damage, ranger boost, pistol fallback, gun record compatibility, connected-wall redraw, all melee animations match full redraw, both layouts.");
}
int main(void){v6_checks();v61_input_checks();v61_melee_checks();return 0;}
