"""Register-level checks of the real PWM init code, using peripheral stand-ins."""
from pathlib import Path
import re,subprocess
r=Path(__file__).resolve().parents[1];out=r/'Output/host';out.mkdir(exist_ok=True)
source=r'''
#include <stdint.h>
#include <assert.h>
#include <stdio.h>
typedef struct {uint32_t Pin,Mode,Speed;} GPIO_InitTypeDef;
static struct {uint32_t MAPR;} afio;
static struct {uint32_t CFGR;} rcc;
static struct {uint32_t CR1,PSC,ARR,CCMR2,CCER,CCR3,EGR;} tim;
#define AFIO (&afio)
#define RCC (&rcc)
#define TIM3 (&tim)
#define GPIOB 1
#define GPIO_PIN_0 1
#define GPIO_MODE_AF_PP 2
#define GPIO_SPEED_FREQ_HIGH 3
#define AFIO_MAPR_TIM3_REMAP (3U<<10)
#define AFIO_MAPR_SWJ_CFG (7U<<24)
#define AFIO_MAPR_SWJ_CFG_JTAGDISABLE (2U<<24)
#define RCC_CFGR_PPRE1 (7U<<8)
#define TIM_CCMR2_OC3PE (1U<<3)
#define TIM_CCER_CC3E (1U<<8)
#define TIM_EGR_UG 1
#define TIM_CR1_ARPE (1U<<7)
#define TIM_CR1_CEN 1
#define __HAL_RCC_GPIOB_CLK_ENABLE() ((void)0)
#define __HAL_RCC_AFIO_CLK_ENABLE() ((void)0)
#define __HAL_RCC_TIM3_CLK_ENABLE() ((void)0)
static uint32_t HAL_RCC_GetPCLK1Freq(void){return 36000000;}
static void HAL_GPIO_Init(int port,GPIO_InitTypeDef *p){assert(port==GPIOB&&p->Pin==GPIO_PIN_0&&p->Mode==GPIO_MODE_AF_PP);}
'''
source+=re.sub(r'^#include[^\n]*','',(r/'User/backlight.c').read_text(),flags=re.M)
source+=r'''
int main(void){
 afio.MAPR=0xffffffffU;rcc.CFGR=4U<<8;console_backlight(60);
 assert((afio.MAPR&AFIO_MAPR_SWJ_CFG)==AFIO_MAPR_SWJ_CFG_JTAGDISABLE);
 assert((afio.MAPR&AFIO_MAPR_TIM3_REMAP)==0);
 assert(tim.PSC==35&&tim.ARR==99&&tim.CCR3==60&&tim.CCER==TIM_CCER_CC3E);
 assert(72000000U/(tim.PSC+1)/(tim.ARR+1)==20000);
 console_backlight(20);assert(tim.CCR3==20);console_backlight(100);assert(tim.CCR3==100);
 puts("PASS PWM: 20 kHz at 72 MHz timer clock, PB0 only, SWD explicitly retained, duty updates.");return 0;
}
'''
p=out/'pwm_test.c';p.write_text(source,encoding='utf-8')
subprocess.run(['gcc','-std=c99',str(p),'-o',str(out/'pwm_test.exe')],check=True)
v=subprocess.run([str(out/'pwm_test.exe')],check=True,text=True,capture_output=True)
print(v.stdout);(out/'pwm_results.txt').write_text(v.stdout,encoding='utf-8')
