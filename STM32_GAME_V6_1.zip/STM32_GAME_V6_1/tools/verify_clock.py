"""Exercise real RTC register code with peripheral stand-ins, without hardware writes."""
from pathlib import Path
import re, subprocess
r = Path(__file__).resolve().parents[1]
out = r/'Output/host'
out.mkdir(parents=True, exist_ok=True)
source = r'''
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#define assert(x) do { if(!(x)){fprintf(stderr,"RTC check failed line %d\n",__LINE__);exit(1);} } while(0)
static struct {uint32_t APB1ENR,BDCR;} rcc;
static struct {uint32_t CR;} pwr;
static struct {uint32_t CRL,CRH,PRLH,PRLL,CNTH,CNTL;} rtc;
static struct {uint32_t DR1;} bkp;
#define RCC (&rcc)
#define PWR (&pwr)
#define RTC (&rtc)
#define BKP (&bkp)
#define RCC_APB1ENR_PWREN (1U<<28)
#define RCC_APB1ENR_BKPEN (1U<<27)
#define PWR_CR_DBP (1U<<8)
#define RCC_BDCR_RTCSEL (3U<<8)
#define RCC_BDCR_RTCSEL_0 (1U<<8)
#define RCC_BDCR_LSEON 1U
#define RCC_BDCR_LSERDY 2U
#define RCC_BDCR_RTCEN (1U<<15)
#define RTC_CRL_RSF 8U
#define RTC_CRL_CNF 16U
#define RTC_CRL_RTOFF 32U
static uint32_t ticks;
static int lse=1,sync_ok=1,write_ok=1;
static uint32_t HAL_GetTick(void){if(lse)rcc.BDCR|=2;if(sync_ok)rtc.CRL|=8;if(write_ok)rtc.CRL|=32;return ticks++;}
'''
source += re.sub(r'^#include[^\n]*', '', (r/'User/clock5.c').read_text(), flags=re.M)
source += r'''
int main(void){uint32_t saved;
lse=0;clock5_init();assert(!rtc_ok&&ticks<1600);
lse=1;sync_ok=0;clock5_init();assert(!rtc_ok);
sync_ok=1;write_ok=0;rtc.CRL=0;clock5_init();assert(!rtc_ok);
write_ok=1;rcc.BDCR=2U<<8;clock5_init();assert(!rtc_ok&&rcc.BDCR==(2U<<8));
rcc.BDCR=0;clock5_init();assert(rtc_ok&&!clock5_ready()&&rtc.PRLL==32767&&rtc.CRH==0);
assert(clock5_set_time(2026,9,14,21,30));saved=clock5_seconds();
assert(saved==clock5_encode(2026,9,14)*86400U+21*3600U+1800U);
clock5_init();assert(clock5_ready()&&clock5_seconds()==saved);
assert(!clock5_set_time(2026,2,29,0,0)&&clock5_seconds()==saved);
assert(!(rtc.CRL&RTC_CRL_CNF));
puts("PASS real RTC register path: LSE/sync/write timeouts, alternate clock preservation, prescaler, explicit date/time save, reboot counter preservation, invalid date rejection.");return 0;}
'''
(out/'clock_checks.c').write_text(source)
subprocess.run(['gcc','-std=c99',str(out/'clock_checks.c'),'-o',str(out/'clock_checks.exe')], check=True)
result = subprocess.run([str(out/'clock_checks.exe')], check=True, capture_output=True, text=True, timeout=10)
(out/'clock_results.txt').write_text(result.stdout)
print(result.stdout, end='')
