from pathlib import Path
import re, subprocess
from PIL import Image
root=Path(__file__).resolve().parents[1]
out=root/'Output/host';out.mkdir(exist_ok=True)
def strip(s):return re.sub(r'^#include[^\n]*','',s,flags=re.M)
support=(root/'tools/mock_lcd.h').read_text(encoding='utf-8')
mock=r'''
static uint8_t eeprom[256],beep_output,backlight_value;
static uint32_t mock_now=0;
static int write_budget=-1;
void beep_init(void) {beep_output=0;}
#define BEEP(x) (beep_output=(x))
void at24cxx_init(void) {}
void at24cxx_read(uint16_t addr,uint8_t *p,uint16_t n) {assert(addr+n<=256);memcpy(p,eeprom+addr,n);}
void at24cxx_write_one_byte(uint16_t addr,uint8_t v) {assert(addr<255&&!(addr>=40&&addr<=52));if(write_budget==0)return;if(write_budget>0)write_budget--;eeprom[addr]=v;}
void at24cxx_write(uint16_t addr,uint8_t *p,uint16_t n) {while(n--)at24cxx_write_one_byte(addr++,*p++);}
uint32_t HAL_GetTick(void) {return mock_now;}
void console_backlight(uint8_t value){assert(value<=100);backlight_value=value;}
'''
source='#define HOST_TEST 1\n'+support+mock
source+=strip((root/'User/console_service.h').read_text())
for name in ['arcade.h','combat.h','clock5.h','adventure.h','flame_art.h','sticks.h','ember_save.h']:source+=strip((root/'User'/name).read_text())
for name in ['ui_zh.c','console_service.c','clock5.c','combat.c','sticks.c','ember_save.c','flame_art.c','adventure.c','arcade.c','shell.c','main.c']:
    body=(root/'User'/name).read_text(encoding='utf-8')
    if name=='main.c':body=body.split('int main(void)')[0]
    source+='\n'+strip(body)
source+='\n'+(root/'tools/host_checks.c').read_text()
source+='\n'+(root/'tools/v5_checks.c').read_text().replace('int main(void)', 'static int v5_checks(void)')
source+='\n'+(root/'tools/v6_checks.c').read_text().replace('int main(void)', 'static int v6_checks(void)')
source+='\n'+(root/'tools/v61_checks.c').read_text()
(out/'test.c').write_text(source,encoding='utf-8')
subprocess.run(['gcc','-std=c99','-O1','-g',str(out/'test.c'),'-o',str(out/'test.exe')],check=True)
r=subprocess.run([str(out/'test.exe')],cwd=out,capture_output=True,text=True,timeout=90)
print(r.stdout);print(r.stderr)
(out/'results.txt').write_text(r.stdout+r.stderr,encoding='utf-8')
r.check_returncode()
for p in out.glob('*.ppm'):Image.open(p).save(p.with_suffix('.png'))
